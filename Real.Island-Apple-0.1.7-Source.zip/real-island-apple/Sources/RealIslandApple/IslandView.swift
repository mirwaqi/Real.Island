import AppKit
import IslandLogic
import SwiftUI

struct IslandView: View {
    @ObservedObject var model: IslandModel
    let retryAudio: () -> Void
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    private let accent = Color(red: 0.70, green: 0.57, blue: 1.00)

    var body: some View {
        let compact = model.page == .compact && !model.showingIncoming
        ZStack(alignment: .top) {
            UnevenRoundedRectangle(
                topLeadingRadius: model.cutoutHeight > 0 ? 3 : 13,
                bottomLeadingRadius: compact ? 9 : 15,
                bottomTrailingRadius: compact ? 9 : 15,
                topTrailingRadius: model.cutoutHeight > 0 ? 3 : 13
            )
            .fill(Color.black)
            VStack(spacing: 5) {
                if case .incoming(let messenger) = model.call {
                    incoming(messenger)
                } else {
                    header
                    if model.page == .music {
                        player.transition(.opacity.combined(with: .scale(
                            scale: reduceMotion ? 1 : 0.52, anchor: .top)))
                    }
                    if model.page == .settings { settings }
                }
            }
            .padding(.top, model.cutoutHeight)
            .padding(.horizontal, 11)
            .padding(.bottom, compact ? 0 : 4)
        }
        .environment(\.colorScheme, .dark)
        .foregroundStyle(Color.white)
        .animation(reduceMotion ? nil : .spring(response: 0.32, dampingFraction: 0.86), value: model.page)
        .animation(reduceMotion ? nil : .easeInOut(duration: 0.20), value: model.call)
    }

    private var header: some View {
        Button {
            model.open(model.page == .compact ? .music : .compact)
        } label: {
            HStack(spacing: 9) {
                TimelineView(.periodic(from: .now, by: 0.5)) { time in
                    if case .connected = model.call, let start = model.connectionUptime {
                        Label {
                            HStack(spacing: 5) {
                                Text("В звонке")
                                Text(callDuration(Int(max(0, ProcessInfo.processInfo.systemUptime - start))))
                                    .monospacedDigit()
                                    .foregroundStyle(.secondary)
                            }
                        } icon: {
                            Image(systemName: "phone.fill")
                                .foregroundStyle(.green)
                        }
                    } else {
                        Text(time.date, format: .dateTime.hour().minute())
                            .monospacedDigit()
                    }
                }
                if model.levels.contains(where: { $0 > 0.05 }) { waveform }
            }
            .font(.system(size: 12, weight: .semibold))
            .lineLimit(1)
            .frame(maxWidth: .infinity, minHeight: model.page == .compact ? 22 : 23)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityHint(model.page == .compact ? "Открыть островок" : "Свернуть островок")
    }

    private var waveform: some View {
        HStack(alignment: .center, spacing: 2.5) {
            ForEach(model.levels.indices, id: \.self) { index in
                Capsule()
                    .fill(accent)
                    .frame(width: 2.5, height: CGFloat(3 + model.levels[index] * 13))
            }
        }
        .frame(height: 17)
        .animation(reduceMotion ? nil : .easeOut(duration: 0.09), value: model.levels)
        .accessibilityHidden(true)
    }

    private func incoming(_ messenger: Messenger) -> some View {
        HStack(spacing: 13) {
            ZStack {
                Circle().fill(.green.opacity(0.17)).frame(width: 37, height: 37)
                TimelineView(.animation(minimumInterval: 1 / 30, paused: reduceMotion)) { time in
                    let phase = time.date.timeIntervalSinceReferenceDate.truncatingRemainder(dividingBy: 1.10)
                    let angle = phase < 0.32 ? sin(phase * 56) * 13 : 0
                    Image(systemName: "phone.fill")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundStyle(.green)
                        .rotationEffect(.degrees(reduceMotion ? 0 : angle))
                }
            }
            .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 3) {
                Text("Входящий звонок").font(.system(size: 14, weight: .semibold))
                Text(messenger.rawValue).font(.system(size: 11)).foregroundStyle(.secondary)
            }
            Spacer(minLength: 0)
        }
        .padding(9)
        .modifier(GlassCard())
        .padding(.top, 4)
        .transition(.opacity.combined(with: .scale(scale: 0.94, anchor: .top)))
    }

    private var player: some View {
        HStack(spacing: 8) {
            artwork
            VStack(alignment: .leading, spacing: 2) {
                Text(model.track?.title ?? "Музыка")
                    .font(.system(size: 12, weight: .semibold))
                Text(model.track.flatMap { $0.artist.isEmpty ? nil : $0.artist } ??
                     model.track?.player.name ?? "Нет трека")
                    .font(.system(size: 10))
                    .foregroundStyle(.secondary)
            }
            .lineLimit(1)
            .frame(maxWidth: .infinity, alignment: .leading)
            HStack(spacing: 3) {
                playbackButton(.previous, icon: "backward.fill", label: "Предыдущий трек")
                playbackButton(.toggle, icon: model.track?.isPlaying == true ? "pause.fill" : "play.fill",
                               label: model.track?.isPlaying == true ? "Пауза" : "Воспроизвести")
                playbackButton(.next, icon: "forward.fill", label: "Следующий трек")
            }
            .disabled(model.track == nil)
            Button {
                model.open(.settings)
            } label: {
                Image(systemName: "gearshape")
                    .font(.system(size: 12))
                    .frame(width: 22, height: 26)
                    .contentShape(Rectangle())
            }
            .buttonStyle(.borderless)
            .accessibilityLabel("Настройки")
        }
        .padding(.horizontal, 7)
        .padding(.vertical, 5)
        .modifier(GlassCard())
        .transition(.opacity)
    }

    private var artwork: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 6).fill(accent.opacity(0.23))
            if let url = model.track?.artwork, url.scheme == "https" {
                AsyncImage(url: url) { image in
                    image.resizable().scaledToFill()
                } placeholder: {
                    Image(systemName: "music.note").foregroundStyle(accent)
                }
            } else if let cover = model.musicCover {
                Image(nsImage: cover).resizable().scaledToFill()
            } else {
                Image(systemName: "music.note").foregroundStyle(accent)
            }
        }
        .frame(width: 30, height: 30)
        .clipShape(RoundedRectangle(cornerRadius: 6))
        .accessibilityHidden(true)
    }

    private func playbackButton(_ command: PlaybackCommand, icon: String, label: String) -> some View {
        Button {
            if let track = model.track { MediaControl.send(command, to: track.player) }
        } label: {
            Image(systemName: icon)
                .font(.system(size: 12, weight: .semibold))
                .frame(width: 23, height: 26)
                .contentShape(Rectangle())
        }
        .buttonStyle(.borderless)
        .accessibilityLabel(label)
    }

    private var settings: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Настройки").font(.system(size: 15, weight: .semibold))
                Spacer()
                Button("Готово") { model.open(.compact) }.buttonStyle(.borderless)
            }
            Toggle("Реакция полосок на звук", isOn: Binding(get: { model.audioEnabled }, set: model.setAudioEnabled))
            if model.audioEnabled && model.audioError {
                HStack {
                    Text("Проверь разрешение на запись системного звука.").font(.caption).foregroundStyle(.secondary)
                    Spacer()
                    Button("Повторить", action: retryAudio).buttonStyle(.borderless)
                }
            }
            Toggle("Управление Apple Music и Spotify", isOn: Binding(get: { model.automationEnabled },
                                                                         set: model.setAutomationEnabled))
            HStack {
                Label("Распознавание звонков", systemImage: "phone")
                Spacer()
                if model.accessibilityAllowed {
                    Image(systemName: "checkmark.circle.fill")
                        .foregroundStyle(.green)
                        .accessibilityLabel("Доступ разрешён")
                } else {
                    Button("Разрешить") { model.accessibilityAllowed = CallWindows.requestAccess() }
                }
            }
            Toggle("Оставить островок при входе", isOn: Binding(get: { model.loginEnabled }, set: model.setLoginEnabled))
            if let status = model.loginStatus { Text(status).font(.caption).foregroundStyle(.secondary) }
        }
        .toggleStyle(.switch)
        .font(.system(size: 12))
        .padding(12)
        .modifier(GlassCard())
        .transition(.opacity)
    }
}

private struct GlassCard: ViewModifier {
    func body(content: Content) -> some View {
        let shape = RoundedRectangle(cornerRadius: 13)
        if #available(macOS 26, *) {
            content.background {
                shape.fill(Color(white: 0.045).opacity(0.88))
                    .glassEffect(.regular.tint(.black.opacity(0.78)), in: shape)
            }
        } else {
            content.background {
                shape.fill(.ultraThinMaterial)
                    .overlay { shape.fill(Color(white: 0.045).opacity(0.88)) }
            }
        }
    }
}
