import AppKit
import ApplicationServices
import IslandLogic
import ServiceManagement
import SwiftUI

enum Page {
    case compact, music, settings
}

@MainActor
final class IslandModel: ObservableObject {
    @Published private(set) var page: Page = .compact
    @Published private(set) var call: CallPhase = .idle
    @Published private(set) var connectionUptime: TimeInterval?
    @Published var track: Track?
    @Published var musicCover: NSImage?
    @Published var levels = Array(repeating: Float(0), count: 5)
    @Published var cutoutHeight: CGFloat = 0
    @Published var audioError = false
    @Published var accessibilityAllowed = AXIsProcessTrusted()
    @Published var loginEnabled = SMAppService.mainApp.status == .enabled
    @Published var loginStatus: String?
    @Published private(set) var audioEnabled = UserDefaults.standard.bool(forKey: "audioEnabled")
    @Published private(set) var automationEnabled = UserDefaults.standard.bool(forKey: "automationEnabled")
    var onSizeChange: (() -> Void)?
    private var callMisses = 0

    var showingIncoming: Bool {
        if case .incoming = call { return true }
        return false
    }

    func open(_ page: Page) {
        guard self.page != page else { return }
        self.page = page
        onSizeChange?()
    }

    func updateCall(_ phase: CallPhase) {
        if phase == .idle, case .connected = call {
            callMisses += 1
            guard callMisses >= 3 else { return }
        } else {
            callMisses = 0
        }
        guard call != phase else { return }
        call = phase
        if case .connected = phase {
            connectionUptime = ProcessInfo.processInfo.systemUptime
        } else {
            connectionUptime = nil
        }
        onSizeChange?()
    }

    func setAudioEnabled(_ enabled: Bool) {
        audioEnabled = enabled
        audioError = false
        if !enabled { levels = Array(repeating: 0, count: 5) }
        UserDefaults.standard.set(enabled, forKey: "audioEnabled")
    }

    func setAutomationEnabled(_ enabled: Bool) {
        automationEnabled = enabled
        if !enabled {
            track = nil
            musicCover = nil
        }
        UserDefaults.standard.set(enabled, forKey: "automationEnabled")
    }

    func setLoginEnabled(_ enabled: Bool) {
        do {
            if enabled { try SMAppService.mainApp.register() }
            else { try SMAppService.mainApp.unregister() }
            loginStatus = SMAppService.mainApp.status == .requiresApproval
                ? "Подтверди запуск в системных настройках." : nil
        } catch {
            loginStatus = "Не удалось изменить запуск при входе."
        }
        loginEnabled = SMAppService.mainApp.status == .enabled
    }
}

@MainActor
final class IslandApplication: NSObject, NSApplicationDelegate {
    private let model = IslandModel()
    private let meter = MusicMeter()
    private let callQueue = DispatchQueue(label: "RealIslandApple.calls", qos: .utility)
    private let panel = NSPanel(contentRect: .zero, styleMask: [.borderless, .nonactivatingPanel],
                                backing: .buffered, defer: true)
    private var statusItem: NSStatusItem?
    private var updateTimer: Timer?
    private var checkingCalls = false
    private var lastTrackUpdate: TimeInterval = 0
    private var lastAudioUpdate: TimeInterval = 0
    private var lastAudioFrame: TimeInterval = 0
    private var panelVisible = true

    func applicationDidFinishLaunching(_ notification: Notification) {
        panel.isOpaque = false
        panel.backgroundColor = .clear
        panel.hasShadow = false
        panel.level = .statusBar
        panel.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary, .ignoresCycle]
        panel.hidesOnDeactivate = false
        panel.isReleasedWhenClosed = false
        panel.contentView = NSHostingView(rootView: IslandView(model: model, retryAudio: { [weak self] in
            self?.meter.reset()
            self?.lastAudioUpdate = 0
        }))
        model.onSizeChange = { [weak self] in self?.position() }
        configureMenu()
        position()
        panel.orderFrontRegardless()
        NotificationCenter.default.addObserver(self, selector: #selector(screenChanged),
                                               name: NSApplication.didChangeScreenParametersNotification, object: nil)
        updateTimer = Timer.scheduledTimer(withTimeInterval: 0.85, repeats: true) { [weak self] _ in
            Task { @MainActor in self?.refresh() }
        }
    }

    func applicationWillTerminate(_ notification: Notification) {
        updateTimer?.invalidate()
        meter.reset()
    }

    private func position() {
        guard let screen = NSScreen.screens.first(where: {
            $0.auxiliaryTopLeftArea != nil && $0.auxiliaryTopRightArea != nil
        }) ?? NSScreen.main else { return }
        let left = screen.auxiliaryTopLeftArea
        let right = screen.auxiliaryTopRightArea
        var notch: CGFloat = 0
        var notchWidth: CGFloat = 0
        var center = screen.frame.midX
        var top = screen.visibleFrame.maxY
        if let left, let right, right.minX > left.maxX {
            center = (right.minX + left.maxX) / 2
            notchWidth = right.minX - left.maxX
            notch = max(screen.safeAreaInsets.top, screen.frame.maxY - min(left.minY, right.minY))
            top = screen.frame.maxY
        }
        if model.cutoutHeight != notch { model.cutoutHeight = notch }
        let compactWidth: CGFloat = notchWidth > 0 ? notchWidth : 160
        let size: CGSize
        if model.showingIncoming { size = CGSize(width: 346, height: 70) }
        else {
            switch model.page {
            case .settings: size = CGSize(width: 346, height: 235)
            case .music: size = CGSize(width: max(276, notchWidth), height: 74)
            case .compact: size = CGSize(width: compactWidth, height: 22)
            }
        }
        let height = notch + size.height
        let frame = NSRect(x: center - size.width / 2, y: top - height, width: size.width, height: height)
        guard panel.frame != frame else { return }
        panel.setFrame(frame, display: panel.isVisible, animate: panel.isVisible)
    }

    @objc private func screenChanged() { position() }

    private func refresh() {
        model.accessibilityAllowed = AXIsProcessTrusted()
        if !checkingCalls {
            checkingCalls = true
            callQueue.async { [weak self] in
                let phase = CallWindows.read()
                DispatchQueue.main.async {
                    guard let self else { return }
                    self.checkingCalls = false
                    self.model.updateCall(phase)
                    if self.model.showingIncoming && !self.panelVisible {
                        self.panelVisible = true
                        self.panel.orderFrontRegardless()
                    }
                }
            }
        }
        let now = ProcessInfo.processInfo.systemUptime
        if now - lastAudioFrame > 1.2, model.levels.contains(where: { $0 != 0 }) {
            model.levels = Array(repeating: 0, count: 5)
        }
        if now - lastTrackUpdate >= 2.5, model.automationEnabled {
            lastTrackUpdate = now
            let old = model.track
            let new = MediaControl.track(preferred: old?.player)
            if new != old { model.track = new }
            if new?.player == .music, old?.title != new?.title || old?.artist != new?.artist || old?.player != new?.player {
                model.musicCover = MediaControl.musicArtwork()
            } else if new?.player != .music, model.musicCover != nil {
                model.musicCover = nil
            }
        }
        if now - lastAudioUpdate >= 2.5 {
            lastAudioUpdate = now
            meter.update(enabled: model.audioEnabled, onLevels: { [weak self] levels in
                guard let self, self.model.audioEnabled else { return }
                self.lastAudioFrame = ProcessInfo.processInfo.systemUptime
                self.model.levels = levels
            }, onError: { [weak self] failed in self?.model.audioError = failed })
        }
    }

    private func configureMenu() {
        let item = NSStatusBar.system.statusItem(withLength: NSStatusItem.squareLength)
        statusItem = item
        item.button?.image = NSImage(systemSymbolName: "capsule", accessibilityDescription: "Real.Island Apple")
        item.button?.toolTip = "Real.Island Apple"
        let menu = NSMenu()
        let toggle = NSMenuItem(title: "Показать или скрыть островок", action: #selector(togglePanel), keyEquivalent: "")
        toggle.target = self
        menu.addItem(toggle)
        let settings = NSMenuItem(title: "Настройки", action: #selector(settings), keyEquivalent: ",")
        settings.target = self
        menu.addItem(settings)
        menu.addItem(.separator())
        menu.addItem(withTitle: "Завершить Real.Island Apple", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q")
        item.menu = menu
    }

    @objc private func togglePanel() {
        panelVisible.toggle()
        if panelVisible { position(); panel.orderFrontRegardless() }
        else { panel.orderOut(nil) }
    }

    @objc private func settings() {
        model.open(.settings)
        if !panelVisible { togglePanel() }
    }
}

MainActor.assumeIsolated {
    let app = NSApplication.shared
    let delegate = IslandApplication()
    app.setActivationPolicy(.accessory)
    app.delegate = delegate
    withExtendedLifetime(delegate) { app.run() }
}
