import AppKit
import IslandLogic
import SwiftUI

struct IslandView: View {
    @ObservedObject var model: IslandModel
    let retryAudio: () -> Void
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var reminderTitle = ""
    @State private var reminderDate = Date.now.addingTimeInterval(300)
    @State private var reminderError = false

    private let accent = Color(red: 0.70, green: 0.57, blue: 1.00)

    var body: some View {
        Group {
            if model.showingMusicNotch { musicNotch }
            else { standardPanel }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
        .environment(\.colorScheme, .dark)
        .foregroundStyle(Color.white)
        .animation(reduceMotion ? nil : .spring(response: 0.32, dampingFraction: 0.86), value: model.page)
        .animation(reduceMotion ? nil : .easeInOut(duration: 0.16), value: model.musicCardHidden)
        .animation(reduceMotion ? nil : .easeInOut(duration: 0.20), value: model.call)
    }

    private var standardPanel: some View {
        let compact = model.page == .compact && !model.showingIncoming
        return ZStack(alignment: .top) {
            UnevenRoundedRectangle(
                topLeadingRadius: model.cutoutHeight > 0 ? 3 : 13,
                bottomLeadingRadius: compact ? 9 : 15,
                bottomTrailingRadius: compact ? 9 : 15,
                topTrailingRadius: model.cutoutHeight > 0 ? 3 : 13
            )
            .fill(Color.black)
            VStack(spacing: 5) {
                if case .incoming(let messenger) = model.call {
                    incoming(messenger)
                } else if let reminder = model.reminderNotice {
                    reminderBanner(reminder)
                } else {
                    header
                    if model.page == .music {
                        player(small: false).transition(.opacity.combined(with: .scale(
                            scale: reduceMotion ? 1 : 0.52, anchor: .top)))
                    }
                    if model.page == .settings { settings }
                    if model.page == .reminders { reminders }
                }
            }
            .padding(.top, model.cutoutHeight)
            .padding(.horizontal, 11)
            .padding(.bottom, compact ? 0 : 4)
        }
    }

    private var musicNotch: some View {
        ZStack(alignment: .top) {
            VStack(spacing: 0) {
                Color.clear.frame(height: model.cutoutHeight)
                header
                Color.clear.frame(height: 21)
            }
            .frame(width: model.notchWidth)
            .background {
                MusicNotchWave(levels: reduceMotion ? [] : model.levels)
                    .fill(Color.black)
                    .animation(reduceMotion ? nil : .easeOut(duration: 0.10), value: model.levels)
            }
            if !model.musicCardHidden {
                player(small: true)
                    .frame(width: IslandModel.musicCardWidth)
                    .offset(x: (model.notchWidth + IslandModel.musicCardWidth) / 2 + IslandModel.musicCardGap,
                            y: model.cutoutHeight + 2)
                    .transition(.opacity)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
    }

    private var header: some View {
        Button {
            if model.showingMusicNotch && model.musicCardHidden {
                model.setMusicCardHidden(false)
            } else {
                model.open(model.page == .compact ? .music : .compact)
            }
        } label: {
            HStack(spacing: 9) {
                TimelineView(.periodic(from: .now, by: 0.5)) { time in
                    if case .connected = model.call, let start = model.connectionUptime {
                        Label {
                            HStack(spacing: 5) {
                                Text("В звонке")
                                Text(callDuration(Int(max(0, ProcessInfo.processInfo.systemUptime - start))))
                                    .monospacedDigit()
                                    .foregroundStyle(.secondary)
                            }
                        } icon: {
                            Image(systemName: "phone.fill")
                                .foregroundStyle(.green)
                        }
                    } else {
                        Text(time.date, format: .dateTime.hour().minute())
                            .monospacedDigit()
                    }
                }
                if !model.showingMusicNotch && model.levels.contains(where: { $0 > 0.05 }) { waveform }
            }
            .font(.system(size: 12, weight: .semibold))
            .lineLimit(1)
            .frame(maxWidth: .infinity, minHeight: model.page == .compact ? 22 : 23)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityHint(model.page == .compact ? "Открыть островок" : "Свернуть островок")
    }

    private var waveform: some View {
        HStack(alignment: .center, spacing: 2.5) {
            ForEach(model.levels.indices, id: \.self) { index in
                Capsule()
                    .fill(accent)
                    .frame(width: 2.5, height: CGFloat(3 + model.levels[index] * 13))
            }
        }
        .frame(height: 17)
        .animation(reduceMotion ? nil : .easeOut(duration: 0.09), value: model.levels)
        .accessibilityHidden(true)
    }

    private func incoming(_ messenger: Messenger) -> some View {
        HStack(spacing: 13) {
            ZStack {
                Circle().fill(.green.opacity(0.17)).frame(width: 37, height: 37)
                TimelineView(.animation(minimumInterval: 1 / 30, paused: reduceMotion)) { time in
                    let phase = time.date.timeIntervalSinceReferenceDate.truncatingRemainder(dividingBy: 1.10)
                    let angle = phase < 0.32 ? sin(phase * 56) * 13 : 0
                    Image(systemName: "phone.fill")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundStyle(.green)
                        .rotationEffect(.degrees(reduceMotion ? 0 : angle))
                }
            }
            .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 3) {
                Text("Входящий звонок").font(.system(size: 14, weight: .semibold))
                Text(messenger.rawValue).font(.system(size: 11)).foregroundStyle(.secondary)
            }
            Spacer(minLength: 0)
        }
        .padding(9)
        .modifier(GlassCard())
        .padding(.top, 4)
        .transition(.opacity.combined(with: .scale(scale: 0.94, anchor: .top)))
    }

    private func player(small: Bool) -> some View {
        Group {
            if small {
                VStack(alignment: .leading, spacing: 1) {
                    HStack(spacing: 8) {
                        artwork
                        trackLabel
                        settingsButton
                    }
                    HStack {
                        transport.padding(.leading, 32)
                        Spacer(minLength: 0)
                        Button {
                            model.setMusicCardHidden(true)
                        } label: {
                            Image(systemName: "xmark")
                                .font(.system(size: 10, weight: .semibold))
                                .frame(width: 22, height: 26)
                                .contentShape(Rectangle())
                        }
                        .buttonStyle(.borderless)
                        .foregroundStyle(.secondary)
                        .help("Скрыть мини-плеер")
                        .accessibilityLabel("Скрыть мини-плеер")
                    }
                }
            } else {
                HStack(spacing: 8) {
                    artwork
                    trackLabel
                    transport
                    settingsButton
                }
            }
        }
        .padding(.horizontal, 7)
        .padding(.vertical, 5)
        .modifier(GlassCard())
    }

    private var trackLabel: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(model.track?.title ?? "Музыка")
                .font(.system(size: 12, weight: .semibold))
            Text(model.track.flatMap { $0.artist.isEmpty ? nil : $0.artist } ??
                 model.track?.player.name ?? "Нет трека")
                .font(.system(size: 10))
                .foregroundStyle(.secondary)
        }
        .lineLimit(1)
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var transport: some View {
        HStack(spacing: 3) {
            playbackButton(.previous, icon: "backward.fill", label: "Предыдущий трек")
            playbackButton(.toggle, icon: model.track?.isPlaying == true ? "pause.fill" : "play.fill",
                           label: model.track?.isPlaying == true ? "Пауза" : "Воспроизвести")
            playbackButton(.next, icon: "forward.fill", label: "Следующий трек")
        }
        .disabled(model.track == nil)
    }

    private var settingsButton: some View {
        Button {
            model.open(.settings)
        } label: {
            Image(systemName: "gearshape")
                .font(.system(size: 12))
                .frame(width: 22, height: 26)
                .contentShape(Rectangle())
        }
        .buttonStyle(.borderless)
        .accessibilityLabel("Настройки")
    }

    private func reminderBanner(_ reminder: ScheduledReminder) -> some View {
        HStack(spacing: 10) {
            Image(systemName: "bell.fill").foregroundStyle(accent)
            VStack(alignment: .leading, spacing: 2) {
                Text("Напоминание").font(.caption).foregroundStyle(.secondary)
                Text(reminder.title).font(.system(size: 12, weight: .semibold)).lineLimit(1)
            }
            Spacer()
            Button("Готово") { model.dismissReminder() }.buttonStyle(.borderless)
        }
        .padding(9)
        .modifier(GlassCard())
        .padding(.top, 7)
    }

    private var reminders: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("Напоминания").font(.system(size: 15, weight: .semibold))
                Spacer()
                Button("Настройки") { model.open(.settings) }
                Button("Готово") { model.open(.compact) }
            }
            TextField("О чём напомнить", text: $reminderTitle)
                .textFieldStyle(.roundedBorder)
            HStack {
                DatePicker("Дата и время", selection: $reminderDate, displayedComponents: [.date, .hourAndMinute])
                    .labelsHidden()
                    .accessibilityLabel("Дата и время")
                Spacer(minLength: 4)
                Button("Добавить") {
                    reminderError = !model.addReminder(title: reminderTitle, date: reminderDate)
                    if !reminderError { reminderTitle = "" }
                }
            }
            if reminderError {
                Text("Введи текст и выбери время в будущем.").font(.caption).foregroundStyle(.secondary)
            }
            ScrollView {
                VStack(alignment: .leading, spacing: 5) {
                    if model.reminders.isEmpty {
                        Text("Нет запланированных напоминаний").foregroundStyle(.secondary)
                    }
                    ForEach(model.reminders.sorted(by: { $0.date < $1.date })) { reminder in
                        HStack {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(reminder.title).lineLimit(1)
                                Text(reminder.date.formatted(date: .abbreviated, time: .shortened))
                                    .font(.caption).foregroundStyle(.secondary)
                            }
                            Spacer()
                            Button {
                                model.removeReminder(reminder)
                            } label: { Image(systemName: "trash") }
                            .accessibilityLabel("Удалить напоминание")
                        }
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .frame(height: 91)
        }
        .font(.system(size: 12))
        .padding(12)
        .modifier(GlassCard())
    }

    private var artwork: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 6).fill(accent.opacity(0.23))
            if let url = model.track?.artwork, url.scheme == "https" {
                AsyncImage(url: url) { image in
                    image.resizable().scaledToFill()
                } placeholder: {
                    Image(systemName: "music.note").foregroundStyle(accent)
                }
            } else if let cover = model.musicCover {
                Image(nsImage: cover).resizable().scaledToFill()
            } else {
                Image(systemName: "music.note").foregroundStyle(accent)
            }
        }
        .frame(width: 30, height: 30)
        .clipShape(RoundedRectangle(cornerRadius: 6))
        .accessibilityHidden(true)
    }

    private func playbackButton(_ command: PlaybackCommand, icon: String, label: String) -> some View {
        Button {
            if let track = model.track { MediaControl.send(command, to: track.player) }
        } label: {
            Image(systemName: icon)
                .font(.system(size: 12, weight: .semibold))
                .frame(width: 23, height: 26)
                .contentShape(Rectangle())
        }
        .buttonStyle(.borderless)
        .accessibilityLabel(label)
    }

    private var settings: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Настройки").font(.system(size: 15, weight: .semibold))
                Spacer()
                Button("Напоминания") { model.open(.reminders) }.buttonStyle(.borderless)
                Button("Готово") { model.open(.compact) }.buttonStyle(.borderless)
            }
            Toggle("Реакция полосок на звук", isOn: Binding(get: { model.audioEnabled }, set: model.setAudioEnabled))
            if model.audioEnabled && model.audioError {
                HStack {
                    Text("Проверь разрешение на запись системного звука.").font(.caption).foregroundStyle(.secondary)
                    Spacer()
                    Button("Повторить", action: retryAudio).buttonStyle(.borderless)
                }
            }
            Toggle("Управление Apple Music и Spotify", isOn: Binding(get: { model.automationEnabled },
                                                                         set: model.setAutomationEnabled))
            HStack {
                Label("Распознавание звонков", systemImage: "phone")
                Spacer()
                if model.accessibilityAllowed {
                    Image(systemName: "checkmark.circle.fill")
                        .foregroundStyle(.green)
                        .accessibilityLabel("Доступ разрешён")
                } else {
                    Button("Разрешить") { model.accessibilityAllowed = CallWindows.requestAccess() }
                }
            }
            Toggle("Оставить островок при входе", isOn: Binding(get: { model.loginEnabled }, set: model.setLoginEnabled))
            if let status = model.loginStatus { Text(status).font(.caption).foregroundStyle(.secondary) }
        }
        .toggleStyle(.switch)
        .font(.system(size: 12))
        .padding(12)
        .modifier(GlassCard())
        .transition(.opacity)
    }
}

private struct MusicNotchWave: Shape {
    private typealias Pair = AnimatablePair<CGFloat, CGFloat>
    var data: AnimatablePair<AnimatablePair<CGFloat, CGFloat>, AnimatablePair<CGFloat, AnimatablePair<CGFloat, CGFloat>>>

    init(levels: [Float]) {
        let values = (0..<5).map { index in
            levels.indices.contains(index) ? CGFloat(max(0, min(1, levels[index]))) : 0
        }
        data = AnimatablePair(Pair(values[0], values[1]),
                              AnimatablePair(values[2], Pair(values[3], values[4])))
    }

    var animatableData: AnimatablePair<AnimatablePair<CGFloat, CGFloat>, AnimatablePair<CGFloat, AnimatablePair<CGFloat, CGFloat>>> {
        get { data }
        set { data = newValue }
    }

    func path(in rect: CGRect) -> Path {
        let base = rect.maxY - 21
        let levels = [data.first.first, data.first.second, data.second.first,
                      data.second.second.first, data.second.second.second]
        let shoulder = min(6, rect.width * 0.04)
        let span = (rect.width - 2 * shoulder) / CGFloat(levels.count)
        let depthLimits: [CGFloat] = [13, 15, 21, 15, 13]
        let tipPositions: [CGFloat] = [0.44, 0.58, 0.54, 0.43, 0.55]
        var path = Path()
        path.move(to: CGPoint(x: rect.minX, y: rect.minY))
        path.addLine(to: CGPoint(x: rect.minX, y: base - shoulder))
        path.addQuadCurve(to: CGPoint(x: rect.minX + shoulder, y: base),
                          control: CGPoint(x: rect.minX, y: base))
        for (index, level) in levels.enumerated() {
            let start = rect.minX + shoulder + CGFloat(index) * span
            let tip = start + span * tipPositions[index]
            let depth = level * depthLimits[index]
            path.addLine(to: CGPoint(x: start + span * 0.15, y: base))
            path.addLine(to: CGPoint(x: tip, y: base + depth))
            path.addLine(to: CGPoint(x: start + span * 0.85, y: base))
            path.addLine(to: CGPoint(x: start + span, y: base))
        }
        path.addQuadCurve(to: CGPoint(x: rect.maxX, y: base - shoulder),
                          control: CGPoint(x: rect.maxX, y: base))
        path.addLine(to: CGPoint(x: rect.maxX, y: rect.minY))
        path.closeSubpath()
        return path
    }
}

private struct GlassCard: ViewModifier {
    func body(content: Content) -> some View {
        let shape = RoundedRectangle(cornerRadius: 13)
        if #available(macOS 26, *) {
            content.background {
                shape.fill(Color(white: 0.045).opacity(0.88))
                    .glassEffect(.regular.tint(.black.opacity(0.78)), in: shape)
            }
        } else {
            content.background {
                shape.fill(.ultraThinMaterial)
                    .overlay { shape.fill(Color(white: 0.045).opacity(0.88)) }
            }
        }
    }
}
