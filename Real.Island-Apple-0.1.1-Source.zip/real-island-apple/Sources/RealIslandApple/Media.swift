import AppKit
import AudioToolbox
import CoreAudio
import Foundation
import IslandLogic

enum Player: String, CaseIterable {
    case music = "com.apple.Music"
    case spotify = "com.spotify.client"

    var name: String { self == .music ? "Музыка" : "Spotify" }
}

enum PlaybackCommand: String {
    case previous = "previous track"
    case toggle = "playpause"
    case next = "next track"
}

struct Track: Equatable {
    let player: Player
    let title: String
    let artist: String
    let isPlaying: Bool
    let artwork: URL?
}

enum MediaControl {
    static func track(preferred: Player?) -> Track? {
        let running = Set(NSWorkspace.shared.runningApplications.compactMap(\.bundleIdentifier))
        let players = Player.allCases.filter { running.contains($0.rawValue) }
        var paused: Track?
        for player in players.sorted(by: { $0 == preferred && $1 != preferred }) {
            let artwork = player == .spotify ? "artwork url of current track" : "\"\""
            let query = """
                tell application id "\(player.rawValue)"
                    if player state is stopped then return {}
                    return {name of current track, artist of current track, (player state is playing), \(artwork)}
                end tell
                """
            guard let reply = execute(query), reply.numberOfItems >= 3,
                  let title = reply.atIndex(1)?.stringValue, !title.isEmpty else { continue }
            let track = Track(player: player, title: title, artist: reply.atIndex(2)?.stringValue ?? "",
                              isPlaying: reply.atIndex(3)?.booleanValue ?? false,
                              artwork: reply.atIndex(4)?.stringValue.flatMap { URL(string: $0) })
            if track.isPlaying { return track }
            if paused == nil { paused = track }
        }
        return paused
    }

    static func send(_ command: PlaybackCommand, to player: Player) {
        guard !NSRunningApplication.runningApplications(withBundleIdentifier: player.rawValue).isEmpty else { return }
        _ = execute("tell application id \"\(player.rawValue)\" to \(command.rawValue)")
    }

    static func musicArtwork() -> NSImage? {
        guard let data = execute("tell application id \"com.apple.Music\" to get raw data of artwork 1 of current track")?.data else {
            return nil
        }
        return NSImage(data: data)
    }

    private static func execute(_ source: String) -> NSAppleEventDescriptor? {
        var error: NSDictionary?
        return NSAppleScript(source: source)?.executeAndReturnError(&error)
    }
}

final class MusicMeter {
    private let queue = DispatchQueue(label: "RealIslandApple.audio")
    private let callbackQueue = DispatchQueue(label: "RealIslandApple.audio.samples", qos: .userInteractive)
    private var tap: AudioObjectID = kAudioObjectUnknown
    private var device: AudioObjectID = kAudioObjectUnknown
    private var callback: AudioDeviceIOProcID?
    private var previousProcesses: [AudioObjectID] = []
    private var meter = AudioBands()
    private var window = Array(repeating: Float(0), count: 2048)
    private var windowCount = 0

    private let browserPrefixes = ["com.apple.Safari", "com.google.Chrome", "com.microsoft.edgemac",
                                   "org.mozilla.firefox", "company.thebrowser.Browser", "com.brave.Browser"]

    func update(enabled: Bool, onLevels: @escaping ([Float]) -> Void, onError: @escaping (Bool) -> Void) {
        queue.async { [self] in
            guard enabled else {
                if tap != kAudioObjectUnknown { stop() }
                previousProcesses = []
                return
            }
            let processes = musicProcesses()
            guard processes != previousProcesses else { return }
            stop()
            previousProcesses = processes
            guard !processes.isEmpty else {
                DispatchQueue.main.async { onLevels(Array(repeating: 0, count: 5)); onError(false) }
                return
            }
            let started = start(processes, onLevels: onLevels)
            DispatchQueue.main.async { onError(!started) }
        }
    }

    func reset() {
        queue.async { [self] in
            stop()
            previousProcesses = []
        }
    }

    private func musicProcesses() -> [AudioObjectID] {
        let system = AudioObjectID(kAudioObjectSystemObject)
        var key = property(kAudioHardwarePropertyProcessObjectList)
        var size: UInt32 = 0
        guard AudioObjectGetPropertyDataSize(system, &key, 0, nil, &size) == noErr,
              size >= UInt32(MemoryLayout<AudioObjectID>.stride) else { return [] }
        var ids = Array(repeating: AudioObjectID(0), count: Int(size) / MemoryLayout<AudioObjectID>.stride)
        let status = ids.withUnsafeMutableBytes { buffer in
            guard let data = buffer.baseAddress else { return OSStatus(-1) }
            return AudioObjectGetPropertyData(system, &key, 0, nil, &size, data)
        }
        guard status == noErr else { return [] }
        return ids.prefix(Int(size) / MemoryLayout<AudioObjectID>.stride).filter { id in
            var bundleKey = property(kAudioProcessPropertyBundleID)
            var bundle: CFString? = nil
            var bundleSize = UInt32(MemoryLayout<CFString?>.size)
            guard AudioObjectGetPropertyData(id, &bundleKey, 0, nil, &bundleSize, &bundle) == noErr,
                  let bundle else { return false }
            let name = bundle as String
            return Player.allCases.contains { name == $0.rawValue || name.hasPrefix($0.rawValue + ".") } ||
                browserPrefixes.contains { name == $0 || name.hasPrefix($0 + ".") }
        }.sorted()
    }

    private func start(_ processes: [AudioObjectID], onLevels: @escaping ([Float]) -> Void) -> Bool {
        let description = CATapDescription(monoMixdownOfProcesses: processes)
        description.name = "Real.Island Apple"
        description.isPrivate = true
        description.muteBehavior = .unmuted
        guard AudioHardwareCreateProcessTap(description, &tap) == noErr else { return false }

        let aggregate: [String: Any] = [
            kAudioAggregateDeviceNameKey: "Real.Island Apple Audio",
            kAudioAggregateDeviceUIDKey: UUID().uuidString,
            kAudioAggregateDeviceIsPrivateKey: true,
            kAudioAggregateDeviceTapAutoStartKey: true,
            kAudioAggregateDeviceTapListKey: [[
                kAudioSubTapUIDKey: description.uuid.uuidString,
                kAudioSubTapDriftCompensationKey: true
            ]]
        ]
        guard AudioHardwareCreateAggregateDevice(aggregate as CFDictionary, &device) == noErr else {
            stop()
            return false
        }
        var address = property(kAudioTapPropertyFormat)
        var format = AudioStreamBasicDescription()
        var formatSize = UInt32(MemoryLayout<AudioStreamBasicDescription>.size)
        guard AudioObjectGetPropertyData(tap, &address, 0, nil, &formatSize, &format) == noErr,
              format.mFormatID == kAudioFormatLinearPCM, format.mBitsPerChannel == 32,
              format.mFormatFlags & kAudioFormatFlagIsFloat != 0 else {
            stop()
            return false
        }
        let sampleRate = format.mSampleRate
        meter = AudioBands()
        windowCount = 0
        let status = AudioDeviceCreateIOProcIDWithBlock(&callback, device, callbackQueue) { [weak self] _, input, _, _, _ in
            guard let self else { return }
            let buffers = UnsafeMutableAudioBufferListPointer(UnsafeMutablePointer(mutating: input))
            guard let buffer = buffers.first, let data = buffer.mData else { return }
            let count = Int(buffer.mDataByteSize) / MemoryLayout<Float>.stride
            let stride = max(1, Int(buffer.mNumberChannels))
            let samples = UnsafeBufferPointer(start: data.assumingMemoryBound(to: Float.self), count: count)
            let windowSize = window.count
            for frame in 0..<(count / stride) {
                window[windowCount] = samples[frame * stride]
                windowCount += 1
                if windowCount == windowSize {
                    let levels = window.withUnsafeBufferPointer {
                        meter.measure($0, frames: windowSize, stride: 1, sampleRate: sampleRate)
                    }
                    windowCount = 0
                    DispatchQueue.main.async { onLevels(levels) }
                }
            }
        }
        guard status == noErr, let callback, AudioDeviceStart(device, callback) == noErr else {
            stop()
            return false
        }
        return true
    }

    private func stop() {
        if let callback {
            AudioDeviceStop(device, callback)
            AudioDeviceDestroyIOProcID(device, callback)
            self.callback = nil
        }
        if device != kAudioObjectUnknown {
            AudioHardwareDestroyAggregateDevice(device)
            device = kAudioObjectUnknown
        }
        if tap != kAudioObjectUnknown {
            AudioHardwareDestroyProcessTap(tap)
            tap = kAudioObjectUnknown
        }
    }

    private func property(_ selector: AudioObjectPropertySelector) -> AudioObjectPropertyAddress {
        AudioObjectPropertyAddress(mSelector: selector, mScope: kAudioObjectPropertyScopeGlobal,
                                   mElement: kAudioObjectPropertyElementMain)
    }
}
