import IslandLogic
import XCTest

final class IslandLogicTests: XCTestCase {
    func testIncomingControlsAreNotConfusedWithAnActiveCall() {
        XCTAssertEqual(CallRecognition.phase(for: .whatsapp, labels: ["Voice call"], buttons: ["Accept"]),
                       .incoming(.whatsapp))
        XCTAssertEqual(CallRecognition.phase(for: .discord, labels: ["Voice Connected"], buttons: ["Disconnect"]),
                       .connected(.discord))
        XCTAssertEqual(CallRecognition.phase(for: .discord, labels: [], buttons: ["Join Voice Call"]),
                       .idle)
        XCTAssertEqual(CallRecognition.phase(for: .telegram, labels: ["00:23"], buttons: ["End call"]),
                       .connected(.telegram))
    }

    func testTimerUsesMinutesAndHours() {
        XCTAssertEqual(callDuration(0), "00:00")
        XCTAssertEqual(callDuration(61), "01:01")
        XCTAssertEqual(callDuration(3601), "1:00:01")
    }

    func testAudioBandsFollowDifferentFrequencies() {
        let frames = 2048
        let sampleRate = 48_000.0
        func bands(tone: Double) -> [Float] {
            var analyzer = AudioBands()
            let samples: [Float] = (0..<frames).map { index in
                Float(0.4 * sin(2 * .pi * tone * Double(index) / sampleRate))
            }
            return samples.withUnsafeBufferPointer {
                analyzer.measure($0, frames: frames, stride: 1, sampleRate: sampleRate)
            }
        }
        let bass = bands(tone: 68)
        let treble = bands(tone: 4400)
        XCTAssertGreaterThan(bass[0], bass[4] + 0.2)
        XCTAssertGreaterThan(treble[4], treble[0] + 0.2)
    }
}
