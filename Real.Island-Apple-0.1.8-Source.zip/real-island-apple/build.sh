#!/bin/bash
set -euo pipefail

if [[ "$(uname -s)" != Darwin ]]; then
  printf '%s\n' "Для сборки Real.Island Apple нужен Mac с Xcode 26 или новее." >&2
  exit 1
fi

cd "$(dirname "$0")"
sdk="$(xcrun --sdk macosx --show-sdk-version)"
sdk_major="$(printf '%s' "$sdk" | cut -d. -f1)"
if (( sdk_major < 26 )); then
  printf '%s\n' "Выбери Xcode с macOS SDK 26 или новее." >&2
  exit 1
fi

sign_identity="${REAL_ISLAND_SIGN_IDENTITY:-}"
notary_profile="${REAL_ISLAND_NOTARY_PROFILE:-}"
if [[ -n "$notary_profile" && -z "$sign_identity" ]]; then
  printf '%s\n' "Для нотарификации нужна подпись Developer ID Application." >&2
  exit 1
fi

xcrun swift test
xcrun swift build -c release --arch arm64
binary_dir="$(xcrun swift build -c release --arch arm64 --show-bin-path)"
staging="$(mktemp -d)"
trap 'rm -r -- "$staging"' EXIT
app="$staging/Real.Island Apple.app"
mkdir -p "$app/Contents/MacOS" "$app/Contents/Resources" dist
cp Resources/Info.plist "$app/Contents/Info.plist"
/usr/bin/plutil -lint "$app/Contents/Info.plist"
install -m 755 "$binary_dir/RealIslandApple" "$app/Contents/MacOS/RealIslandApple"

if [[ -n "$sign_identity" ]]; then
  codesign --force --options runtime --timestamp --sign "$sign_identity" \
    --entitlements Resources/Entitlements.plist "$app"
else
  codesign --force --sign - --entitlements Resources/Entitlements.plist "$app"
fi
codesign --verify --deep --strict "$app"

ln -s /Applications "$staging/Applications"
image="dist/Real.Island Apple.dmg"
hdiutil create -quiet -ov -format UDZO -volname "Real.Island Apple" -srcfolder "$staging" "$image"
if [[ -n "$sign_identity" ]]; then
  codesign --force --timestamp --sign "$sign_identity" "$image"
fi
if [[ -n "$notary_profile" ]]; then
  xcrun notarytool submit "$image" --keychain-profile "$notary_profile" --wait
  xcrun stapler staple "$image"
  xcrun stapler validate "$image"
  spctl --assess --type open --context context:primary-signature "$image"
else
  printf '%s\n' "Образ собран для тестирования. Нотарификация Apple не выполнена."
fi
printf 'Готовый образ: %s/%s\n' "$PWD" "$image"
