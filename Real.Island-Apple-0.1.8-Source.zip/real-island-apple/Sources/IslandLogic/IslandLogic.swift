import Foundation

public enum Messenger: String, CaseIterable, Sendable {
    case discord = "Discord"
    case telegram = "Telegram"
    case whatsapp = "WhatsApp"
    case facetime = "FaceTime"

    public init?(bundleID: String) {
        let id = bundleID.lowercased()
        if id.hasPrefix("com.hnc.discord") { self = .discord }
        else if ["ru.keepcoder.telegram", "org.telegram.desktop", "com.tdesktop.telegram"].contains(id) { self = .telegram }
        else if id == "net.whatsapp.whatsapp" { self = .whatsapp }
        else if id == "com.apple.facetime" { self = .facetime }
        else { return nil }
    }
}

public enum CallPhase: Equatable, Sendable {
    case idle
    case incoming(Messenger)
    case connected(Messenger)
}

public enum CallRecognition {
    public static func phase(for app: Messenger, labels: [String], buttons: [String]) -> CallPhase {
        let text = Set(labels.map(normalize))
        let controls = Set(buttons.map(normalize))
        let answer: Set<String> = [
            "accept", "accept call", "answer", "answer call", "accept video call",
            "join call", "join voice call", "join video call",
            "принять", "принять звонок", "ответить на звонок", "прийняти", "прийняти дзвінок",
            "присоединиться к звонку", "присоединиться к голосовому звонку"
        ]
        let decline: Set<String> = [
            "decline", "decline call", "reject call", "ignore call", "отклонить",
            "отклонить звонок", "игнорировать звонок", "відхилити", "відхилити дзвінок"
        ]
        let callLabels: Set<String> = [
            "voice call", "video call", "incoming call", "incoming voice call", "incoming video call",
            "голосовой звонок", "входящий звонок", "входящий голосовой звонок", "видеозвонок",
            "вхідний дзвінок", "голосовий дзвінок", "відеодзвінок"
        ]
        let hasAnswer = !controls.isDisjoint(with: answer)
        if hasAnswer && (!controls.isDisjoint(with: decline) ||
                         ((app == .whatsapp || app == .telegram) && !text.isDisjoint(with: callLabels))) {
            return .incoming(app)
        }
        if app == .discord {
            let hangUp: Set<String> = [
                "end call", "leave call", "disconnect from call", "disconnect from voice",
                "завершить звонок", "завершить вызов", "выйти из звонка", "покинуть звонок", "отключиться от звонка",
                "завершити дзвінок", "вийти з дзвінка", "anruf beenden"
            ]
            if !controls.isDisjoint(with: hangUp) { return .connected(app) }
            let disconnect: Set<String> = [
                "disconnect", "отключиться", "роз’єднати", "від’єднатися", "trennen"
            ]
            let video: Set<String> = [
                "enable camera", "disable camera", "turn on camera", "turn off camera", "turn on video", "turn off video",
                "включить камеру", "выключить камеру", "включить видео", "выключить видео",
                "увімкнути камеру", "вимкнути камеру", "kamera einschalten", "kamera ausschalten"
            ]
            if !controls.isDisjoint(with: disconnect) && !controls.isDisjoint(with: video) { return .connected(app) }
        }
        let hasEnd = !controls.isDisjoint(with: [
            "end call", "hang up", "disconnect", "disconnect from voice", "leave call",
            "завершить звонок", "завершить вызов", "отключиться", "повесить трубку",
            "завершити дзвінок", "роз’єднатися"
        ])
        let hasConnection = !text.isDisjoint(with: [
            "voice connected", "voice connected (rtc)", "call connected", "connected",
            "голосовая связь подключена", "подключено к голосовому каналу",
            "голосове з’єднання", "в звонке", "у дзвінку"
        ]) || (app != .discord && text.contains(where: isDuration))
        return hasEnd && hasConnection ? .connected(app) : .idle
    }

    private static func normalize(_ text: String) -> String {
        text.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
    }

    private static func isDuration(_ text: String) -> Bool {
        let parts = text.split(separator: ":", omittingEmptySubsequences: false)
        return (2...3).contains(parts.count) && parts.last?.count == 2 &&
            parts.allSatisfy { !$0.isEmpty && $0.allSatisfy(\.isNumber) }
    }
}

public func callDuration(_ seconds: Int) -> String {
    let total = max(0, seconds)
    if total >= 3600 { return String(format: "%d:%02d:%02d", total / 3600, total / 60 % 60, total % 60) }
    return String(format: "%02d:%02d", total / 60, total % 60)
}

public struct AudioBands {
    private var smooth = Array(repeating: Float(0), count: 5)
    private var headroom = Array(repeating: Float(0.018), count: 5)
    private var weights: [Float] = []
    private var coefficients: [Float] = []
    private var format = (sampleRate: 0.0, frames: 0)
    private let centers: [[Double]] = [[48, 68, 90], [114, 158, 225], [300, 440, 650],
                                       [900, 1400, 2000], [2800, 4400, 6800]]

    public init() {}

    public mutating func measure(_ samples: UnsafeBufferPointer<Float>, frames: Int, stride: Int,
                                 sampleRate: Double) -> [Float] {
        let count = min(frames, 2048)
        guard stride > 0, count >= 128, (count - 1) * stride < samples.count, sampleRate > 0 else { return smooth }
        if format != (sampleRate, count) {
            format = (sampleRate, count)
            weights = (0..<count).map { Float(0.5 - 0.5 * cos(2 * .pi * Double($0) / Double(count - 1))) }
            coefficients = centers.flatMap { $0 }.map { Float(2 * cos(2 * .pi * $0 / sampleRate)) }
        }
        for band in centers.indices {
            var energy: Float = 0
            for coefficient in coefficients[(band * 3)..<(band * 3 + 3)] {
                var previous: Float = 0
                var beforePrevious: Float = 0
                for frame in 0..<count {
                    let next = samples[frame * stride] * weights[frame] + coefficient * previous - beforePrevious
                    beforePrevious = previous
                    previous = next
                }
                energy += max(0, previous * previous + beforePrevious * beforePrevious -
                              coefficient * previous * beforePrevious)
            }
            let magnitude = sqrt(energy / 3) / Float(count)
            headroom[band] = max(0.018, magnitude, headroom[band] * 0.993)
            let relative = magnitude / (headroom[band] * 0.72)
            let target: Float = magnitude < 0.0002 ? 0 : relative / (0.38 + relative)
            smooth[band] += (target - smooth[band]) * (target > smooth[band] ? 0.63 : 0.26)
        }
        return smooth
    }
}
