import AppKit
import ApplicationServices
import IslandLogic

enum CallWindows {
    static func requestAccess() -> Bool {
        let key = kAXTrustedCheckOptionPrompt.takeUnretainedValue() as String
        return AXIsProcessTrustedWithOptions([key: true] as CFDictionary)
    }

    static func read() -> CallPhase {
        guard AXIsProcessTrusted() else { return .idle }
        var connected: CallPhase = .idle
        for app in NSWorkspace.shared.runningApplications {
            guard let id = app.bundleIdentifier, let messenger = Messenger(bundleID: id) else { continue }
            let root = AXUIElementCreateApplication(app.processIdentifier)
            AXUIElementSetMessagingTimeout(root, 0.15)
            for window in elements(root, kAXWindowsAttribute) {
                let match = classify(window, messenger: messenger)
                if case .incoming = match { return match }
                if match != .idle { connected = match }
            }
        }
        return connected
    }

    private static func classify(_ window: AXUIElement, messenger: Messenger) -> CallPhase {
        let started = ProcessInfo.processInfo.systemUptime
        let maximumNodes = 210
        var pending = [window]
        var index = 0
        var labels = [String]()
        var buttons = [String]()
        while index < pending.count && index < maximumNodes &&
                ProcessInfo.processInfo.systemUptime - started < 0.30 {
            let item = pending[index]
            index += 1
            let role = attribute(item, kAXRoleAttribute) as? String
            let names = [kAXTitleAttribute, kAXDescriptionAttribute, kAXHelpAttribute].compactMap {
                attribute(item, $0) as? String
            }
            if role == kAXButtonRole || role == kAXCheckBoxRole {
                buttons.append(contentsOf: names)
            }
            if role == kAXStaticTextRole || role == "AXHeading" {
                labels.append(contentsOf: names)
                if let value = attribute(item, kAXValueAttribute) as? String { labels.append(value) }
            }
            if pending.count < maximumNodes {
                pending.append(contentsOf: elements(item, kAXChildrenAttribute).prefix(maximumNodes - pending.count))
            }
        }
        return CallRecognition.phase(for: messenger, labels: labels, buttons: buttons)
    }

    private static func elements(_ item: AXUIElement, _ key: String) -> [AXUIElement] {
        attribute(item, key) as? [AXUIElement] ?? []
    }

    private static func attribute(_ item: AXUIElement, _ key: String) -> CFTypeRef? {
        var value: CFTypeRef?
        return AXUIElementCopyAttributeValue(item, key as CFString, &value) == .success ? value : nil
    }
}
