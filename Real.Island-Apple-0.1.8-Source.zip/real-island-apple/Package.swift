// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "RealIslandApple",
    platforms: [.macOS(.v15)],
    targets: [
        .target(name: "IslandLogic"),
        .executableTarget(name: "RealIslandApple", dependencies: ["IslandLogic"]),
        .testTarget(name: "IslandLogicTests", dependencies: ["IslandLogic"])
    ],
    swiftLanguageModes: [.v5]
)
