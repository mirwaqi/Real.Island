using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Windows.Storage.Streams;
using System.Threading.Tasks;
using Windows.UI.Notifications;
using Windows.UI.Notifications.Management;

namespace IslandDesktop
{
    internal sealed class IslandNotice
    {
        public string App, Title, Body;
        public BitmapSource Icon;
    }

    internal sealed class NoticeMonitor
    {
        private readonly HashSet<uint> seen = new HashSet<uint>();
        private bool initialized;

        public bool Enabled { get; private set; }

        public async Task<bool> Enable()
        {
            var listener = UserNotificationListener.Current;
            if (await MediaSession.Read<UserNotificationListenerAccessStatus>(listener.RequestAccessAsync()) !=
                UserNotificationListenerAccessStatus.Allowed) return false;
            var snapshot = await Read(listener);
            seen.Clear();
            foreach (var item in snapshot) seen.Add(item.Id);
            initialized = Enabled = true;
            return true;
        }

        public void Resume()
        {
            if (Enabled) return;
            Enabled = UserNotificationListener.Current.GetAccessStatus() == UserNotificationListenerAccessStatus.Allowed;
        }

        public void Disable()
        {
            Enabled = initialized = false;
            seen.Clear();
        }

        public async Task<IslandNotice> Refresh()
        {
            var listener = UserNotificationListener.Current;
            if (listener.GetAccessStatus() != UserNotificationListenerAccessStatus.Allowed)
            {
                Disable();
                return null;
            }
            var snapshot = await Read(listener);
            if (!Enabled) return null;
            var latest = snapshot.Where(n => (!initialized || !seen.Contains(n.Id)) &&
                DateTimeOffset.Now - n.CreationTime < TimeSpan.FromSeconds(15))
                .OrderByDescending(n => n.CreationTime).FirstOrDefault();
            seen.Clear();
            foreach (var item in snapshot) seen.Add(item.Id);
            initialized = true;
            if (latest == null) return null;
            var display = latest.AppInfo.DisplayInfo;
            var binding = latest.Notification.Visual.GetBinding(KnownNotificationBindings.ToastGeneric);
            var lines = binding == null ? new string[0] : binding.GetTextElements().Select(line => line.Text).ToArray();
            var result = new IslandNotice {
                App = display.DisplayName, Title = lines.FirstOrDefault() ?? "Новое уведомление",
                Body = string.Join(" ", lines.Skip(1))
            };
            try
            {
                var reference = display.GetLogo(new Windows.Foundation.Size(80, 80));
                using (var data = await MediaSession.Read<IRandomAccessStreamWithContentType>(reference.OpenReadAsync()))
                    result.Icon = TrimIconPadding(MediaSession.DecodeImage(data, 96));
            }
            catch (Exception) { }
            return result;
        }

        internal static BitmapSource TrimIconPadding(BitmapSource image)
        {
            var argb = new FormatConvertedBitmap(image, PixelFormats.Bgra32, null, 0);
            int stride = argb.PixelWidth * 4;
            var pixels = new byte[stride * argb.PixelHeight];
            argb.CopyPixels(pixels, stride, 0);
            int left = argb.PixelWidth, right = -1, top = argb.PixelHeight, bottom = -1;
            for (int y = 0; y < argb.PixelHeight; y++)
                for (int x = 0; x < argb.PixelWidth; x++)
                {
                    if (pixels[y * stride + 4 * x + 3] < 32) continue;
                    left = Math.Min(left, x);
                    right = Math.Max(right, x);
                    top = Math.Min(top, y);
                    bottom = Math.Max(bottom, y);
                }
            if (right < left || bottom < top) return image;
            // Keep a small antialiasing margin while discarding the asset's empty border.
            left = Math.Max(0, left - 1);
            top = Math.Max(0, top - 1);
            right = Math.Min(argb.PixelWidth - 1, right + 1);
            bottom = Math.Min(argb.PixelHeight - 1, bottom + 1);
            var crop = new CroppedBitmap(image, new Int32Rect(left, top, right - left + 1, bottom - top + 1));
            crop.Freeze();
            return crop;
        }

        private static Task<IReadOnlyList<UserNotification>> Read(UserNotificationListener listener)
        {
            return MediaSession.Read<IReadOnlyList<UserNotification>>(listener.GetNotificationsAsync(NotificationKinds.Toast));
        }
    }
}

