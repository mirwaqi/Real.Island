using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Windows.Storage.Streams;
using System.Threading.Tasks;
using Windows.UI.Notifications;
using Windows.UI.Notifications.Management;

namespace IslandDesktop
{
    internal sealed class IslandNotice
    {
        public string App, Title, Body;
        public string[] BodyLines;
        public BitmapSource Icon;
        public bool FromWindows;
        public bool Weather;
        public bool Reminder;
        public bool IncomingCall;
        public bool MissedCall;
        public string Symbol;
        public bool CanReply { get { return FromWindows && !IncomingCall && !MissedCall && MediaSession.IsCallSource(App ?? ""); } }
    }

    internal sealed class NoticeMonitor
    {
        private static readonly Lazy<BitmapSource> telegramLogo = new Lazy<BitmapSource>(() => {
            using (var resource = typeof(NoticeMonitor).Assembly.GetManifestResourceStream("Telegram.png"))
            {
                var logo = BitmapFrame.Create(resource, BitmapCreateOptions.None, BitmapCacheOption.OnLoad);
                logo.Freeze();
                return logo;
            }
        });
        private readonly Dictionary<uint, DateTimeOffset> seen = new Dictionary<uint, DateTimeOffset>();
        private readonly ConcurrentQueue<UserNotification> incoming = new ConcurrentQueue<UserNotification>();
        private readonly Queue<UserNotification> pending = new Queue<UserNotification>();
        private UserNotificationListener subscribed;
        private DateTimeOffset nextSnapshot;

        public bool Enabled { get; private set; }

        public bool AccessDenied
        {
            get { return UserNotificationListener.Current.GetAccessStatus() == UserNotificationListenerAccessStatus.Denied; }
        }

        public bool CanPrompt
        {
            get { return UserNotificationListener.Current.GetAccessStatus() == UserNotificationListenerAccessStatus.Unspecified; }
        }

        public async Task<bool> Enable()
        {
            if (!await RequestSystemAccess()) return false;
            Resume();
            return Enabled;
        }

        public static async Task<bool> RequestSystemAccess()
        {
            var listener = UserNotificationListener.Current;
            var current = listener.GetAccessStatus();
            if (current == UserNotificationListenerAccessStatus.Allowed) return true;
            if (current == UserNotificationListenerAccessStatus.Unspecified)
                current = await MediaSession.Read<UserNotificationListenerAccessStatus>(listener.RequestAccessAsync());
            if (current == UserNotificationListenerAccessStatus.Denied)
                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("ms-settings:privacy-notifications") { UseShellExecute = true });
            return current == UserNotificationListenerAccessStatus.Allowed;
        }

        public void Resume()
        {
            if (Enabled) return;
            var listener = UserNotificationListener.Current;
            if (listener.GetAccessStatus() != UserNotificationListenerAccessStatus.Allowed) return;
            try
            {
                listener.NotificationChanged += OnNotificationChanged;
                subscribed = listener;
            }
            catch (Exception) { }
            nextSnapshot = DateTimeOffset.MinValue;
            Enabled = true;
        }

        private void OnNotificationChanged(UserNotificationListener sender, UserNotificationChangedEventArgs args)
        {
            if (args.ChangeKind != UserNotificationChangedKind.Added) return;
            try
            {
                var item = sender.GetNotification(args.UserNotificationId);
                if (item != null) incoming.Enqueue(item);
            }
            catch (Exception) { }
        }

        public void Disable()
        {
            Enabled = false;
            if (subscribed != null)
            {
                try { subscribed.NotificationChanged -= OnNotificationChanged; }
                catch (Exception) { }
            }
            subscribed = null;
            pending.Clear();
            UserNotification ignored;
            while (incoming.TryDequeue(out ignored)) { }
            seen.Clear();
        }

        public async Task<IslandNotice> Refresh()
        {
            var listener = UserNotificationListener.Current;
            if (listener.GetAccessStatus() != UserNotificationListenerAccessStatus.Allowed)
            {
                Disable();
                return null;
            }
            DateTimeOffset now = DateTimeOffset.UtcNow;
            UserNotification queued;
            while (incoming.TryDequeue(out queued)) Enqueue(queued, now);
            if (now >= nextSnapshot)
            {
                nextSnapshot = now.AddSeconds(subscribed == null ? 1 : 3);
                IReadOnlyList<UserNotification> snapshot;
                try { snapshot = await Read(listener); }
                catch (Exception) { snapshot = new UserNotification[0]; }
                if (!Enabled) return null;
                foreach (var item in snapshot.OrderBy(n => n.CreationTime)) Enqueue(item, now);
                foreach (uint old in seen.Where(item => now - item.Value > TimeSpan.FromMinutes(3)).Select(item => item.Key).ToArray())
                    seen.Remove(old);
            }
            while (pending.Count > 0 && now - pending.Peek().CreationTime > TimeSpan.FromMinutes(2)) pending.Dequeue();
            if (pending.Count == 0) return null;
            var latest = pending.Dequeue();
            var display = latest.AppInfo.DisplayInfo;
            var visual = latest.Notification.Visual;
            var binding = visual.GetBinding(KnownNotificationBindings.ToastGeneric) ?? visual.Bindings.FirstOrDefault();
            var lines = binding == null ? new string[0] : binding.GetTextElements()
                .Select(line => (line.Text ?? "").Trim()).Where(line => line.Length != 0).ToArray();
            var result = new IslandNotice {
                App = display.DisplayName, Title = lines.FirstOrDefault() ?? "Новое уведомление",
                Body = string.Join(" ", lines.Skip(1)), BodyLines = lines.Skip(1).ToArray(), FromWindows = true
            };
            result.IncomingCall = IsIncomingCall(result.App, lines);
            result.MissedCall = MediaSession.IsCallSource(result.App ?? "") && lines.Any(IsMissedCall);
            result.Icon = MessengerLogo(result.App);
            if (result.Icon != null) return result;
            try
            {
                var reference = display.GetLogo(new Windows.Foundation.Size(80, 80));
                var stream = MediaSession.Read<IRandomAccessStreamWithContentType>(reference.OpenReadAsync());
                if (await Task.WhenAny(stream, Task.Delay(250)) == stream)
                {
                    using (var data = await stream) result.Icon = TrimIconPadding(MediaSession.DecodeImage(data, 96));
                }
                else
                {
                    DisposeLateIcon(stream);
                }
            }
            catch (Exception) { }
            return result;
        }

        internal static BitmapSource MessengerLogo(string app)
        {
            return string.Equals(app, "Telegram", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(app, "Telegram Desktop", StringComparison.OrdinalIgnoreCase) ? telegramLogo.Value : null;
        }

        internal static bool IsIncomingCall(string source, IEnumerable<string> lines)
        {
            if (!MediaSession.IsCallSource(source ?? "")) return false;
            string[] invitations = { "incoming call", "incoming voice call", "incoming video call", "incoming audio call",
                "входящий звонок", "входящий вызов", "входящий видеозвонок", "вхідний дзвінок",
                "входящий аудиозвонок", "вхідний виклик", "вхідний відеодзвінок", "вхідний голосовий дзвінок",
                "anruf von", "eingehender anruf",
                "is calling you", "звонит вам", "телефонує вам", "голосовой вызов",
                "входящий голосовой звонок" };
            var textLines = lines.Select(line => (line ?? "").Trim().TrimEnd('.', '…', '!', ':').TrimEnd()).ToArray();
            if (textLines.Any(IsMissedCall)) return false;
            if (textLines.Any(text => invitations.Any(phrase =>
                string.Equals(text, phrase, StringComparison.OrdinalIgnoreCase) ||
                text.StartsWith(phrase + " ", StringComparison.OrdinalIgnoreCase) ||
                text.StartsWith(phrase + ":", StringComparison.OrdinalIgnoreCase) ||
                text.EndsWith(" " + phrase, StringComparison.OrdinalIgnoreCase)))) return true;
            if (source.IndexOf("Discord", StringComparison.OrdinalIgnoreCase) < 0) return false;
            string[] discordCallEndings = { "starts a call", "started a call", "is starting a call", "начинает звонок",
                "начал звонок", "начала звонок", "начал(а) звонок", "починає дзвінок", "розпочинає дзвінок" };
            return textLines.Any(text => discordCallEndings.Any(phrase =>
                string.Equals(text, phrase, StringComparison.OrdinalIgnoreCase) ||
                text.EndsWith(" " + phrase, StringComparison.OrdinalIgnoreCase)));
        }

        private static bool IsMissedCall(string line)
        {
            return new[] { "пропущенный звонок", "пропущенный голосовой звонок", "пропущенный видеозвонок",
                "вы пропустили звонок", "missed call", "missed voice call", "missed video call",
                "you missed a call", "пропущений дзвінок", "verpasster anruf" }
                .Any(phrase => line.StartsWith(phrase, StringComparison.OrdinalIgnoreCase));
        }

        private static async void DisposeLateIcon(Task<IRandomAccessStreamWithContentType> stream)
        {
            try { using (await stream.ConfigureAwait(false)) { } }
            catch (Exception) { }
        }

        private void Enqueue(UserNotification item, DateTimeOffset now)
        {
            if (now - item.CreationTime > TimeSpan.FromSeconds(30)) return;
            DateTimeOffset previous;
            if (seen.TryGetValue(item.Id, out previous) && previous == item.CreationTime) return;
            seen[item.Id] = item.CreationTime;
            if (pending.Count >= 20) pending.Dequeue();
            pending.Enqueue(item);
        }

        internal static BitmapSource TrimIconPadding(BitmapSource image)
        {
            var argb = new FormatConvertedBitmap(image, PixelFormats.Bgra32, null, 0);
            int stride = argb.PixelWidth * 4;
            var pixels = new byte[stride * argb.PixelHeight];
            argb.CopyPixels(pixels, stride, 0);
            int left = argb.PixelWidth, right = -1, top = argb.PixelHeight, bottom = -1;
            for (int y = 0; y < argb.PixelHeight; y++)
                for (int x = 0; x < argb.PixelWidth; x++)
                {
                    if (pixels[y * stride + 4 * x + 3] < 32) continue;
                    left = Math.Min(left, x);
                    right = Math.Max(right, x);
                    top = Math.Min(top, y);
                    bottom = Math.Max(bottom, y);
                }
            if (right < left || bottom < top) return image;
            // Keep a small antialiasing margin while discarding the asset's empty border.
            left = Math.Max(0, left - 1);
            top = Math.Max(0, top - 1);
            right = Math.Min(argb.PixelWidth - 1, right + 1);
            bottom = Math.Min(argb.PixelHeight - 1, bottom + 1);
            var crop = new CroppedBitmap(image, new Int32Rect(left, top, right - left + 1, bottom - top + 1));
            crop.Freeze();
            return crop;
        }

        private static Task<IReadOnlyList<UserNotification>> Read(UserNotificationListener listener)
        {
            return MediaSession.Read<IReadOnlyList<UserNotification>>(listener.GetNotificationsAsync(NotificationKinds.Toast));
        }
    }
}

