using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Forms = System.Windows.Forms;
using Drawing = System.Drawing;

namespace IslandDesktop
{
    internal static class WindowsIntegration
    {
        [StructLayout(LayoutKind.Sequential)]
        private struct Rect { public int Left, Top, Right, Bottom; }

        [DllImport("user32.dll")] private static extern bool GetWindowRect(IntPtr window, out Rect rect);
        [DllImport("user32.dll")] private static extern IntPtr GetForegroundWindow();
        [DllImport("user32.dll")] private static extern IntPtr GetShellWindow();
        [DllImport("user32.dll")] private static extern uint GetWindowThreadProcessId(IntPtr window, out uint process);
        [DllImport("user32.dll")] private static extern bool SetWindowPos(IntPtr window, IntPtr after, int x, int y, int width, int height, uint flags);
        [DllImport("user32.dll")] private static extern IntPtr GetDC(IntPtr window);
        [DllImport("user32.dll")] private static extern int ReleaseDC(IntPtr window, IntPtr dc);
        [DllImport("gdi32.dll")] private static extern uint GetPixel(IntPtr dc, int x, int y);
        [DllImport("user32.dll")] private static extern void keybd_event(byte key, byte scan, uint flags, UIntPtr extra);

        public static void MediaKey(byte key)
        {
            keybd_event(key, 0, 0, UIntPtr.Zero);
            keybd_event(key, 0, 2, UIntPtr.Zero);
        }

        public static void OpenNotificationCenter()
        {
            const byte windowsKey = 0x5B;
            byte shortcut = Environment.OSVersion.Version.Build >= 22000 ? (byte)0x4E : (byte)0x41;
            keybd_event(windowsKey, 0, 0, UIntPtr.Zero);
            try { MediaKey(shortcut); }
            finally { keybd_event(windowsKey, 0, 2, UIntPtr.Zero); }
        }

        [DllImport("user32.dll")] private static extern bool IsZoomed(IntPtr window);
        [DllImport("user32.dll")] private static extern IntPtr GetWindow(IntPtr window, uint command);
        [DllImport("user32.dll")] private static extern bool IsWindowVisible(IntPtr window);
        [DllImport("dwmapi.dll")] private static extern int DwmGetWindowAttribute(IntPtr window, uint attribute, out Rect value, int size);

        [DllImport("user32.dll", EntryPoint="SetWindowLongW")] private static extern int SetWindowLong(IntPtr window, int index, int value);
        [DllImport("user32.dll")] private static extern bool RegisterHotKey(IntPtr window, int id, uint modifiers, uint key);
        [DllImport("user32.dll")] private static extern bool UnregisterHotKey(IntPtr window, int id);

        public static Action InstallIslandShortcut(Window window, Action open)
        {
            var source = (HwndSource)PresentationSource.FromVisual(window);
            IntPtr hwnd = source.Handle;
            const int id = 0x4953;
            if (!RegisterHotKey(hwnd, id, 0x4000 | 1 | 2, 0x49)) return null;
            source.AddHook(delegate(IntPtr handle, int message, IntPtr wParam, IntPtr lParam, ref bool handled) {
                if (message == 0x0312 && wParam.ToInt32() == id)
                {
                    handled = true;
                    open();
                }
                return IntPtr.Zero;
            });
            return () => UnregisterHotKey(hwnd, id);
        }

        public static void SetClickThrough(Window window, bool enabled)
        {
            IntPtr hwnd = new WindowInteropHelper(window).Handle;
            if (hwnd == IntPtr.Zero) return;
            int style = GetWindowLong(hwnd, -20);
            int next = enabled ? style | 0x20 : style & ~0x20;
            if (next != style) SetWindowLong(hwnd, -20, next);
        }

        public static bool ForegroundExcluded(Preferences preferences)
        {
            if (preferences.ExcludedApps.Count == 0) return false;
            uint pid;
            GetWindowThreadProcessId(GetForegroundWindow(), out pid);
            if (pid == 0 || pid == App.ProcessId) return false;
            try
            {
                using (var process = Process.GetProcessById((int)pid))
                    return preferences.ExcludedApps.Contains(process.ProcessName);
            }
            catch (ArgumentException) { return false; }
            catch (InvalidOperationException) { return false; }
        }

        public static void KeepAbove(Window window, IntPtr fullscreen)
        {
            IntPtr hwnd = new WindowInteropHelper(window).Handle;
            if (hwnd == IntPtr.Zero || GetForegroundWindow() == hwnd) return;

            bool raise = (GetWindowLong(hwnd, -20) & 8) == 0;
            for (IntPtr above = GetWindow(hwnd, 3); !raise && above != IntPtr.Zero; above = GetWindow(above, 3))
            {
                if ((GetWindowLong(above, -20) & 8) == 0) break;
                if (!IsWindowVisible(above)) continue;
                uint process;
                GetWindowThreadProcessId(above, out process);
                if (process == App.ProcessId) return;
                if (above == fullscreen) raise = true;
            }
            if (raise) SetWindowPos(hwnd, new IntPtr(-1), 0, 0, 0, 0, 0x0010 | 0x0002 | 0x0001 | 0x0200);
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct WindowPosition
        {
            public IntPtr Hwnd, After;
            public int X, Y, Width, Height;
            public uint Flags;
        }

        private static int CenteredPixels(int pixels)
        {
            // An even width prevents alternate half-pixel origins during animation.
            return Math.Max(2, (int)(Math.Round(pixels / 2d) * 2));
        }

        public static double CenteredVisualWidth(Window window, double width)
        {
            double scale = VisualTreeHelper.GetDpi(window).DpiScaleX;
            return CenteredPixels((int)Math.Round(width * scale)) / scale;
        }

        public static void CenterOnResize(Window window, Func<IntPtr> fullscreen)
        {
            IntPtr hwnd = new WindowInteropHelper(window).Handle;
            var source = HwndSource.FromHwnd(hwnd);
            source.AddHook(delegate(IntPtr handle, int message, IntPtr wParam, IntPtr lParam, ref bool handled) {
                if (message != 0x0046 || lParam == IntPtr.Zero || source.CompositionTarget == null) return IntPtr.Zero;
                var position = (WindowPosition)Marshal.PtrToStructure(lParam, typeof(WindowPosition));
                if ((position.Flags & 1) != 0 || position.Width <= 0) return IntPtr.Zero;
                position.Width = CenteredPixels(position.Width);
                var point = IslandPosition(position.Width, fullscreen());
                position.X = point.X;
                position.Y = point.Y;
                position.Flags &= ~2u;
                Marshal.StructureToPtr(position, lParam, false);
                return IntPtr.Zero;
            });
        }

        private static Drawing.Point IslandPosition(int width, IntPtr fullscreen)
        {
            Forms.Screen screen = fullscreen == IntPtr.Zero ? Forms.Screen.PrimaryScreen : Forms.Screen.FromHandle(fullscreen);
            int top = fullscreen == IntPtr.Zero ? screen.WorkingArea.Top : screen.Bounds.Top;
            return new Drawing.Point(screen.Bounds.Left + (screen.Bounds.Width - width) / 2, top);
        }

        public static void Place(Window window, IntPtr fullscreen)
        {
            IntPtr hwnd = new WindowInteropHelper(window).Handle;
            Rect rect;
            if (hwnd == IntPtr.Zero || !GetWindowRect(hwnd, out rect)) return;
            var point = IslandPosition(rect.Right - rect.Left, fullscreen);
            if (rect.Left == point.X && rect.Top == point.Y) return;
            SetWindowPos(hwnd, IntPtr.Zero, point.X, point.Y, 0, 0, 0x0010 | 0x0004 | 0x0200 | 0x0001);
        }

        public static IntPtr FullscreenWindow()
        {
            IntPtr active = GetForegroundWindow();
            if (active == IntPtr.Zero || active == GetShellWindow() || IsZoomed(active)) return IntPtr.Zero;
            uint process;
            GetWindowThreadProcessId(active, out process);
            if (process == App.ProcessId) return IntPtr.Zero;
            Rect r;
            if (DwmGetWindowAttribute(active, 9, out r, Marshal.SizeOf(typeof(Rect))) < 0 &&
                !GetWindowRect(active, out r)) return IntPtr.Zero;
            Drawing.Rectangle screen = Forms.Screen.FromHandle(active).Bounds;
            bool coversScreen = r.Left <= screen.Left + 2 && r.Top <= screen.Top + 2 &&
                r.Right >= screen.Right - 2 && r.Bottom >= screen.Bottom - 2;
            return coversScreen ? active : IntPtr.Zero;
        }

        [DllImport("user32.dll", EntryPoint="GetWindowLongW")] private static extern int GetWindowLong(IntPtr window, int index);


        public static BitmapSource GlassBackdrop(IntPtr hwnd, int horizontalInset, int topInset, int bottomInset, out bool dark)
        {
            dark = true;
            Rect r;
            if (!GetWindowRect(hwnd, out r)) return null;
            r.Left += horizontalInset;
            r.Right -= horizontalInset;
            r.Top += topInset;
            r.Bottom -= bottomInset;
            Drawing.Rectangle screen = Forms.Screen.FromHandle(hwnd).Bounds;
            int left = Math.Max(r.Left, screen.Left);
            int right = Math.Min(r.Right, screen.Right);
            int top = Math.Max(r.Top, screen.Top);
            int bottom = Math.Min(r.Bottom, screen.Bottom);
            if (right <= left || bottom <= top) return null;
            dark = DarkBehind(r, screen);

            int sourceWidth = right - left, sourceHeight = bottom - top;
            // Sample below the native window so the glass cannot contain a second copy of the clock.
            int captureTop = bottom + bottomInset + 2;
            if (captureTop >= screen.Bottom) return null;
            sourceHeight = Math.Min(sourceHeight, screen.Bottom - captureTop);
            int width = Math.Min(44, Math.Max(1, sourceWidth / 11));
            int height = Math.Max(1, (int)Math.Round(sourceHeight * width / (double)sourceWidth));
            var pixels = new int[width * height];
            using (var source = new Drawing.Bitmap(sourceWidth, sourceHeight, Drawing.Imaging.PixelFormat.Format32bppRgb))
            using (var reduced = new Drawing.Bitmap(width, height, Drawing.Imaging.PixelFormat.Format32bppRgb))
            {
                using (var graphics = Drawing.Graphics.FromImage(source))
                    graphics.CopyFromScreen(left, captureTop, 0, 0, source.Size, Drawing.CopyPixelOperation.SourceCopy);
                using (var graphics = Drawing.Graphics.FromImage(reduced))
                {
                    graphics.InterpolationMode = Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                    graphics.PixelOffsetMode = Drawing.Drawing2D.PixelOffsetMode.HighQuality;
                    graphics.DrawImage(source, new Drawing.Rectangle(0, 0, width, height));
                }
                var data = reduced.LockBits(new Drawing.Rectangle(0, 0, width, height),
                    Drawing.Imaging.ImageLockMode.ReadOnly, Drawing.Imaging.PixelFormat.Format32bppRgb);
                try { Marshal.Copy(data.Scan0, pixels, 0, pixels.Length); }
                finally { reduced.UnlockBits(data); }
            }

            var refracted = new int[pixels.Length];
            var horizontal = GlassRefraction(width);
            var vertical = GlassRefraction(height);
            for (int y = 0; y < height; y++)
                for (int x = 0; x < width; x++)
                    refracted[y * width + x] = pixels[vertical[y] * width + horizontal[x]];

            var image = BitmapSource.Create(width, height, 96, 96, PixelFormats.Bgr32, null, refracted, width * 4);
            image.Freeze();
            return image;
        }

        private static int[] GlassRefraction(int length)
        {
            var map = new int[length];
            double band = Math.Min(12, length / 3d);
            for (int i = 0; i < length; i++)
            {
                int edge = Math.Min(i, length - 1 - i);
                double lens = Math.Max(0, 1 - edge / band);
                int offset = (int)Math.Round(band * .6 * lens * lens);
                map[i] = i < length / 2d ? i + offset : i - offset;
            }
            return map;
        }

        private static bool DarkBehind(Rect r, Drawing.Rectangle screen)
        {
            IntPtr dc = GetDC(IntPtr.Zero);
            if (dc == IntPtr.Zero) return true;
            try
            {
                int y = Math.Max(screen.Top, r.Top - 3);
                int middle = r.Top + (r.Bottom - r.Top) / 2;
                int seen = 0;
                int dark = 0;
                for (int i = 1; i <= 7; i++)
                {
                    int x = r.Left + (r.Right - r.Left) * i / 8;
                    SamplePixel(dc, x, y, ref seen, ref dark);
                }
                SamplePixel(dc, Math.Max(screen.Left, r.Left - 3), middle, ref seen, ref dark);
                SamplePixel(dc, Math.Min(screen.Right - 1, r.Right + 2), middle, ref seen, ref dark);
                return seen == 0 || dark >= (seen + 1) / 2;
            }
            finally { ReleaseDC(IntPtr.Zero, dc); }
        }

        private static void SamplePixel(IntPtr dc, int x, int y, ref int seen, ref int dark)
        {
            uint color = GetPixel(dc, x, y);
            if (color == uint.MaxValue) return;
            seen++;
            uint luma = 54 * (color & 255) + 183 * ((color >> 8) & 255) + 19 * ((color >> 16) & 255);
            if (luma < 64 * 256) dark++;
        }

        [ComImport, Guid("B92B56A9-8B55-4E14-9A89-0199BBB6F93B"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        private interface IDesktopWallpaper
        {
            void SetWallpaper([MarshalAs(UnmanagedType.LPWStr)] string monitorId, [MarshalAs(UnmanagedType.LPWStr)] string path);
        }

        public static void SetWallpaper(string path)
        {
            Guid clsid = new Guid("C2CF3110-460E-4FC1-B9D0-8A1C0C9CC4BD");
            object instance = Activator.CreateInstance(Type.GetTypeFromCLSID(clsid, true));
            try { ((IDesktopWallpaper)instance).SetWallpaper(null, path); }
            finally { Marshal.ReleaseComObject(instance); }
        }
    }
}









