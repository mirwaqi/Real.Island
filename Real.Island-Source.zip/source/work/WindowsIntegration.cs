using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Forms = System.Windows.Forms;
using Drawing = System.Drawing;

namespace IslandDesktop
{
    internal static class WindowsIntegration
    {
        [StructLayout(LayoutKind.Sequential)]
        private struct Rect { public int Left, Top, Right, Bottom; }

        [DllImport("user32.dll")] private static extern bool GetWindowRect(IntPtr window, out Rect rect);
        [DllImport("user32.dll")] private static extern IntPtr GetForegroundWindow();
        [DllImport("user32.dll")] private static extern IntPtr GetShellWindow();
        [DllImport("user32.dll")] private static extern uint GetWindowThreadProcessId(IntPtr window, out uint process);
        [DllImport("user32.dll")] private static extern bool SetWindowPos(IntPtr window, IntPtr after, int x, int y, int width, int height, uint flags);
        [DllImport("user32.dll")] private static extern IntPtr GetDC(IntPtr window);
        [DllImport("user32.dll")] private static extern int ReleaseDC(IntPtr window, IntPtr dc);
        [DllImport("gdi32.dll")] private static extern uint GetPixel(IntPtr dc, int x, int y);
        [DllImport("user32.dll")] private static extern void keybd_event(byte key, byte scan, uint flags, UIntPtr extra);

        public static void MediaKey(byte key)
        {
            keybd_event(key, 0, 0, UIntPtr.Zero);
            keybd_event(key, 0, 2, UIntPtr.Zero);
        }

        [DllImport("user32.dll")] private static extern bool IsZoomed(IntPtr window);
        [DllImport("user32.dll")] private static extern IntPtr GetWindow(IntPtr window, uint command);
        [DllImport("user32.dll")] private static extern bool IsWindowVisible(IntPtr window);
        [DllImport("dwmapi.dll")] private static extern int DwmGetWindowAttribute(IntPtr window, uint attribute, out Rect value, int size);

        public static void KeepAbove(Window window)
        {
            IntPtr hwnd = new WindowInteropHelper(window).Handle;
            if (hwnd == IntPtr.Zero || GetForegroundWindow() == hwnd) return;
            IntPtr previous = GetWindow(hwnd, 3);
            if (previous == IntPtr.Zero || !IsWindowVisible(previous) || (GetWindowLong(previous, -20) & 8) == 0) return;
            uint process;
            GetWindowThreadProcessId(previous, out process);
            if (process == App.ProcessId || (GetWindowLong(previous, -20) & 0x08000000) != 0) return;
            SetWindowPos(hwnd, new IntPtr(-1), 0, 0, 0, 0, 0x0010 | 0x0002 | 0x0001 | 0x0200);
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct WindowPosition
        {
            public IntPtr Hwnd, After;
            public int X, Y, Width, Height;
            public uint Flags;
        }

        private static int CenteredPixels(int pixels)
        {
            // An even width prevents alternate half-pixel origins during animation.
            return Math.Max(2, (int)(Math.Round(pixels / 2d) * 2));
        }

        public static double CenteredVisualWidth(Window window, double width)
        {
            double scale = VisualTreeHelper.GetDpi(window).DpiScaleX;
            return CenteredPixels((int)Math.Round(width * scale)) / scale;
        }

        public static void CenterOnResize(Window window)
        {
            IntPtr hwnd = new WindowInteropHelper(window).Handle;
            var source = HwndSource.FromHwnd(hwnd);
            source.AddHook(delegate(IntPtr handle, int message, IntPtr wParam, IntPtr lParam, ref bool handled) {
                if (message != 0x0046 || lParam == IntPtr.Zero || source.CompositionTarget == null) return IntPtr.Zero;
                var position = (WindowPosition)Marshal.PtrToStructure(lParam, typeof(WindowPosition));
                if ((position.Flags & 1) != 0 || position.Width <= 0) return IntPtr.Zero;
                position.Width = CenteredPixels(position.Width);
                var point = IslandPosition(source, position.Width);
                position.X = point.X;
                position.Y = point.Y;
                position.Flags &= ~2u;
                Marshal.StructureToPtr(position, lParam, false);
                return IntPtr.Zero;
            });
        }

        private static Drawing.Point IslandPosition(HwndSource source, int width)
        {
            Forms.Screen screen = Forms.Screen.PrimaryScreen;
            int inset = (int)Math.Round(9 * source.CompositionTarget.TransformToDevice.M22);
            return new Drawing.Point(screen.Bounds.Left + (screen.Bounds.Width - width) / 2,
                screen.WorkingArea.Top + inset);
        }

        public static void Place(Window window)
        {
            IntPtr hwnd = new WindowInteropHelper(window).Handle;
            Rect rect;
            if (hwnd == IntPtr.Zero || !GetWindowRect(hwnd, out rect)) return;
            var source = HwndSource.FromHwnd(hwnd);
            if (source == null || source.CompositionTarget == null) return;
            var point = IslandPosition(source, rect.Right - rect.Left);
            if (rect.Left == point.X && rect.Top == point.Y) return;
            SetWindowPos(hwnd, IntPtr.Zero, point.X, point.Y, 0, 0, 0x0010 | 0x0004 | 0x0200 | 0x0001);
        }

        public static bool Fullscreen()
        {
            IntPtr active = GetForegroundWindow();
            if (active == IntPtr.Zero || active == GetShellWindow()) return false;
            uint process;
            GetWindowThreadProcessId(active, out process);
            if (process == App.ProcessId) return false;
            if (IsZoomed(active)) return false;
            Rect r;
            if (DwmGetWindowAttribute(active, 9, out r, Marshal.SizeOf(typeof(Rect))) < 0 &&
                !GetWindowRect(active, out r)) return false;
            Drawing.Rectangle screen = Forms.Screen.PrimaryScreen.Bounds;
            return r.Left <= screen.Left + 2 && r.Top <= screen.Top + 2 &&
                r.Right >= screen.Right - 2 && r.Bottom >= screen.Bottom - 2;
        }

        [DllImport("user32.dll", EntryPoint="GetWindowLongW")] private static extern int GetWindowLong(IntPtr window, int index);


        public static bool DarkBehind(IntPtr hwnd)
        {
            Rect r;
            if (!GetWindowRect(hwnd, out r)) return true;
            IntPtr dc = GetDC(IntPtr.Zero);
            if (dc == IntPtr.Zero) return true;
            try
            {
                Drawing.Rectangle screen = Forms.Screen.PrimaryScreen.Bounds;
                int y = Math.Max(screen.Top, r.Top - 3);
                int middle = r.Top + (r.Bottom - r.Top) / 2;
                int seen = 0;
                int dark = 0;
                for (int i = 1; i <= 7; i++)
                {
                    int x = r.Left + (r.Right - r.Left) * i / 8;
                    SamplePixel(dc, x, y, ref seen, ref dark);
                }
                SamplePixel(dc, Math.Max(screen.Left, r.Left - 3), middle, ref seen, ref dark);
                SamplePixel(dc, Math.Min(screen.Right - 1, r.Right + 2), middle, ref seen, ref dark);
                return seen == 0 || dark >= (seen + 1) / 2;
            }
            finally { ReleaseDC(IntPtr.Zero, dc); }
        }

        private static void SamplePixel(IntPtr dc, int x, int y, ref int seen, ref int dark)
        {
            uint color = GetPixel(dc, x, y);
            if (color == uint.MaxValue) return;
            seen++;
            uint luma = 54 * (color & 255) + 183 * ((color >> 8) & 255) + 19 * ((color >> 16) & 255);
            if (luma < 64 * 256) dark++;
        }

        [ComImport, Guid("B92B56A9-8B55-4E14-9A89-0199BBB6F93B"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        private interface IDesktopWallpaper
        {
            void SetWallpaper([MarshalAs(UnmanagedType.LPWStr)] string monitorId, [MarshalAs(UnmanagedType.LPWStr)] string path);
        }

        public static void SetWallpaper(string path)
        {
            Guid clsid = new Guid("C2CF3110-460E-4FC1-B9D0-8A1C0C9CC4BD");
            object instance = Activator.CreateInstance(Type.GetTypeFromCLSID(clsid, true));
            try { ((IDesktopWallpaper)instance).SetWallpaper(null, path); }
            finally { Marshal.ReleaseComObject(instance); }
        }
    }
}







