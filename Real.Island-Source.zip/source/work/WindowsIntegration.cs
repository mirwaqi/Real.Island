using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Forms = System.Windows.Forms;
using Drawing = System.Drawing;

namespace IslandDesktop
{
    internal static class WindowsIntegration
    {
        internal static bool SupportsSavingTrack(Track track)
        {
            return track != null && !string.IsNullOrWhiteSpace(track.Title) &&
                !string.IsNullOrWhiteSpace(track.Artist) &&
                (string.Equals(track.Source, "Spotify.exe", StringComparison.OrdinalIgnoreCase) ||
                 string.Equals(track.Source, "SpotifyAB.SpotifyMusic_zpdnekdrzrea0!Spotify", StringComparison.OrdinalIgnoreCase));
        }

        internal static string SaveSpotifyTrack(Track track)
        {
            if (!SupportsSavingTrack(track)) return "Сохранение недоступно для этого плеера.";
            string result = null;
            var players = Process.GetProcessesByName("Spotify");
            try
            {
                foreach (var player in players)
                {
                    var window = player.MainWindowHandle;
                    if (window == IntPtr.Zero || !IsWindowVisible(window) || IsIconic(window)) continue;
                    var root = AutomationElement.FromHandle(window);
                    if (root == null) continue;
                    var trackNames = root.FindAll(TreeScope.Descendants, new PropertyCondition(AutomationElement.NameProperty, track.Title));
                    foreach (AutomationElement name in trackNames)
                    {
                        var card = TreeWalker.ControlViewWalker.GetParent(name);
                        for (int level = 0; level < 5 && card != null && !card.Equals(root); level++, card = TreeWalker.ControlViewWalker.GetParent(card))
                        {
                            string label = card.Current.Name;
                            if (label != "Now playing bar" && label != "Now Playing" &&
                                label != "Сейчас играет" && label != "Aktuelle Wiedergabe") continue;
                            if (!HasCallControl(card, track.Artist)) break;
                            var buttons = card.FindAll(TreeScope.Descendants, new PropertyCondition(
                                AutomationElement.ControlTypeProperty, ControlType.Button));
                            var save = buttons.Cast<AutomationElement>().Where(button => !button.Current.IsOffscreen &&
                                CanSaveSpotifySong(button.Current.Name)).ToArray();
                            if (save.Length == 1 && save[0].Current.IsEnabled)
                            {
                                object action;
                                if (save[0].TryGetCurrentPattern(InvokePattern.Pattern, out action))
                                {
                                    ((InvokePattern)action).Invoke();
                                    return "Команда сохранения передана Spotify.";
                                }
                            }
                            result = "Spotify не показал кнопку добавления для этого трека.";
                            break;
                        }
                    }
                }
            }
            catch (ElementNotAvailableException) { }
            catch (COMException) { }
            catch (InvalidOperationException) { }
            catch (ArgumentException) { }
            catch (System.ComponentModel.Win32Exception) { }
            finally { foreach (var player in players) player.Dispose(); }
            return result ?? "Открой окно Spotify и попробуй ещё раз.";
        }

        internal static bool CanSaveSpotifySong(string name)
        {
            return name == "Add to Liked Songs" || name == "Save to Your Library" || name == "Add to Your Library" ||
                name == "Добавить в любимые треки" || name == "Добавить в медиатеку" ||
                name == "Zu Lieblingssongs hinzufügen" || name == "Zu deiner Bibliothek hinzufügen";
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct Rect { public int Left, Top, Right, Bottom; }

        [DllImport("user32.dll")] private static extern bool GetWindowRect(IntPtr window, out Rect rect);
        [DllImport("user32.dll")] private static extern IntPtr GetForegroundWindow();
        [DllImport("user32.dll")] private static extern IntPtr GetShellWindow();
        [DllImport("user32.dll")] private static extern uint GetWindowThreadProcessId(IntPtr window, out uint process);
        [DllImport("user32.dll")] private static extern IntPtr GetKeyboardLayout(uint thread);
        private delegate bool WindowVisitor(IntPtr window, IntPtr context);
        [DllImport("user32.dll")] private static extern bool EnumWindows(WindowVisitor visitor, IntPtr context);
        [DllImport("user32.dll")] private static extern bool IsIconic(IntPtr window);

        internal static string IncomingMessengerCall(out bool discordConnected)
        {
            discordConnected = false;
            bool connected = false;
            var apps = Process.GetProcesses();
            try
            {
                var processIds = new System.Collections.Generic.Dictionary<uint, string>();
                foreach (var app in apps)
                {
                    try
                    {
                        if (MediaSession.IsCallSource(app.ProcessName) ||
                            string.Equals(app.ProcessName, "ApplicationFrameHost", StringComparison.OrdinalIgnoreCase))
                            processIds[(uint)app.Id] = app.ProcessName;
                    }
                    catch (InvalidOperationException) { }
                    catch (System.ComponentModel.Win32Exception) { }
                }
                string found = null;
                EnumWindows((window, context) => {
                    uint pid;
                    GetWindowThreadProcessId(window, out pid);
                    string app;
                    if (!processIds.TryGetValue(pid, out app) || !IsWindowVisible(window) || IsIconic(window)) return true;
                    try
                    {
                        var root = AutomationElement.FromHandle(window);
                        if (root == null) return true;
                        if (string.Equals(app, "ApplicationFrameHost", StringComparison.OrdinalIgnoreCase))
                        {
                            if (!IsWhatsAppWindowTitle(root.Current.Name)) return true;
                            app = "WhatsApp";
                        }
                        bool isDiscord = app.StartsWith("Discord", StringComparison.OrdinalIgnoreCase);
                        bool isWhatsApp = app.IndexOf("WhatsApp", StringComparison.OrdinalIgnoreCase) >= 0;
                        bool ringing = (isWhatsApp && IsWhatsAppIncomingCall(names => HasCallControl(root, names))) ||
                            HasCallControl(root, "is calling you...", "is calling you…", "звонит вам…",
                            "звонит вам...", "телефонує вам…", "телефонує вам...", "ruft dich an …") ||
                            (HasCallControl(root, "Decline", "Decline call", "Reject call", "Ignore call", "Отклонить", "Отклонить звонок",
                            "Отклонить вызов", "Игнорировать звонок", "Відхилити", "Відхилити дзвінок", "Ablehnen", "Anruf ablehnen") &&
                            (HasCallControl(root, "Accept call", "Answer call", "Принять звонок", "Принять вызов", "Ответить на звонок",
                                "Прийняти дзвінок", "Anruf annehmen") || (isDiscord &&
                                HasCallControl(root, "Join Call", "Join Voice Call", "Join Video Call", "Присоединиться к звонку",
                                    "Присоединиться к голосовому звонку", "Присоединиться к видеозвонку")) || (!isDiscord &&
                                HasCallControl(root, "Accept", "Answer", "Принять", "Ответить", "Прийняти", "Annehmen"))));
                        if (isDiscord && !ringing)
                            connected |= HasCallControl(root, "Voice Connected", "Voice connected", "Voice Connected (RTC)",
                                "Голосовая связь подключена", "Голосовое подключение", "Подключено к голосовому каналу",
                                "Голосове з’єднання", "Sprachverbindung hergestellt") &&
                                HasCallControl(root, "Disconnect", "Disconnect from voice", "Отключиться", "Роз’єднати", "Trennen");
                        if (ringing) found = isDiscord ? "Discord" : isWhatsApp ? "WhatsApp" : app;
                        return !ringing;
                    }
                    catch (ElementNotAvailableException) { return true; }
                    catch (COMException) { return true; }
                    catch (InvalidOperationException) { return true; }
                    catch (ArgumentException) { return true; }
                }, IntPtr.Zero);
                discordConnected = connected;
                return found;
            }
            finally
            {
                foreach (var app in apps) app.Dispose();
            }
        }

        private static bool IsWhatsAppWindowTitle(string name)
        {
            return string.Equals(name, "WhatsApp", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(name, "WhatsApp Beta", StringComparison.OrdinalIgnoreCase);
        }

        internal static bool IsWhatsAppIncomingCall(Func<string[], bool> hasLabel)
        {
            return hasLabel(new[] { "Voice call", "Video call", "Incoming voice call", "Incoming video call",
                "Голосовой звонок", "Видеозвонок", "Входящий голосовой звонок", "Входящий видеозвонок",
                "Голосовий дзвінок", "Відеодзвінок", "Sprachanruf", "Videoanruf" }) &&
                hasLabel(new[] { "Accept", "Accept call", "Answer", "Answer call", "Принять", "Принять звонок",
                    "Ответить на звонок", "Прийняти", "Прийняти дзвінок", "Annehmen", "Anruf annehmen" });
        }

        private static bool HasCallControl(AutomationElement root, params string[] names)
        {
            if (root == null || names.Length == 0) return false;
            var matches = Array.ConvertAll(names, name => (System.Windows.Automation.Condition)new PropertyCondition(
                AutomationElement.NameProperty, name, PropertyConditionFlags.IgnoreCase));
            var nameCondition = matches.Length == 1 ? matches[0] : new OrCondition(matches);
            return root.FindFirst(TreeScope.Descendants, new AndCondition(nameCondition,
                new PropertyCondition(AutomationElement.IsOffscreenProperty, false))) != null;
        }

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        private static extern int GetClassName(IntPtr window, System.Text.StringBuilder buffer, int count);

        internal enum ReplyResult { CenterUnavailable, MessageUnavailable, ActionUnavailable, Submitted, Ready }

        internal static ReplyResult SubmitNotificationReply(IslandNotice notice, string text, Func<ReplyPanelCover> coverPanel)
        {
            if (notice == null || !notice.CanReply) return ReplyResult.MessageUnavailable;
            return ReplyThroughNotificationCenterWithCover(notice, text, coverPanel);
        }

        private static ReplyResult ReplyThroughNotificationCenter(IslandNotice notice, string text)
        {
            return ReplyThroughNotificationCenterWithCover(notice, text, null);
        }

        private static ReplyResult ReplyThroughNotificationCenterWithCover(IslandNotice notice, string text, Func<ReplyPanelCover> coverPanel)
        {
            IntPtr window;
            bool openForReply = FindNotificationCenter(out window) == null;
            ReplyPanelCover cover = openForReply && coverPanel != null ? coverPanel() : null;
            if (openForReply) OpenNotificationCenter();
            try
            {
                Action raiseCover = cover == null ? (Action)null : cover.Raise;
                return InvokeNotificationReplyCore(notice, text, false, raiseCover);
            }
            finally
            {
                // Leave a panel the user had already opened alone. Never send the shortcut to close a different flyout.
                if (openForReply && FindNotificationCenter(out window) != null && GetForegroundWindow() == window)
                {
                    OpenNotificationCenter();
                    if (cover != null)
                    {
                        for (int frame = 0; frame < 12 && FindNotificationCenter(out window) != null; frame++)
                            System.Threading.Thread.Sleep(20);
                    }
                }
            }
        }

        private static ReplyResult InvokeNotificationReply(IslandNotice notice, string text, bool inspectOnly)
        {
            return InvokeNotificationReplyCore(notice, text, inspectOnly, null);
        }

        private static ReplyResult InvokeNotificationReplyCore(IslandNotice notice, string text, bool inspectOnly, Action raiseCover)
        {
            if (string.IsNullOrWhiteSpace(notice.App) || string.IsNullOrWhiteSpace(notice.Title) ||
                string.IsNullOrWhiteSpace(text)) return ReplyResult.MessageUnavailable;
            var result = ReplyResult.CenterUnavailable;
            var expanded = new System.Collections.Generic.HashSet<string>();
            bool restartedScroll = false;
            for (int attempt = 0; attempt < 20; attempt++)
            {
                System.Threading.Thread.Sleep(180);
                try
                {
                    IntPtr shell;
                    var root = FindNotificationCenter(out shell);
                    if (root == null) continue;
                    if (raiseCover != null) raiseCover();
                    result = ReplyResult.MessageUnavailable;
                    var walker = TreeWalker.RawViewWalker;
                    var bodyLines = notice.BodyLines ?? new[] { notice.Body ?? "" };
                    var candidates = root.FindAll(TreeScope.Descendants, new OrCondition(
                        new PropertyCondition(AutomationElement.NameProperty, notice.Title),
                        new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.ListItem),
                        new PropertyCondition(AutomationElement.ClassNameProperty, "FlexibleItemView")));
                    var cards = new System.Collections.Generic.List<AutomationElement>();
                    foreach (AutomationElement candidate in candidates)
                    {
                        for (var card = candidate; card != null && !card.Equals(root) && !IsNotificationList(card); card = walker.GetParent(card))
                        {
                            if (!MatchesNotificationCard(card, notice.Title, bodyLines) ||
                                !MatchesNotificationApp(card, root, notice.App)) continue;
                            if (!cards.Any(existing => existing.Equals(card))) cards.Add(card);
                            break;
                        }
                    }
                    // A card and its inner accessibility provider can describe the same message.
                    var matches = cards.Where(card => !cards.Any(other =>
                        !other.Equals(card) && IsAutomationAncestor(card, other))).ToArray();
                    if (matches.Length > 1) return ReplyResult.MessageUnavailable;
                    if (matches.Length == 0)
                    {
                        if (!ExpandNotification(root, expanded, true) && !ScrollNotifications(root, ref restartedScroll)) return result;
                        continue;
                    }
                    var match = matches[0];
                    object scroll;
                    if (match.Current.IsOffscreen && match.TryGetCurrentPattern(ScrollItemPattern.Pattern, out scroll))
                    {
                        ((ScrollItemPattern)scroll).ScrollIntoView();
                        continue;
                    }
                    for (var card = match; card != null && !card.Equals(root) && !IsNotificationList(card); card = walker.GetParent(card))
                    {
                        var group = walker.GetParent(card);
                        result = ReplyResult.ActionUnavailable;
                        if (!IsSingleNotificationScope(card)) break;
                        var edits = card.FindAll(TreeScope.Descendants, new AndCondition(
                            new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Edit),
                            new PropertyCondition(AutomationElement.IsOffscreenProperty, false)));
                        if (edits.Count == 0)
                        {
                            if (ExpandNotification(card, expanded) || OpenReplyField(card, expanded)) break;
                            continue;
                        }
                        if (edits.Count != 1) return result;
                        var button = FindReplyButton(card, edits[0]);
                        if (button == null) continue;
                        // A body-less toast must still expose the app on the card or in its immediate group.
                        if (string.IsNullOrWhiteSpace(notice.Body) && !HasCallControl(card, notice.App) &&
                            (group == null || !HasCallControl(group, notice.App))) return result;
                        object value, action;
                        if (!edits[0].TryGetCurrentPattern(ValuePattern.Pattern, out value) ||
                            !button.TryGetCurrentPattern(InvokePattern.Pattern, out action)) continue;
                        var field = (ValuePattern)value;
                        string original = field.Current.Value;
                        if (field.Current.IsReadOnly || (!string.IsNullOrEmpty(original) && original != text))
                            return result;
                        if (inspectOnly) return ReplyResult.Ready;
                        edits[0].SetFocus();
                        if (GetForegroundWindow() != shell || !edits[0].Current.HasKeyboardFocus) return result;
                        field.SetValue(text);
                        System.Threading.Thread.Sleep(120);
                        if (field.Current.Value != text || !button.Current.IsEnabled || GetForegroundWindow() != shell)
                            return result;
                        ((InvokePattern)action).Invoke();
                        return ReplyResult.Submitted;
                    }
                }
                catch (ElementNotAvailableException) { continue; }
                catch (COMException) { return result; }
                catch (InvalidOperationException) { return result; }
                catch (ArgumentException) { return result; }
                catch (System.ComponentModel.Win32Exception) { continue; }
            }
            return result;
        }

        internal sealed class ReplyPanelCover : IDisposable
        {
            private readonly HwndSource source;
            private readonly IntPtr handle;

            internal ReplyPanelCover(Drawing.Rectangle region)
            {
                BitmapSource snapshot;
                using (var bitmap = new Drawing.Bitmap(region.Width, region.Height, Drawing.Imaging.PixelFormat.Format32bppRgb))
                {
                    using (var graphics = Drawing.Graphics.FromImage(bitmap))
                        graphics.CopyFromScreen(region.Location, Drawing.Point.Empty, region.Size);
                    var pixels = bitmap.LockBits(new Drawing.Rectangle(Drawing.Point.Empty, region.Size),
                        Drawing.Imaging.ImageLockMode.ReadOnly, Drawing.Imaging.PixelFormat.Format32bppRgb);
                    try
                    {
                        snapshot = BitmapSource.Create(region.Width, region.Height, 96, 96,
                            PixelFormats.Bgr32, null, pixels.Scan0, pixels.Stride * region.Height, pixels.Stride);
                    }
                    finally { bitmap.UnlockBits(pixels); }
                }
                snapshot.Freeze();
                var settings = new HwndSourceParameters("Real.Island")
                {
                    PositionX = region.X, PositionY = region.Y, Width = region.Width, Height = region.Height,
                    WindowStyle = unchecked((int)0x80000000), // WS_POPUP
                    ExtendedWindowStyle = 0x08000080, // NOACTIVATE, TOOLWINDOW
                    UsesPerPixelOpacity = true
                };
                source = new HwndSource(settings);
                try
                {
                    var logicalSize = source.CompositionTarget.TransformFromDevice.Transform(new Point(region.Width, region.Height));
                    var drawing = new DrawingVisual();
                    using (var canvas = drawing.RenderOpen())
                        canvas.DrawImage(snapshot, new System.Windows.Rect(0, 0, logicalSize.X, logicalSize.Y));
                    source.RootVisual = drawing;
                    handle = source.Handle;
                    Raise();
                }
                catch
                {
                    source.Dispose();
                    throw;
                }
            }

            internal void Raise()
            {
                const uint showWithoutActivation = 0x0001 | 0x0002 | 0x0010 | 0x0040 | 0x0200;
                SetWindowPos(handle, new IntPtr(-1), 0, 0, 0, 0, showWithoutActivation);
            }

            public void Dispose() { source.Dispose(); }
        }

        private static bool MatchesNotificationCard(AutomationElement card, string title, string[] body)
        {
            if (!IsSingleNotificationScope(card)) return false;
            var lines = new[] { title }.Concat(body).Where(line => !string.IsNullOrWhiteSpace(line)).ToArray();
            if (lines.Length > 1 && MatchesCombinedNotificationText(card.Current.Name, lines)) return true;
            return lines.All(line => HasNotificationLabel(card, line));
        }

        private static bool HasNotificationLabel(AutomationElement item, string label)
        {
            if (MatchesNotificationLabel(item.Current.Name, label) ||
                item.FindFirst(TreeScope.Descendants, new PropertyCondition(
                    AutomationElement.NameProperty, label.Trim(), PropertyConditionFlags.IgnoreCase)) != null) return true;
            return item.FindAll(TreeScope.Descendants, new PropertyCondition(
                AutomationElement.ControlTypeProperty, ControlType.Text)).Cast<AutomationElement>()
                .Any(text => MatchesNotificationLabel(text.Current.Name, label));
        }

        internal static bool MatchesNotificationLabel(string actual, string expected)
        {
            return string.Equals((actual ?? "").Trim(), (expected ?? "").Trim(), StringComparison.OrdinalIgnoreCase);
        }

        internal static bool MatchesCombinedNotificationText(string text, string[] lines)
        {
            return NormalizeNotificationText(text) == NormalizeNotificationText(string.Join(" ", lines));
        }

        private static string NormalizeNotificationText(string text)
        {
            return System.Text.RegularExpressions.Regex.Replace((text ?? "").Trim(), @"\s+", " ");
        }

        private static bool IsSingleNotificationScope(AutomationElement card)
        {
            var views = card.FindAll(TreeScope.Descendants, new PropertyCondition(
                AutomationElement.ClassNameProperty, "FlexibleItemView"));
            return views.Count != 0 ? views.Count == 1 :
                card.FindAll(TreeScope.Descendants, new PropertyCondition(
                    AutomationElement.ControlTypeProperty, ControlType.ListItem)).Count <= 1;
        }

        private static bool IsAutomationAncestor(AutomationElement ancestor, AutomationElement child)
        {
            var walker = TreeWalker.RawViewWalker;
            for (var parent = walker.GetParent(child); parent != null; parent = walker.GetParent(parent))
                if (parent.Equals(ancestor)) return true;
            return false;
        }

        private static bool MatchesNotificationApp(AutomationElement card, AutomationElement root, string name)
        {
            var walker = TreeWalker.RawViewWalker;
            for (var item = card; item != null && !item.Equals(root) && !IsNotificationList(item); item = walker.GetParent(item))
            {
                if (HasNotificationLabel(item, name)) return true;
            }
            return false;
        }

        private static bool ScrollNotifications(AutomationElement root, ref bool restarted)
        {
            var list = root.FindFirst(TreeScope.Descendants, new PropertyCondition(
                AutomationElement.AutomationIdProperty, "NotificationCenterGrid"));
            if (list == null) return false;
            var mainList = list.FindFirst(TreeScope.Descendants, new PropertyCondition(
                AutomationElement.AutomationIdProperty, "MainListView"));
            object listPattern;
            if (mainList != null && mainList.TryGetCurrentPattern(ScrollPattern.Pattern, out listPattern))
                return ScrollNotificationList((ScrollPattern)listPattern, ref restarted);
            var scrollables = list.FindAll(TreeScope.Subtree, new AndCondition(
                new PropertyCondition(AutomationElement.IsScrollPatternAvailableProperty, true),
                new PropertyCondition(AutomationElement.IsOffscreenProperty, false)));
            var patterns = scrollables.Cast<AutomationElement>()
                .Select(element => (ScrollPattern)element.GetCurrentPattern(ScrollPattern.Pattern))
                .Where(pattern => pattern.Current.VerticallyScrollable).ToArray();
            return patterns.Length == 1 && ScrollNotificationList(patterns[0], ref restarted);
        }

        private static bool ScrollNotificationList(ScrollPattern scroll, ref bool restarted)
        {
            if (!scroll.Current.VerticallyScrollable) return false;
            if (!restarted && scroll.Current.VerticalScrollPercent > 0)
            {
                restarted = true;
                scroll.SetScrollPercent(ScrollPattern.NoScroll, 0);
                return true;
            }
            restarted = true;
            if (scroll.Current.VerticalScrollPercent >= 100) return false;
            scroll.Scroll(ScrollAmount.NoAmount, ScrollAmount.LargeIncrement);
            return true;
        }

        private static AutomationElement FindNotificationCenter(out IntPtr shell)
        {
            var foreground = GetForegroundWindow();
            shell = foreground;
            var activeCenter = ReadNotificationCenter(foreground);
            if (activeCenter != null) return activeCenter;

            IntPtr found = IntPtr.Zero;
            AutomationElement center = null;
            EnumWindows((window, context) => {
                if (window == foreground) return true;
                center = ReadNotificationCenter(window);
                if (center == null) return true;
                found = window;
                return false;
            }, IntPtr.Zero);
            shell = found;
            return center;
        }

        private static AutomationElement ReadNotificationCenter(IntPtr window)
        {
            if (!IsWindowVisible(window) || !IsNotificationHost(window)) return null;
            try
            {
                var root = AutomationElement.FromHandle(window);
                var marker = root.FindFirst(TreeScope.Descendants, new AndCondition(
                    new PropertyCondition(AutomationElement.IsOffscreenProperty, false),
                    new OrCondition(new PropertyCondition(AutomationElement.AutomationIdProperty, "NotificationCenterGrid"),
                        new PropertyCondition(AutomationElement.AutomationIdProperty, "ActionCenterListView"))));
                return marker == null ? null : root;
            }
            catch (ElementNotAvailableException) { return null; }
            catch (COMException) { return null; }
            catch (InvalidOperationException) { return null; }
            catch (ArgumentException) { return null; }
        }

        private static bool IsNotificationHost(IntPtr window)
        {
            uint pid;
            GetWindowThreadProcessId(window, out pid);
            if (pid == 0) return false;
            try
            {
                using (var process = Process.GetProcessById((int)pid))
                {
                    string name = process.ProcessName;
                    if (name == "ShellExperienceHost" || name == "ShellHost" || name == "NotificationCenter") return true;
                    if (name != "explorer") return false;
                }
            }
            catch (ArgumentException) { return false; }
            catch (InvalidOperationException) { return false; }
            catch (System.ComponentModel.Win32Exception) { return false; }
            var windowClass = new System.Text.StringBuilder(128);
            GetClassName(window, windowClass, windowClass.Capacity);
            string shellClass = windowClass.ToString();
            return shellClass == "Windows.UI.Core.CoreWindow" || shellClass == "Xaml_WindowedPopupClass" ||
                shellClass == "Windows.UI.Composition.DesktopWindowContentBridge";
        }

        private static AutomationElement FindReplyButton(AutomationElement card, AutomationElement edit)
        {
            var buttons = card.FindAll(TreeScope.Descendants, new AndCondition(
                new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Button),
                new PropertyCondition(AutomationElement.IsOffscreenProperty, false)));
            var names = new[] { "Send", "Send reply", "Send message", "Reply", "Отправить", "Отправить ответ",
                "Отправить сообщение", "Ответить", "Надіслати", "Відповісти", "Senden", "Antworten" };
            var right = new System.Collections.Generic.List<AutomationElement>();
            var named = new System.Collections.Generic.List<AutomationElement>();
            var bounds = edit.Current.BoundingRectangle;
            foreach (AutomationElement button in buttons)
            {
                var info = button.Current;
                var label = (info.Name ?? "").Trim();
                var help = (info.HelpText ?? "").Trim();
                if (names.Contains(label, StringComparer.OrdinalIgnoreCase) || names.Contains(help, StringComparer.OrdinalIgnoreCase))
                    named.Add(button);
                if (IsInlineReplyButton(bounds, info.BoundingRectangle) &&
                    string.IsNullOrWhiteSpace(label) && string.IsNullOrWhiteSpace(help))
                    right.Add(button);
            }
            if (named.Count != 0) return named.Count == 1 ? named[0] : null;
            // Windows can expose a toast action with an image and no accessible name.
            // Limit that case to the single button alongside the one verified reply field.
            return right.Count == 1 ? right[0] : null;
        }

        internal static bool IsInlineReplyButton(System.Windows.Rect field, System.Windows.Rect button)
        {
            if (field.IsEmpty || button.IsEmpty || field.Width <= 0 || field.Height <= 0 ||
                button.Width <= 0 || button.Height <= 0) return false;
            var gap = Math.Max(button.Left - field.Right, field.Left - button.Right);
            var overlap = Math.Min(field.Bottom, button.Bottom) - Math.Max(field.Top, button.Top);
            return gap >= -2 && gap <= field.Height &&
                overlap >= Math.Min(field.Height, button.Height) * .75;
        }

        private static bool IsNotificationList(AutomationElement element)
        {
            var type = element.Current.ControlType;
            return type == ControlType.List || type == ControlType.Window;
        }

        private static bool OpenReplyField(AutomationElement card, System.Collections.Generic.HashSet<string> expanded)
        {
            var labels = new[] { "Reply", "Ответить", "Відповісти", "Antworten" };
            var controls = card.FindAll(TreeScope.Descendants, new AndCondition(
                new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Button),
                new PropertyCondition(AutomationElement.IsOffscreenProperty, false),
                new OrCondition(labels.Select(label => (System.Windows.Automation.Condition)new PropertyCondition(
                    AutomationElement.NameProperty, label, PropertyConditionFlags.IgnoreCase)).ToArray())));
            object action;
            if (controls.Count != 1 || !controls[0].TryGetCurrentPattern(InvokePattern.Pattern, out action) ||
                !expanded.Add(string.Join(".", controls[0].GetRuntimeId()))) return false;
            ((InvokePattern)action).Invoke();
            return true;
        }

        private static bool ExpandNotification(AutomationElement item, System.Collections.Generic.HashSet<string> expanded, bool groupedOnly = false)
        {
            object pattern;
            if (!groupedOnly && item.TryGetCurrentPattern(ExpandCollapsePattern.Pattern, out pattern))
            {
                var expansion = (ExpandCollapsePattern)pattern;
                if (expansion.Current.ExpandCollapseState == ExpandCollapseState.Collapsed)
                {
                    expansion.Expand();
                    return true;
                }
            }
            var buttons = item.FindAll(TreeScope.Descendants, new AndCondition(
                new OrCondition(new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Button),
                    new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Hyperlink)),
                new PropertyCondition(AutomationElement.IsOffscreenProperty, false)));
            foreach (AutomationElement button in buttons)
            {
                string name = button.Current.Name ?? "";
                bool grouped = IsMoreNotificationsLabel(name);
                if (!grouped && (groupedOnly || (button.Current.AutomationId != "ExpandButton" &&
                    !IsExpandNotificationLabel(name, button.Current.HelpText))))
                    continue;
                var id = string.Join(".", button.GetRuntimeId());
                if (expanded.Contains(id)) continue;
                if (button.TryGetCurrentPattern(ExpandCollapsePattern.Pattern, out pattern))
                {
                    var disclosure = (ExpandCollapsePattern)pattern;
                    if (disclosure.Current.ExpandCollapseState != ExpandCollapseState.Collapsed) continue;
                    disclosure.Expand();
                }
                else if (button.TryGetCurrentPattern(InvokePattern.Pattern, out pattern))
                {
                    ((InvokePattern)pattern).Invoke();
                }
                else if (button.TryGetCurrentPattern(TogglePattern.Pattern, out pattern))
                {
                    var toggle = (TogglePattern)pattern;
                    if (toggle.Current.ToggleState != ToggleState.Off) continue;
                    toggle.Toggle();
                }
                else continue;
                expanded.Add(id);
                return true;
            }
            return false;
        }

        private static bool IsExpandNotificationLabel(string name, string help)
        {
            var labels = new[] { "Expand", "Expand notification", "Expand this notification",
                "Развернуть", "Развернуть уведомление", "Развернуть это уведомление",
                "Раскрыть", "Раскрыть уведомление", "Показать больше", "Show more",
                "Розгорнути", "Розгорнути сповіщення", "Erweitern", "Benachrichtigung erweitern" };
            return labels.Contains(name.Trim(), StringComparer.OrdinalIgnoreCase) ||
                labels.Contains((help ?? "").Trim(), StringComparer.OrdinalIgnoreCase);
        }

        internal static bool IsMoreNotificationsLabel(string label)
        {
            return System.Text.RegularExpressions.Regex.IsMatch(label.Trim(),
                @"^(?:\+\s*)?\d+\s+(?:(?:more|weitere|ещ[её])\s+)?(?:уведомл\.?|уведомлен[а-яё]+|notifications?|benachrichtigungen|сповіщень)\s*[.!]?$",
                System.Text.RegularExpressions.RegexOptions.IgnoreCase);
        }

        internal static IntPtr ForegroundKeyboardLayout()
        {
            uint process;
            uint thread = GetWindowThreadProcessId(GetForegroundWindow(), out process);
            return thread == 0 ? IntPtr.Zero : GetKeyboardLayout(thread);
        }
        [DllImport("user32.dll")] private static extern bool SetWindowPos(IntPtr window, IntPtr after, int x, int y, int width, int height, uint flags);
        [DllImport("user32.dll")] private static extern IntPtr GetDC(IntPtr window);
        [DllImport("user32.dll")] private static extern int ReleaseDC(IntPtr window, IntPtr dc);
        [DllImport("gdi32.dll")] private static extern uint GetPixel(IntPtr dc, int x, int y);
        [DllImport("user32.dll")] private static extern void keybd_event(byte key, byte scan, uint flags, UIntPtr extra);

        public static void MediaKey(byte key)
        {
            keybd_event(key, 0, 0, UIntPtr.Zero);
            keybd_event(key, 0, 2, UIntPtr.Zero);
        }

        public static void OpenNotificationCenter()
        {
            const byte windowsKey = 0x5B;
            byte shortcut = Environment.OSVersion.Version.Build >= 22000 ? (byte)0x4E : (byte)0x41;
            keybd_event(windowsKey, 0, 0, UIntPtr.Zero);
            try { MediaKey(shortcut); }
            finally { keybd_event(windowsKey, 0, 2, UIntPtr.Zero); }
        }

        [DllImport("shell32.dll")]
        private static extern int SHGetKnownFolderPath(ref Guid folder, uint flags, IntPtr token, out IntPtr path);

        public static string DownloadsFolder()
        {
            var id = new Guid("374DE290-123F-4565-9164-39C4925E467B");
            IntPtr path;
            int result = SHGetKnownFolderPath(ref id, 0, IntPtr.Zero, out path);
            try { return result == 0 ? Marshal.PtrToStringUni(path) : ""; }
            finally { Marshal.FreeCoTaskMem(path); }
        }

        [DllImport("user32.dll")] private static extern bool IsZoomed(IntPtr window);
        [DllImport("user32.dll")] private static extern IntPtr GetWindow(IntPtr window, uint command);
        [DllImport("user32.dll")] private static extern bool IsWindowVisible(IntPtr window);
        [DllImport("dwmapi.dll")] private static extern int DwmGetWindowAttribute(IntPtr window, uint attribute, out Rect value, int size);

        [DllImport("user32.dll", EntryPoint="SetWindowLongW")] private static extern int SetWindowLong(IntPtr window, int index, int value);
        [DllImport("user32.dll")] private static extern bool RegisterHotKey(IntPtr window, int id, uint modifiers, uint key);
        [DllImport("user32.dll")] private static extern bool UnregisterHotKey(IntPtr window, int id);

        public static Action InstallIslandShortcut(Window window, Action open)
        {
            var source = (HwndSource)PresentationSource.FromVisual(window);
            IntPtr hwnd = source.Handle;
            const int id = 0x4953;
            if (!RegisterHotKey(hwnd, id, 0x4000 | 1 | 2, 0x49)) return null;
            source.AddHook(delegate(IntPtr handle, int message, IntPtr wParam, IntPtr lParam, ref bool handled) {
                if (message == 0x0312 && wParam.ToInt32() == id)
                {
                    handled = true;
                    open();
                }
                return IntPtr.Zero;
            });
            return () => UnregisterHotKey(hwnd, id);
        }

        public static void SetClickThrough(Window window, bool enabled)
        {
            IntPtr hwnd = new WindowInteropHelper(window).Handle;
            if (hwnd == IntPtr.Zero) return;
            int style = GetWindowLong(hwnd, -20);
            int next = enabled ? style | 0x20 : style & ~0x20;
            if (next != style) SetWindowLong(hwnd, -20, next);
        }

        public static bool ForegroundExcluded(Preferences preferences)
        {
            if (preferences.ExcludedApps.Count == 0) return false;
            uint pid;
            GetWindowThreadProcessId(GetForegroundWindow(), out pid);
            if (pid == 0 || pid == App.ProcessId) return false;
            try
            {
                using (var process = Process.GetProcessById((int)pid))
                    return preferences.ExcludedApps.Contains(process.ProcessName);
            }
            catch (ArgumentException) { return false; }
            catch (InvalidOperationException) { return false; }
        }

        public static void KeepAbove(Window window, IntPtr fullscreen)
        {
            IntPtr hwnd = new WindowInteropHelper(window).Handle;
            if (hwnd == IntPtr.Zero || GetForegroundWindow() == hwnd) return;

            bool raise = (GetWindowLong(hwnd, -20) & 8) == 0;
            for (IntPtr above = GetWindow(hwnd, 3); !raise && above != IntPtr.Zero; above = GetWindow(above, 3))
            {
                if ((GetWindowLong(above, -20) & 8) == 0) break;
                if (!IsWindowVisible(above)) continue;
                uint process;
                GetWindowThreadProcessId(above, out process);
                if (process == App.ProcessId) return;
                if (above == fullscreen) raise = true;
            }
            if (raise) SetWindowPos(hwnd, new IntPtr(-1), 0, 0, 0, 0, 0x0010 | 0x0002 | 0x0001 | 0x0200);
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct WindowPosition
        {
            public IntPtr Hwnd, After;
            public int X, Y, Width, Height;
            public uint Flags;
        }

        private static int CenteredPixels(int pixels)
        {
            // An even width prevents alternate half-pixel origins during animation.
            return Math.Max(2, (int)(Math.Round(pixels / 2d) * 2));
        }

        public static double CenteredVisualWidth(Window window, double width)
        {
            double scale = VisualTreeHelper.GetDpi(window).DpiScaleX;
            return CenteredPixels((int)Math.Round(width * scale)) / scale;
        }

        public static void CenterOnResize(Window window, Func<IntPtr> fullscreen)
        {
            IntPtr hwnd = new WindowInteropHelper(window).Handle;
            var source = HwndSource.FromHwnd(hwnd);
            source.AddHook(delegate(IntPtr handle, int message, IntPtr wParam, IntPtr lParam, ref bool handled) {
                if (message != 0x0046 || lParam == IntPtr.Zero || source.CompositionTarget == null) return IntPtr.Zero;
                var position = (WindowPosition)Marshal.PtrToStructure(lParam, typeof(WindowPosition));
                bool sizeChanges = (position.Flags & 1) == 0;
                if (!sizeChanges && (position.Flags & 2) != 0) return IntPtr.Zero;
                int width = position.Width;
                if (sizeChanges && width > 0) position.Width = width = CenteredPixels(width);
                else
                {
                    Rect current;
                    if (!GetWindowRect(handle, out current)) return IntPtr.Zero;
                    width = current.Right - current.Left;
                }
                if (width <= 0) return IntPtr.Zero;
                var point = IslandPosition(width, fullscreen());
                position.X = point.X;
                position.Y = point.Y;
                position.Flags &= ~2u;
                Marshal.StructureToPtr(position, lParam, false);
                return IntPtr.Zero;
            });
        }

        private static Drawing.Point IslandPosition(int width, IntPtr fullscreen)
        {
            Forms.Screen screen = fullscreen == IntPtr.Zero || !IsWindow(fullscreen) ? Forms.Screen.PrimaryScreen : Forms.Screen.FromHandle(fullscreen);
            int top = fullscreen == IntPtr.Zero ? screen.WorkingArea.Top : screen.Bounds.Top;
            return new Drawing.Point(screen.Bounds.Left + (screen.Bounds.Width - width) / 2, top);
        }

        [DllImport("user32.dll")] private static extern bool IsWindow(IntPtr window);

        public static void Place(Window window, IntPtr fullscreen)
        {
            IntPtr hwnd = new WindowInteropHelper(window).Handle;
            Rect rect;
            if (hwnd == IntPtr.Zero || !GetWindowRect(hwnd, out rect)) return;
            var point = IslandPosition(rect.Right - rect.Left, fullscreen);
            if (rect.Left == point.X && rect.Top == point.Y) return;
            SetWindowPos(hwnd, IntPtr.Zero, point.X, point.Y, 0, 0, 0x0010 | 0x0004 | 0x0200 | 0x0001);
        }

        public static IntPtr FullscreenWindow()
        {
            IntPtr active = GetForegroundWindow();
            if (active == IntPtr.Zero || active == GetShellWindow() || IsZoomed(active)) return IntPtr.Zero;
            uint process;
            GetWindowThreadProcessId(active, out process);
            if (process == App.ProcessId) return IntPtr.Zero;
            Rect r;
            if (DwmGetWindowAttribute(active, 9, out r, Marshal.SizeOf(typeof(Rect))) < 0 &&
                !GetWindowRect(active, out r)) return IntPtr.Zero;
            Drawing.Rectangle screen = Forms.Screen.FromHandle(active).Bounds;
            bool coversScreen = r.Left <= screen.Left + 2 && r.Top <= screen.Top + 2 &&
                r.Right >= screen.Right - 2 && r.Bottom >= screen.Bottom - 2;
            return coversScreen ? active : IntPtr.Zero;
        }

        [DllImport("user32.dll", EntryPoint="GetWindowLongW")] private static extern int GetWindowLong(IntPtr window, int index);


        public static BitmapSource GlassBackdrop(IntPtr hwnd, int horizontalInset, int topInset, int bottomInset, out bool dark)
        {
            dark = true;
            Rect r;
            if (!GetWindowRect(hwnd, out r)) return null;
            r.Left += horizontalInset;
            r.Right -= horizontalInset;
            r.Top += topInset;
            r.Bottom -= bottomInset;
            Drawing.Rectangle screen = Forms.Screen.FromHandle(hwnd).Bounds;
            int left = Math.Max(r.Left, screen.Left);
            int right = Math.Min(r.Right, screen.Right);
            int top = Math.Max(r.Top, screen.Top);
            int bottom = Math.Min(r.Bottom, screen.Bottom);
            if (right <= left || bottom <= top) return null;
            dark = DarkBehind(r, screen);

            int sourceWidth = right - left, sourceHeight = bottom - top;
            // Sample below the native window so the glass cannot contain a second copy of the clock.
            int captureTop = bottom + bottomInset + 2;
            if (captureTop >= screen.Bottom) return null;
            sourceHeight = Math.Min(sourceHeight, screen.Bottom - captureTop);
            int width = Math.Min(44, Math.Max(1, sourceWidth / 11));
            int height = Math.Max(1, (int)Math.Round(sourceHeight * width / (double)sourceWidth));
            var pixels = new int[width * height];
            using (var source = new Drawing.Bitmap(sourceWidth, sourceHeight, Drawing.Imaging.PixelFormat.Format32bppRgb))
            using (var reduced = new Drawing.Bitmap(width, height, Drawing.Imaging.PixelFormat.Format32bppRgb))
            {
                using (var graphics = Drawing.Graphics.FromImage(source))
                    graphics.CopyFromScreen(left, captureTop, 0, 0, source.Size, Drawing.CopyPixelOperation.SourceCopy);
                using (var graphics = Drawing.Graphics.FromImage(reduced))
                {
                    graphics.InterpolationMode = Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                    graphics.PixelOffsetMode = Drawing.Drawing2D.PixelOffsetMode.HighQuality;
                    graphics.DrawImage(source, new Drawing.Rectangle(0, 0, width, height));
                }
                var data = reduced.LockBits(new Drawing.Rectangle(0, 0, width, height),
                    Drawing.Imaging.ImageLockMode.ReadOnly, Drawing.Imaging.PixelFormat.Format32bppRgb);
                try { Marshal.Copy(data.Scan0, pixels, 0, pixels.Length); }
                finally { reduced.UnlockBits(data); }
            }

            var refracted = new int[pixels.Length];
            var horizontal = GlassRefraction(width);
            var vertical = GlassRefraction(height);
            for (int y = 0; y < height; y++)
                for (int x = 0; x < width; x++)
                    refracted[y * width + x] = pixels[vertical[y] * width + horizontal[x]];

            var image = BitmapSource.Create(width, height, 96, 96, PixelFormats.Bgr32, null, refracted, width * 4);
            image.Freeze();
            return image;
        }

        private static int[] GlassRefraction(int length)
        {
            var map = new int[length];
            double band = Math.Min(12, length / 3d);
            for (int i = 0; i < length; i++)
            {
                int edge = Math.Min(i, length - 1 - i);
                double lens = Math.Max(0, 1 - edge / band);
                int offset = (int)Math.Round(band * .6 * lens * lens);
                map[i] = i < length / 2d ? i + offset : i - offset;
            }
            return map;
        }

        private static bool DarkBehind(Rect r, Drawing.Rectangle screen)
        {
            IntPtr dc = GetDC(IntPtr.Zero);
            if (dc == IntPtr.Zero) return true;
            try
            {
                int y = Math.Max(screen.Top, r.Top - 3);
                int middle = r.Top + (r.Bottom - r.Top) / 2;
                int seen = 0;
                int dark = 0;
                for (int i = 1; i <= 7; i++)
                {
                    int x = r.Left + (r.Right - r.Left) * i / 8;
                    SamplePixel(dc, x, y, ref seen, ref dark);
                }
                SamplePixel(dc, Math.Max(screen.Left, r.Left - 3), middle, ref seen, ref dark);
                SamplePixel(dc, Math.Min(screen.Right - 1, r.Right + 2), middle, ref seen, ref dark);
                return seen == 0 || dark >= (seen + 1) / 2;
            }
            finally { ReleaseDC(IntPtr.Zero, dc); }
        }

        private static void SamplePixel(IntPtr dc, int x, int y, ref int seen, ref int dark)
        {
            uint color = GetPixel(dc, x, y);
            if (color == uint.MaxValue) return;
            seen++;
            uint luma = 54 * (color & 255) + 183 * ((color >> 8) & 255) + 19 * ((color >> 16) & 255);
            if (luma < 64 * 256) dark++;
        }

        [ComImport, Guid("B92B56A9-8B55-4E14-9A89-0199BBB6F93B"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        private interface IDesktopWallpaper
        {
            void SetWallpaper([MarshalAs(UnmanagedType.LPWStr)] string monitorId, [MarshalAs(UnmanagedType.LPWStr)] string path);
        }

        public static void SetWallpaper(string path)
        {
            Guid clsid = new Guid("C2CF3110-460E-4FC1-B9D0-8A1C0C9CC4BD");
            object instance = Activator.CreateInstance(Type.GetTypeFromCLSID(clsid, true));
            try { ((IDesktopWallpaper)instance).SetWallpaper(null, path); }
            finally { Marshal.ReleaseComObject(instance); }
        }
    }
}









