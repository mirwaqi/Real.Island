using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Interop;
using System.Runtime.InteropServices;
using Microsoft.Win32;

namespace IslandDesktop
{
    internal sealed class AppPicker : Window
    {
        private readonly HashSet<string> selected = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        private readonly HashSet<string> pinned;
        private readonly WrapPanel cards = new WrapPanel();
        private readonly TextBlock counter;
        private readonly Button done;
        private readonly List<string> files;
        public IEnumerable<string> Selected { get { return selected; } }

        public AppPicker(IEnumerable<string> existing)
        {
            pinned = new HashSet<string>(existing, StringComparer.OrdinalIgnoreCase);
            files = FindShortcuts().Where(path => !pinned.Contains(path)).ToList();
            Title = "Добавление приложений";
            WindowStyle = WindowStyle.None;
            ResizeMode = ResizeMode.NoResize;
            AllowsTransparency = true;
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            WindowState = WindowState.Maximized;
            ShowInTaskbar = false;
            Topmost = true;
            Background = Brushes.Transparent;

            var rim = Theme.Card(0, "#A807070A", "#08080B");
            rim.BorderThickness = new Thickness(15);
            var shell = Theme.Card(26, "#15151D", "#4C4859");
            shell.Width = Math.Min(840, Math.Max(365, SystemParameters.PrimaryScreenWidth - 72));
            shell.Height = Math.Min(620, Math.Max(330, SystemParameters.PrimaryScreenHeight - 66));
            shell.HorizontalAlignment = HorizontalAlignment.Center;
            shell.VerticalAlignment = VerticalAlignment.Center;
            rim.Child = shell;
            Content = rim;

            var layout = new DockPanel { Margin = new Thickness(22) };
            shell.Child = layout;
            var top = new StackPanel { Margin = new Thickness(0, 0, 0, 13) };
            top.Children.Add(Theme.TextAt("Нажми на приложения, которые хочешь добавить", 21, Theme.Text, true));
            var search = new TextBox { Margin = new Thickness(0, 10, 0, 0), Padding = new Thickness(9, 6, 9, 6),
                Foreground = Theme.Text, Background = Theme.Paint("#292632"), CaretBrush = Theme.Text, BorderBrush = Theme.Paint("#51475F"),
                ToolTip = "Поиск по названию" };
            System.Windows.Automation.AutomationProperties.SetName(search, "Поиск приложений");
            search.TextChanged += delegate { DrawCards(search.Text); };
            top.Children.Add(search);
            DockPanel.SetDock(top, Dock.Top);
            layout.Children.Add(top);

            var footer = Theme.Row();
            footer.Margin = new Thickness(0, 10, 0, 0);
            counter = Theme.TextAt("", 12, Theme.Muted);
            counter.Margin = new Thickness(0, 0, 12, 0);
            footer.Children.Add(counter);
            var browse = Theme.Button("Выбрать файл…", Browse, "#322B40", 32, 10);
            footer.Children.Add(browse);
            var cancel = Theme.Button("Отмена", delegate { DialogResult = false; }, "#292532", 32, 10);
            cancel.Margin = new Thickness(6, 0, 6, 0);
            footer.Children.Add(cancel);
            done = Theme.Button("Готово", delegate { DialogResult = true; }, "#7658C8", 32, 10);
            footer.Children.Add(done);
            DockPanel.SetDock(footer, Dock.Bottom);
            layout.Children.Add(footer);
            layout.Children.Add(new ScrollViewer { Content = cards, VerticalScrollBarVisibility = ScrollBarVisibility.Auto });
            PreviewKeyDown += delegate(object sender, KeyEventArgs e) { if (e.Key == Key.Escape) { DialogResult = false; e.Handled = true; } };
            DrawCards("");
        }

        private static IEnumerable<string> FindShortcuts()
        {
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            string[] roots = {
                Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory),
                Environment.GetFolderPath(Environment.SpecialFolder.CommonDesktopDirectory),
                Environment.GetFolderPath(Environment.SpecialFolder.Programs),
                Environment.GetFolderPath(Environment.SpecialFolder.CommonPrograms)
            };
            var list = new List<string>();
            for (int i = 0; i < roots.Length; i++)
            {
                if (string.IsNullOrEmpty(roots[i]) || !Directory.Exists(roots[i])) continue;
                try
                {
                    var option = i < 2 ? SearchOption.TopDirectoryOnly : SearchOption.AllDirectories;
                    foreach (string path in Directory.EnumerateFiles(roots[i], "*.*", option))
                    {
                        string name = Path.GetFileNameWithoutExtension(path);
                        if (IsApp(path) && seen.Add(name)) list.Add(path);
                    }
                }
                catch (IOException) { }
                catch (UnauthorizedAccessException) { }
            }
            return list.OrderBy(path => Path.GetFileNameWithoutExtension(path), StringComparer.CurrentCultureIgnoreCase);
        }

        private static bool IsApp(string path)
        {
            return new[] { ".lnk", ".exe", ".appref-ms", ".url" }.Contains(Path.GetExtension(path), StringComparer.OrdinalIgnoreCase);
        }

        private void DrawCards(string filter)
        {
            cards.Children.Clear();
            foreach (string path in files.Where(path => Path.GetFileNameWithoutExtension(path).IndexOf(filter.Trim(), StringComparison.CurrentCultureIgnoreCase) >= 0)
                .OrderByDescending(path => selected.Contains(path)).Take(160))
            {
                string target = path;
                var button = Theme.Button("", delegate { Pick(target); }, selected.Contains(path) ? "#654E9B" : "#2A2634", 80, 13);
                button.Width = 134;
                button.Padding = new Thickness(3);
                button.Margin = new Thickness(0, 0, 7, 7);
                button.Content = AppIcon.Label(path, true);
                Theme.Accessible(button, Path.GetFileNameWithoutExtension(path));
                cards.Children.Add(button);
            }
            if (cards.Children.Count == 0) cards.Children.Add(Theme.TextAt("Приложения не найдены", 13, Theme.Muted));
            UpdateFooter();
        }

#if SMOKE_TEST
        internal void ConfirmFirst()
        {
            if (files.Count == 0) { DialogResult = false; return; }
            Pick(files[0]);
            DialogResult = done.IsEnabled;
        }
#endif

        private void Pick(string path)
        {
            if (!selected.Remove(path)) selected.Add(path);
            foreach (Button button in cards.Children.OfType<Button>())
            {
                var label = (FrameworkElement)button.Content;
                button.Background = Theme.Paint(selected.Contains((string)label.Tag) ? "#654E9B" : "#2A2634");
            }
            UpdateFooter();
        }

        private void UpdateFooter()
        {
            counter.Text = "Выбрано " + selected.Count;
            done.IsEnabled = selected.Count > 0;
        }

        private void Browse()
        {
            var dialog = new OpenFileDialog { Title = "Выбери приложения", Multiselect = true, CheckFileExists = true,
                Filter = "Программы и ярлыки|*.exe;*.lnk;*.appref-ms;*.url" };
            if (dialog.ShowDialog(this) != true) return;
            foreach (string path in dialog.FileNames)
            {
                if (!IsApp(path) || pinned.Contains(path)) continue;
                if (!files.Contains(path, StringComparer.OrdinalIgnoreCase)) files.Insert(0, path);
                selected.Add(path);
            }
            DrawCards("");
        }
    }

    internal static class AppIcon
    {
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        private struct ShellInfo
        {
            public IntPtr Icon;
            public int Index;
            public uint Attributes;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)] public string Name;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 80)] public string Type;
        }
        [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
        private static extern IntPtr SHGetFileInfo(string path, uint attributes, out ShellInfo info, uint size, uint flags);
        [DllImport("user32.dll")] private static extern bool DestroyIcon(IntPtr icon);
        private static readonly Dictionary<string, ImageSource> icons = new Dictionary<string, ImageSource>(StringComparer.OrdinalIgnoreCase);

        public static FrameworkElement Label(string path, bool tile)
        {
            var stack = new StackPanel { Tag = path, Orientation = tile ? Orientation.Vertical : Orientation.Horizontal,
                VerticalAlignment = VerticalAlignment.Center };
            FrameworkElement picture = Picture(path, tile ? 32 : 21);
            picture.Margin = new Thickness(0, 0, tile ? 0 : 8, tile ? 4 : 0);
            stack.Children.Add(picture);
            var label = Theme.TextAt(Path.GetFileNameWithoutExtension(path), 11, Theme.Text);
            label.MaxWidth = tile ? 124 : 246;
            label.TextTrimming = TextTrimming.CharacterEllipsis;
            label.TextAlignment = tile ? TextAlignment.Center : TextAlignment.Left;
            stack.Children.Add(label);
            return stack;
        }

        public static FrameworkElement Picture(string path, double size)
        {
            ImageSource icon;
            if (!icons.TryGetValue(path, out icon))
            {
                ShellInfo info;
                SHGetFileInfo(path, 0, out info, (uint)Marshal.SizeOf(typeof(ShellInfo)), 0x100);
                if (info.Icon != IntPtr.Zero)
                {
                    try { icon = Imaging.CreateBitmapSourceFromHIcon(info.Icon, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions()); }
                    finally { DestroyIcon(info.Icon); }
                }
                icons[path] = icon;
            }
            if (icon != null) return new Image { Source = icon, Width = size, Height = size, IsHitTestVisible = false };
            return new TextBlock { Text = "▣", Width = size, FontSize = size * .8, TextAlignment = TextAlignment.Center, Foreground = Theme.Muted };
        }
    }
}


