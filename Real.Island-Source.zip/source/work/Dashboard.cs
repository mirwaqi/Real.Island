using System;
using System.IO;

using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Microsoft.Win32;

namespace IslandDesktop
{
    internal sealed class Dashboard : Window
    {
        private readonly Preferences prefs;
        private readonly ImageBrush wallpaperImage;
        private readonly TextBlock wallpaperName, status, mode;
        private readonly Button power, apply;
        private readonly CheckBox startupOption;

        private readonly DispatcherTimer watch, saveDelay;
        private Island island;
        private TaskbarMode taskbar;

        public Dashboard()
        {
            prefs = Preferences.Load(Preferences.FileName);
            Title = Installation.Brand;
            using (Stream icon = typeof(Dashboard).Assembly.GetManifestResourceStream("Island.ico"))
            {
                if (icon != null) Icon = BitmapFrame.Create(icon, BitmapCreateOptions.None, BitmapCacheOption.OnLoad);
            }
            Width = 760;
            Height = 715;
            MinWidth = 530;
            MinHeight = 410;
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            Background = Theme.Paint("#101118");
            FontFamily = Theme.Font;
            UseLayoutRounding = true;

            saveDelay = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(250) };
            saveDelay.Tick += delegate { saveDelay.Stop(); SaveIslandSettings(); };
            var root = new StackPanel { Margin = new Thickness(27, 21, 27, 20) };
            var scroll = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Content = root };
            Content = scroll;

            var titleRow = new Grid();
            titleRow.ColumnDefinitions.Add(new ColumnDefinition());
            titleRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            var identity = Theme.Row();
            var logo = Theme.Card(13, "#2D2450", "#554488");
            logo.Width = 42; logo.Height = 42;
            logo.Margin = new Thickness(0, 0, 12, 0);
            var logoMark = Theme.Card(7, "#C2A9FF");
            logoMark.Width = 24; logoMark.Height = 12;
            logoMark.HorizontalAlignment = HorizontalAlignment.Center;
            logoMark.VerticalAlignment = VerticalAlignment.Center;
            logo.Child = logoMark;
            identity.Children.Add(logo);
            identity.Children.Add(Theme.TextAt(Installation.Brand, 29, Theme.Text, true));
            titleRow.Children.Add(identity);
            mode = Theme.TextAt("Выключено", 12, Theme.Muted, true);
            Grid.SetColumn(mode, 1);
            titleRow.Children.Add(mode);
            root.Children.Add(titleRow);

            var hero = Theme.Card(18, "#1C1929", "#353043");
            hero.Margin = new Thickness(0, 17, 0, 12);
            var heroRow = new Grid { Margin = new Thickness(16, 12, 14, 12) };
            heroRow.ColumnDefinitions.Add(new ColumnDefinition());
            heroRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            var intro = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
            intro.Children.Add(Theme.TextAt("Оформление рабочего стола", 16, Theme.Text, true));
            var description = Theme.TextAt("Dynamic Island для Windows", 12, Theme.Muted);
            description.Margin = new Thickness(0, 2, 0, 0);
            intro.Children.Add(description);
            heroRow.Children.Add(intro);
            power = Theme.Button("Запустить", Toggle, "#7658C8", 40);
            power.MinWidth = 131;
            Grid.SetColumn(power, 1);
            heroRow.Children.Add(power);
            hero.Child = heroRow;
            root.Children.Add(hero);

            if (!Installation.Exists)
            {
                var setup = Section(root, "Оставить островок навсегда?");
                var detail = Theme.TextAt("Real.Island будет запускаться при входе в Windows. Удалить его можно в любой момент.", 12, Theme.Muted);
                detail.TextWrapping = TextWrapping.Wrap;
                detail.Margin = new Thickness(0, 0, 0, 9);
                setup.Children.Add(detail);
                var install = Theme.Button("Установить", delegate {
                    try
                    {
                        Installation.Install();
                        ((Border)setup.Parent).Visibility = Visibility.Collapsed;
                        startupOption.IsChecked = true;
                        StartAtLogin();
                    }
                    catch (Exception ex) { Report("Не удалось установить Real.Island. " + ex.Message, true); }
                }, "#7658C8", 34, 10);
                install.HorizontalAlignment = HorizontalAlignment.Left;
                setup.Children.Add(install);
            }

            var settings = Section(root, "Настройки островка");
            var sliders = new Grid { Margin = new Thickness(0, 2, 0, 6) };
            sliders.ColumnDefinitions.Add(new ColumnDefinition());
            sliders.ColumnDefinitions.Add(new ColumnDefinition());
            var transparency = SliderRow("Прозрачность фона", 0, 60, prefs.Transparency, "%", delegate(int value) { prefs.Transparency = value; });
            transparency.Margin = new Thickness(0, 0, 10, 0);
            sliders.Children.Add(transparency);
            var speed = SliderRow("Длительность анимации", 160, 580, prefs.Animation, " мс", delegate(int value) { prefs.Animation = value; });
            Grid.SetColumn(speed, 1);
            sliders.Children.Add(speed);
            settings.Children.Add(sliders);

            var switches = new UniformGrid { Columns = 2 };
            AddSwitch(switches, "Часы в островке", prefs.Clock, delegate(bool value) { prefs.Clock = value; ApplySettings(); });
            AddSwitch(switches, "Обложка и управление музыкой", prefs.Media, delegate(bool value) { prefs.Media = value; ApplySettings(); });
            AddSwitch(switches, "Контур на тёмном фоне", prefs.Outline, delegate(bool value) { prefs.Outline = value; ApplySettings(); });
            AddSwitch(switches, "Скрывать панель задач", prefs.HideTaskbar, delegate(bool value) { prefs.HideTaskbar = value; ApplySettings(); });
            AddSwitch(switches, "Скрывать в полноэкранном режиме", prefs.HideFullscreen, delegate(bool value) { prefs.HideFullscreen = value; ApplySettings(); });

            startupOption = AddSwitch(switches, "Запускать при входе в Windows", Preferences.StartsAtLogin(), delegate(bool value) {
                ChangeStartup(value);
                startupOption.IsChecked = Preferences.StartsAtLogin();
            });
            startupOption.ToolTip = "Храни EXE в постоянной папке, чтобы Windows могла найти его при входе.";
            settings.Children.Add(switches);

            var walls = Section(root, "Обои");
            var preview = Theme.Card(13, "#1C1B2C");
            preview.Height = 153;
            preview.ClipToBounds = true;
            wallpaperImage = new ImageBrush { Stretch = Stretch.UniformToFill, AlignmentY = AlignmentY.Bottom };
            RenderOptions.SetBitmapScalingMode(preview, BitmapScalingMode.HighQuality);
            preview.Background = wallpaperImage;
            walls.Children.Add(preview);
            wallpaperName = Theme.TextAt("", 12, Theme.Muted);
            wallpaperName.TextTrimming = TextTrimming.CharacterEllipsis;
            wallpaperName.Margin = new Thickness(0, 6, 0, 0);
            walls.Children.Add(wallpaperName);

            var wallActions = new WrapPanel { Margin = new Thickness(0, 7, 0, 0) };
            AddButton(wallActions, "Выбрать файл…", ChooseWallpaper);
            AddButton(wallActions, "Аврора 4K", delegate { SelectWallpaper(Preferences.Aurora); });
            apply = AddButton(wallActions, "Установить обои", ApplyWallpaper, "#4B3B72");
            walls.Children.Add(wallActions);

            status = Theme.TextAt("", 12, Theme.Muted);
            status.TextWrapping = TextWrapping.Wrap;
            status.Margin = new Thickness(1, 0, 0, 0);
            System.Windows.Automation.AutomationProperties.SetLiveSetting(status, System.Windows.Automation.AutomationLiveSetting.Polite);
            root.Children.Add(status);
            watch = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(500) };
            watch.Tick += delegate { RefreshOverlays(); };
            Closing += delegate(object sender, System.ComponentModel.CancelEventArgs e) {
                if (island == null) return;
                e.Cancel = true;
                HideSettings();
            };
            Closed += delegate { FlushSettings(); Stop(); };

            RefreshWallpaper();
        }

        private StackPanel SliderRow(string name, int min, int max, int initial, string unit, Action<int> change)
        {
            var stack = new StackPanel();
            var label = Theme.TextAt(name + " · " + initial + unit, 12, Theme.Text, true);
            stack.Children.Add(label);
            var slider = new Slider {
                Minimum = min, Maximum = max, Value = initial, TickFrequency = 1,
                IsSnapToTickEnabled = true, SmallChange = 1, LargeChange = 10,
                Margin = new Thickness(0, 4, 0, 1)
            };
            System.Windows.Automation.AutomationProperties.SetName(slider, name);
            slider.ValueChanged += delegate {
                int value = (int)slider.Value;
                label.Text = name + " · " + value + unit;
                change(value);
                ApplySettings();
            };
            stack.Children.Add(slider);
            return stack;
        }

        private static CheckBox AddSwitch(Panel parent, string name, bool initial, Action<bool> change)
        {
            var box = new CheckBox { Content = name, IsChecked = initial, Foreground = Theme.Text,
                FontSize = 12, VerticalContentAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 4, 6, 4) };
            box.Click += delegate { change(box.IsChecked == true); };
            parent.Children.Add(box);
            return box;
        }

        private void ApplySettings()
        {
            if (island != null)
            {
                try
                {
                    UpdateTaskbar();
                    island.ApplySettings();
                }
                catch (Exception ex) { Report("Не удалось применить настройку. " + ex.Message, true); return; }
            }
            saveDelay.Stop();
            saveDelay.Start();
        }

        private void FlushSettings()
        {
            if (!saveDelay.IsEnabled) return;
            saveDelay.Stop();
            Save();
        }

        private void ChangeStartup(bool value)
        {
            try { Preferences.SetStartAtLogin(value); }
            catch (Exception ex) { Report("Не удалось изменить автозапуск. " + ex.Message, true); }
        }

        private void UpdateTaskbar()
        {
            if (prefs.HideTaskbar && taskbar == null) taskbar = TaskbarMode.Begin();
            if (!prefs.HideTaskbar && taskbar != null)
            {
                taskbar.Dispose();
                taskbar = null;
            }
        }

        private static StackPanel Section(Panel root, string heading)
        {
            var card = Theme.Card(18, "#181922", "#292B39");
            card.Margin = new Thickness(0, 0, 0, 10);
            var stack = new StackPanel { Margin = new Thickness(13, 9, 13, 9) };
            var title = Theme.TextAt(heading, 15, Theme.Text, true);
            title.Margin = new Thickness(0, 0, 0, 6);
            stack.Children.Add(title);
            card.Child = stack;
            root.Children.Add(card);
            return stack;
        }

        private static Button AddButton(Panel row, string text, Action action, string color = "#2C2D3C")
        {
            var button = Theme.Button(text, action, color, 31, 9);
            button.Margin = new Thickness(0, 0, 6, 3);
            row.Children.Add(button);
            return button;
        }

        private void Toggle()
        {
            if (island != null)
            {
                Stop();
                Report("Оформление выключено.");
                return;
            }
            try
            {
                island = new Island(prefs, ApplySettings, SaveIslandSettings, StopFromIsland);
                island.Closed += delegate(object sender, EventArgs args) {
                    if (!ReferenceEquals(island, sender)) return;
                    island = null;
                    Stop();
                };
                UpdateTaskbar();
                RefreshOverlays();
                watch.Start();
                power.Content = "Остановить";
                mode.Text = "Работает";
                mode.Foreground = Theme.Paint("#BDA9FF");
                Report("Нажмите на островок, чтобы открыть быстрые настройки.");
                HideSettings();
            }
            catch (Exception ex)
            {
                Stop();
                ShowSettings();
                Report("Не удалось запустить оформление. " + ex.Message, true);
            }
        }

        public void Exit()
        {
            OnSessionEnding();
            Close();
        }

        public void OnSessionEnding()
        {
            FlushSettings();
            Stop();
        }

        public void StartAtLogin()
        {
            if (island == null) Toggle();
        }

        private void HideSettings()
        {
            FlushSettings();
            ShowInTaskbar = false;
            if (IsVisible) Hide();
        }

        private void StopFromIsland()
        {
            Stop();
            ShowSettings();
            Report("Оформление выключено.");
        }

        public void ShowSettings()
        {
            if (island != null)
            {
                island.OpenSettings();
                return;
            }
            Opacity = 1;
            ShowInTaskbar = true;
            if (!IsVisible) Show();
            WindowState = WindowState.Normal;
            Activate();
        }

        private void Stop()
        {
            Island oldIsland = island;
            island = null;
            watch.Stop();
            if (taskbar != null) taskbar.Dispose();
            taskbar = null;
            if (oldIsland != null) oldIsland.Close();
            power.Content = "Запустить";
            mode.Text = "Выключено";
            mode.Foreground = Theme.Muted;
        }

        private void RefreshOverlays()
        {
            var overlay = island;
            if (Dispatcher.HasShutdownStarted || overlay == null || overlay.PickerOpen) return;
            IntPtr fullscreen = WindowsIntegration.FullscreenWindow();
            if (WindowsIntegration.ForegroundExcluded(prefs) || (prefs.HideFullscreen && fullscreen != IntPtr.Zero))
            {
                if (overlay.IsVisible) overlay.Hide();
                return;
            }

            if (!overlay.IsVisible) overlay.Show();
            if (overlay != island) return;
            if (!overlay.IsActive || fullscreen != IntPtr.Zero) overlay.FollowFullscreen(fullscreen);
            overlay.UpdateGlass();
        }

        private void ChooseWallpaper()
        {
            var dialog = new OpenFileDialog { Title = "Выберите обои", CheckFileExists = true,
                Filter = "Изображения|*.jpg;*.jpeg;*.png;*.bmp;*.gif;*.tif;*.tiff;*.webp;*.heic;*.avif|Все файлы|*.*" };
            if (dialog.ShowDialog(this) != true) return;
            SelectWallpaper(dialog.FileName);
        }

        private void SelectWallpaper(string selection)
        {
            string previous = prefs.Wallpaper;
            prefs.Wallpaper = selection;
            if (!RefreshWallpaper())
            {
                prefs.Wallpaper = previous;
                RefreshWallpaper();
                Report("Не удалось прочитать изображение. Проверьте файл или выберите JPG, PNG либо BMP.", true);
                return;
            }
            if (Save()) Report("Обои выбраны. Нажмите «Установить обои».");
        }

        private bool RefreshWallpaper()
        {
            string selection = prefs.Wallpaper;
            if (selection == "" || selection == Preferences.Aurora)
            {
                wallpaperImage.ImageSource = Wallpaper.Art(840, 472);
                wallpaperName.Text = selection == "" ? "Предпросмотр · Аврора 4K" : "Аврора · 3840 × 2160";
                apply.IsEnabled = selection != "";
                return true;
            }
            try
            {
                wallpaperImage.ImageSource = Wallpaper.LoadPreview(selection);
                wallpaperName.Text = Path.GetFileName(selection);
                apply.IsEnabled = true;
                return true;
            }
            catch (Exception)
            {
                wallpaperImage.ImageSource = Wallpaper.Art(840, 472);
                wallpaperName.Text = "Файл обоев недоступен";
                apply.IsEnabled = false;
                return false;
            }
        }

        private void ApplyWallpaper()
        {
            try
            {
                Wallpaper.Apply(prefs.Wallpaper);
                Report("Обои установлены.");
            }
            catch (Exception ex) { Report("Не удалось установить обои. " + ex.Message, true); }
        }

        private void SaveIslandSettings()
        {
            if (!Save() && island != null)
                island.SettingsPanel.Report("Не удалось сохранить изменения.");
        }

        private bool Save()
        {
            try { prefs.Save(Preferences.FileName); return true; }
            catch (Exception ex)
            {
                Report("Не удалось сохранить настройки. " + ex.Message, true);
                return false;
            }
        }

        private void Report(string message, bool error = false)
        {
            status.Text = message;
            status.Foreground = error ? Theme.Paint("#F8AAAA") : Theme.Muted;
        }
    }
}














