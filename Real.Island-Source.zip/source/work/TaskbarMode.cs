using System;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;

namespace IslandDesktop
{
    internal sealed class TaskbarMode : IDisposable
    {
        [StructLayout(LayoutKind.Sequential)]
        private struct AppBarData
        {
            public uint Size;
            public IntPtr Window;
            public uint Callback, Edge;
            public int Left, Top, Right, Bottom;
            public IntPtr Parameter;
        }

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        private static extern IntPtr FindWindow(string cls, string title);

        [DllImport("shell32.dll")]
        private static extern UIntPtr SHAppBarMessage(uint message, ref AppBarData data);

        private static readonly string RecoveryFile = Path.Combine(Preferences.Folder, "taskbar-state.txt");
        private const uint GetState = 4, SetState = 10, AutoHide = 1, StateMask = 3;
        private readonly uint original;

        private TaskbarMode(uint original) { this.original = original; }

        public static TaskbarMode Begin()
        {
#if SMOKE_TEST
            return null;
#else
            var data = CreateData();
            if (data.Window == IntPtr.Zero) return null;
            uint state = SHAppBarMessage(GetState, ref data).ToUInt32() & StateMask;
            if ((state & AutoHide) != 0) return null;
            Directory.CreateDirectory(Preferences.Folder);
            File.WriteAllText(RecoveryFile, state.ToString(CultureInfo.InvariantCulture));
            var mode = new TaskbarMode(state);
            Apply(ref data, state | AutoHide);
            return mode;
#endif
        }

        public static void RestoreInterrupted()
        {
            if (!File.Exists(RecoveryFile)) return;
            try
            {
                uint state;
                if (uint.TryParse(File.ReadAllText(RecoveryFile), out state) && state <= StateMask)
                    new TaskbarMode(state).Dispose();
            }
            catch (IOException) { }
            catch (UnauthorizedAccessException) { }
        }

        public void Dispose()
        {
            var data = CreateData();
            if (data.Window == IntPtr.Zero) return;
            uint current = SHAppBarMessage(GetState, ref data).ToUInt32();
            if ((current & AutoHide) != 0) Apply(ref data, original);
            try { File.Delete(RecoveryFile); }
            catch (IOException) { }
            catch (UnauthorizedAccessException) { }
        }

        private static AppBarData CreateData()
        {
            return new AppBarData {
                Size = (uint)Marshal.SizeOf(typeof(AppBarData)),
                Window = FindWindow("Shell_TrayWnd", null)
            };
        }

        private static void Apply(ref AppBarData data, uint state)
        {
            data.Parameter = new IntPtr((int)state);
            SHAppBarMessage(SetState, ref data);
        }
    }
}
