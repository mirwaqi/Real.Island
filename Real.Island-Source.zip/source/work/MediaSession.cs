using System;
using System.IO;
using System.Text;
using System.Diagnostics;
using System.Collections.Generic;
using System.Threading;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;
using Windows.Media.Control;
using Windows.Storage.Streams;

namespace IslandDesktop
{
    internal sealed class Track
    {
        public string Title = "", Artist = "", Source = "";
        public BitmapSource Cover;
        public bool Playing, Paused;
    }

    internal sealed class MediaSession : IDisposable
    {
        private GlobalSystemMediaTransportControlsSessionManager manager;
        private GlobalSystemMediaTransportControlsSession session;
        private Track track = new Track();
        private volatile bool dirty = true;


        private bool blockedBrowser;
        private GlobalSystemMediaTransportControlsSession pausedSession;
        private Track pausedTrack;
        private DateTime ignorePlayingUntil;
        private bool disposed;
        private DateTime retryAfter;

        // The desktop CLR's WinRT bridge refers to the unified Windows metadata.
        private static readonly MethodInfo AsTask = typeof(System.WindowsRuntimeSystemExtensions).GetMethods()
            .First(m => m.Name == "AsTask" && m.IsGenericMethodDefinition && m.GetParameters().Length == 1 &&
                m.GetParameters()[0].ParameterType.Name == "IAsyncOperation`1");
        private static readonly MethodInfo AsStream = typeof(System.IO.WindowsRuntimeStreamExtensions).GetMethods()
            .First(m => m.Name == "AsStreamForRead" && m.GetParameters().Length == 1);

        internal static BitmapSource DecodeImage(IRandomAccessStreamWithContentType data, int size)
        {
            using (var stream = (Stream)AsStream.Invoke(null, new object[] { data }))
            {
                var bitmap = new BitmapImage();
                bitmap.BeginInit();
                bitmap.StreamSource = stream;
                bitmap.CacheOption = BitmapCacheOption.OnLoad;
                bitmap.DecodePixelWidth = size;
                bitmap.EndInit();
                bitmap.Freeze();
                return bitmap;
            }
        }

        internal static Task<T> Read<T>(object operation)
        {
            return (Task<T>)AsTask.MakeGenericMethod(typeof(T)).Invoke(null, new[] { operation });
        }

        public async Task<Track> Refresh()
        {
            if (disposed || DateTime.UtcNow < retryAfter) return track;
            try
            {
                if (manager == null)
                    manager = await Read<GlobalSystemMediaTransportControlsSessionManager>(GlobalSystemMediaTransportControlsSessionManager.RequestAsync());
                if (disposed) return track;
                var current = manager.GetCurrentSession();
                if (current == null || !IsPlaying(current))
                    current = manager.GetSessions().FirstOrDefault(IsPlaying) ??
                        (session != null && manager.GetSessions().Any(item => Equals(item, session)) ? session : null);
                if (pausedSession != null)
                {
                    bool sameSource = current != null && pausedTrack.Source == current.SourceAppUserModelId;
                    bool active = current != null && IsPlaying(current);
                    if (!active || (sameSource && DateTime.UtcNow < ignorePlayingUntil))
                        return pausedTrack;
                    pausedSession = null;
                    pausedTrack = null;
                }
                if (!Equals(current, session))
                {
                    Unsubscribe();
                    session = current;
                    if (session != null)
                    {
                        session.MediaPropertiesChanged += OnPropertiesChanged;

                    }
                    dirty = true;
                    blockedBrowser = false;
                    track = new Track { Source = current == null ? "" : current.SourceAppUserModelId };
                }
                if (session == null) { blockedBrowser = false; return track; }
                if (dirty)
                {
                    dirty = false;
                    var metadata = await Read<GlobalSystemMediaTransportControlsSessionMediaProperties>(session.TryGetMediaPropertiesAsync());
                    if (disposed) return track;
                    if (metadata == null) { dirty = true; }
                    else
                    {
                        string description = (metadata.Title ?? "") + " " + (metadata.Artist ?? "");
                        blockedBrowser = IsBrowser(track.Source) && IsCallTitle(description);
                        if (blockedBrowser)
                        {
                            track.Playing = track.Paused = false;
                            track.Title = description;
                            return track;
                        }
                        track.Title = metadata.Title ?? "";
                        track.Artist = metadata.Artist ?? "";
                        track.Cover = null;
                        if (metadata.Thumbnail != null)
                        {
                            try
                            {
                                using (var data = await Read<IRandomAccessStreamWithContentType>(metadata.Thumbnail.OpenReadAsync()))
                                    track.Cover = DecodeImage(data, 128);
                            }
                            catch (Exception) { }
                        }
                    }
                }
                if (!disposed)
                {

                    track.Playing = IsPlaying(session) && !blockedBrowser;
                    track.Paused = !blockedBrowser && !track.Playing && session.GetPlaybackInfo().PlaybackStatus == GlobalSystemMediaTransportControlsSessionPlaybackStatus.Paused;
                }
            }
            catch (Exception)
            {
                retryAfter = DateTime.UtcNow.AddSeconds(5);
                dirty = true;
                track.Playing = track.Paused = false;
            }
            return track;
        }

        internal static bool IsCallSource(string source)
        {
            string name = source.ToLowerInvariant();
            return new[] { "discord", "teams", "skype", "zoom", "slack", "webex", "telegram",
                "whatsapp", "viber", "signal", "facetime", "google meet", "phone link" }.Any(name.Contains);
        }

        private static bool IsCallTitle(string title)
        {
            string name = title.ToLowerInvariant();
            return name.Contains("google meet") || name.Contains("meet.google.com") ||
                name.Contains("microsoft teams") || name.Contains("zoom meeting") || name.Contains("discord.com") ||
                name.Trim() == "discord" || name.Contains("видеозвонок");
        }

        internal static bool IsBrowser(string source)
        {
            return new[] { "chrome", "msedge", "firefox", "brave", "opera", "vivaldi", "chromium" }
                .Any(source.ToLowerInvariant().Contains);
        }

        private static bool IsPlaying(GlobalSystemMediaTransportControlsSession item)
        {
            return item != null && !IsCallSource(item.SourceAppUserModelId) && item.GetPlaybackInfo().PlaybackStatus ==
                GlobalSystemMediaTransportControlsSessionPlaybackStatus.Playing;
        }

        private void OnPropertiesChanged(GlobalSystemMediaTransportControlsSession sender, MediaPropertiesChangedEventArgs args)
        {
            dirty = true;
        }

        public async void Transport(byte key)
        {
            try
            {
                if (session != null)
                {
                    if (key == 0xB1 && await Read<bool>(session.TrySkipPreviousAsync())) return;
                    if (key == 0xB0 && await Read<bool>(session.TrySkipNextAsync())) return;
                }
            }
            catch (Exception) { }

        }

        public async Task<bool> SetPaused(bool paused)
        {
            var target = session;
            if (target == null || blockedBrowser || IsCallSource(target.SourceAppUserModelId)) return false;
            try
            {
                if (blockedBrowser || IsCallSource(target.SourceAppUserModelId)) return false;
                var snapshot = new Track { Title = track.Title, Artist = track.Artist, Cover = track.Cover,
                    Source = target.SourceAppUserModelId, Paused = true };
                bool accepted = await Read<bool>(paused ? target.TryPauseAsync() : target.TryPlayAsync());
                if (!accepted || disposed) return false;
                if (paused)
                {
                    pausedTrack = snapshot;
                    pausedSession = target;
                    ignorePlayingUntil = DateTime.UtcNow.AddMilliseconds(700);
                }
                else
                {
                    pausedTrack = null;
                    pausedSession = null;
                }
                return true;
            }
            catch (Exception) { return false; }
        }

        private void Unsubscribe()
        {
            if (session == null) return;
            try { session.MediaPropertiesChanged -= OnPropertiesChanged; }
            catch (COMException) { }
                    catch (UnauthorizedAccessException) { }

            session = null;
        }

        public void Dispose()
        {
            disposed = true;
            Unsubscribe();
        }
    }

    internal sealed class OutputMeter : IDisposable
    {
        [ComImport, Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        private interface IDeviceEnumerator
        {
            void EnumAudioEndpoints(int flow, int stateMask, out IDeviceCollection devices);
            void GetDefaultAudioEndpoint(int flow, int role, out IDevice device);
        }

        [ComImport, Guid("0BD7A1BE-7A1A-44DB-8397-CC5392387B5E"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        private interface IDeviceCollection
        {
            void GetCount(out uint count);
            void Item(uint index, out IDevice device);
        }

        [ComImport, Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        private interface IDevice
        {
            void Activate(ref Guid iid, int context, IntPtr parameters, [MarshalAs(UnmanagedType.IUnknown)] out object result);
            void OpenPropertyStore();
            void GetId([MarshalAs(UnmanagedType.LPWStr)] out string id);
        }

        [ComImport, Guid("C02216F6-8C67-4B5B-9D00-D008E73E0064"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        private interface IAudioMeter
        {
            void GetPeakValue(out float peak);
        }

        [ComImport, Guid("77AA99A0-1BD6-484F-8BC7-2C654C9A9B6F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        private interface ISessionManager
        {
            void GetAudioSessionControl();
            void GetSimpleAudioVolume();
            void GetSessionEnumerator(out ISessionEnumerator sessions);
        }

        [ComImport, Guid("E2F5BB11-0570-40CA-ACDD-3AA01277DEE8"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        private interface ISessionEnumerator
        {
            void GetCount(out int count);
            void GetSession(int index, [MarshalAs(UnmanagedType.IUnknown)] out object session);
        }

        [ComImport, Guid("BFB7FF88-7239-4FC9-8FA2-07C950BE9C6D"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        private interface ISessionControl
        {
            void GetState(out int state);
            void GetDisplayName();
            void SetDisplayName();
            void GetIconPath();
            void SetIconPath();
            void GetGroupingParam();
            void SetGroupingParam();
            void RegisterAudioSessionNotification();
            void UnregisterAudioSessionNotification();
            void GetSessionIdentifier([MarshalAs(UnmanagedType.LPWStr)] out string id);
            void GetSessionInstanceIdentifier();
            [PreserveSig] int GetProcessId(out uint id);
        }

        private readonly List<IAudioMeter> meters = new List<IAudioMeter>();
        private readonly List<IAudioMeter> musicMeters = new List<IAudioMeter>();
        private readonly List<IAudioMeter> outputMeters = new List<IAudioMeter>();
        private readonly List<IAudioMeter> otherMeters = new List<IAudioMeter>();
        private readonly List<IAudioMeter> callMeters = new List<IAudioMeter>();

        private readonly Dictionary<string, bool> musicProducts = new Dictionary<string, bool>(StringComparer.OrdinalIgnoreCase);
        private readonly AutoResetEvent wake = new AutoResetEvent(false);
        private readonly Thread worker;
        internal const string PlayerFallback = "*players";
        private static readonly string[] Players = { "spotify", "vlc", "foobar2000", "aimp", "itunes", "musicbee",
            "mpv", "winamp", "wmplayer", "music.ui", "microsoft.media.player", "applemusic", "tidal", "deezer",
            "yandexmusic", "y.music", "potplayer", "potplayermini", "potplayermini64", "mpc-hc", "mpc-hc64",
            "mediamonkey", "audacious", "audacity", "strawberry", "clementine", "qmmp", "dopamine", "nuclear", "soundcloud", "ytmdesktop", "th-ch-youtube-music" };
        private volatile string source = "";
        private volatile string extraPlayer = "";
        private volatile bool stopped;
        private int peak;
        private readonly int[] spectrumPeaks = new int[BassCapture.BandCount];
        private readonly double[] capturedBands = new double[BassCapture.BandCount];
        private BassCapture bass;
        private string bassDevice;
        private bool keepBass;
        private bool unmeteredOutput;

        public OutputMeter()
        {
            worker = new Thread(Measure) { IsBackground = true, Name = "Island audio meter" };
            worker.Start();
        }

        public void SelectSource(string value, string customPlayer = "")
        {
            if (stopped || (source == value && extraPlayer == customPlayer)) return;
            extraPlayer = customPlayer;
            source = value;
            Interlocked.Exchange(ref peak, 0);
            for (int band = 0; band < spectrumPeaks.Length; band++)
                Interlocked.Exchange(ref spectrumPeaks[band], 0);
            wake.Set();
        }

        public double ReadBass() { return Interlocked.Exchange(ref spectrumPeaks[0], 0) / 1000000d; }
        public void ReadSpectrum(double[] destination)
        {
            for (int band = 0; band < spectrumPeaks.Length; band++)
                destination[band] = Interlocked.Exchange(ref spectrumPeaks[band], 0) / 1000000d;
        }
        public double ReadPeak() { return Interlocked.Exchange(ref peak, 0) / 1000000d; }

        private void Measure()
        {
            string selected = "", selectedExtra = "";
            DateTime refresh = DateTime.MinValue;
            try
            {
                while (!stopped)
                {
                    string current = source;
                    string custom = extraPlayer;
                    if (current != selected || custom != selectedExtra || (current.Length > 0 && DateTime.UtcNow >= refresh))
                    {
                        ClearMeters();
                        if (selected != current) CloseBass();
                        selected = current;
                        selectedExtra = custom;
                        keepBass = false;
                        unmeteredOutput = false;
                        if (selected.Length > 0) Connect(selected, selectedExtra);
                        if (!keepBass) CloseBass();
                        refresh = DateTime.UtcNow.AddMilliseconds(330);
                    }
                    float value = ReadMeters(meters);
                    if (value < .00002f) value = ReadMeters(musicMeters);
                    float calls = ReadMeters(callMeters);
                    float other = ReadMeters(otherMeters);
                    if (value < .00002f && !unmeteredOutput && outputMeters.Count > 0 && Math.Max(calls, other) < .00002f)
                        value = ReadMeters(outputMeters);
                    if (source == current && extraPlayer == custom)
                    {
                        int measured = (int)Math.Round(Math.Min(1, value) * 1000000);
                        int previous;
                        do { previous = Volatile.Read(ref peak); }
                        while (measured > previous && Interlocked.CompareExchange(ref peak, measured, previous) != previous);
                    }
                    if (bass != null)
                    {
                        try
                        {
                            bass.Read(capturedBands);
                            // Require active music before using the output spectrum, and suppress it during calls.
                            if (source == current && extraPlayer == custom && value > .00002f &&
                                calls < .00002f)
                            {
                                for (int band = 0; band < spectrumPeaks.Length; band++)
                                {
                                    int measured = (int)Math.Round(Math.Min(1, capturedBands[band]) * 1000000);
                                    int previous;
                                    do { previous = Volatile.Read(ref spectrumPeaks[band]); }
                                    while (measured > previous && Interlocked.CompareExchange(ref spectrumPeaks[band], measured, previous) != previous);
                                }
                            }
                        }
                        catch (COMException) { CloseBass(); }
                    }
                    wake.WaitOne(current.Length == 0 ? Timeout.Infinite : 10);
                }
            }
            finally
            {
                ClearMeters();
                CloseBass();
                wake.Dispose();
            }
        }

        private static float ReadMeters(List<IAudioMeter> list)
        {
            float peak = 0;
            foreach (IAudioMeter meter in list)
            {
                try
                {
                    float value;
                    meter.GetPeakValue(out value);
                    peak = Math.Max(peak, value);
                }
                catch (COMException) { }
                catch (UnauthorizedAccessException) { }
            }
            return peak;
        }

        private static bool IsMusicPlayer(string value)
        {
            if (Players.Contains(value)) return true;
            string name = value.Replace(" ", "").Replace("-", "").Replace("_", "");
            return name.StartsWith("com.github.thch.youtubemusic", StringComparison.Ordinal) ||
                name.StartsWith("com.github.thch.youtubesong", StringComparison.Ordinal) ||
                name == "youtubesong" || name == "youtubesong.exe" || name == "youtubemusic" ||
                name == "youtubemusic.exe" || name == "soundcloudmusic" || name == "soundcloudmusic.exe" || name == "soundcloudmusic&audio";
        }

        internal static bool Matches(string source, string process, string id, string customPlayer = "", string processPath = "")
        {
            if (source.Length == 0 || process.Length == 0 || MediaSession.IsCallSource(process) || MediaSession.IsCallSource(source)) return false;
            string name = source.ToLowerInvariant(), exe = process.ToLowerInvariant();
            bool explicitlySelected = customPlayer.Length > 0 &&
                !MediaSession.IsBrowser(exe) && !MediaSession.IsCallSource(customPlayer) &&
                (string.Equals(customPlayer, processPath, StringComparison.OrdinalIgnoreCase) ||
                 id.IndexOf(customPlayer, StringComparison.OrdinalIgnoreCase) >= 0);
            if (explicitlySelected) return true;
            if (name == PlayerFallback)
                return IsMusicPlayer(exe);
            if (MediaSession.IsBrowser(exe) && name.Contains(exe)) return true;
            if (exe == "msedge" && (name.Contains("edge") || name.Contains("microsoftedge"))) return true;
            if (IsMusicPlayer(exe) && (name.Contains(exe) || IsMusicPlayer(name))) return true;
            if (exe == "microsoft.media.player" || exe == "music.ui")
                return name.Contains("zunemusic") || name.Contains("mediaplayer");
            string leaf = Path.GetFileNameWithoutExtension(name);
            return name == exe || name == exe + ".exe" || leaf == exe ||
                id.IndexOf(name, StringComparison.OrdinalIgnoreCase) >= 0 ||
                (name.Contains("!") && id.IndexOf(name.Split('!')[0], StringComparison.OrdinalIgnoreCase) >= 0);
        }

        public static bool HasActiveCall()
        {
            IDeviceEnumerator enumerator = null;
            IDeviceCollection devices = null;
            try
            {
                var clsid = new Guid("BCDE0395-E52F-467C-8E3D-C4579291692E");
                enumerator = (IDeviceEnumerator)Activator.CreateInstance(Type.GetTypeFromCLSID(clsid, true));
                enumerator.EnumAudioEndpoints(1, 1, out devices);
                uint count;
                devices.GetCount(out count);
                for (uint index = 0; index < count; index++)
                {
                    IDevice device = null;
                    try
                    {
                        devices.Item(index, out device);
                        if (IsCallCapture(device)) return true;
                    }
                    catch (COMException) { }
                    catch (UnauthorizedAccessException) { }
                    finally { Release(device); }
                }
                return false;
            }
            catch (COMException) { return false; }
            catch (UnauthorizedAccessException) { return false; }
            finally { Release(devices); Release(enumerator); }
        }

        private static bool IsCallCapture(IDevice device)
        {
            Guid iid = typeof(ISessionManager).GUID;
            object manager = null;
            ISessionEnumerator sessions = null;
            try
            {
                device.Activate(ref iid, 23, IntPtr.Zero, out manager);
                ((ISessionManager)manager).GetSessionEnumerator(out sessions);
                int count;
                sessions.GetCount(out count);
                for (int index = 0; index < count; index++)
                {
                    object instance = null;
                    try
                    {
                        sessions.GetSession(index, out instance);
                        var control = instance as ISessionControl;
                        if (control == null) continue;
                        int state;
                        control.GetState(out state);
                        uint pid;
                        if (state != 1 || control.GetProcessId(out pid) < 0 || pid == 0) continue;
                        using (var process = Process.GetProcessById((int)pid))
                            if (MediaSession.IsCallSource(process.ProcessName) || MediaSession.IsCallSource(ReadAppId(pid)))
                                return true;
                    }
                    catch (ArgumentException) { }
                    catch (InvalidOperationException) { }
                    catch (System.ComponentModel.Win32Exception) { }
                    catch (COMException) { }
                    catch (UnauthorizedAccessException) { }
                    finally { Release(instance); }
                }
                return false;
            }
            finally { Release(sessions); Release(manager); }
        }

        private void Connect(string selected, string customPlayer)
        {

            IDeviceEnumerator enumerator = null;
            IDeviceCollection outputs = null;
            try
            {
                var clsid = new Guid("BCDE0395-E52F-467C-8E3D-C4579291692E");
                enumerator = (IDeviceEnumerator)Activator.CreateInstance(Type.GetTypeFromCLSID(clsid, true));
                enumerator.EnumAudioEndpoints(0, 1, out outputs);
                uint count;
                outputs.GetCount(out count);
                for (uint index = 0; index < count; index++)
                {
                    IDevice device = null;
                    try
                    {
                        outputs.Item(index, out device);
                        if (AddSessions(device, selected, customPlayer))
                        {
                            Guid meterId = typeof(IAudioMeter).GUID;
                            object output;
                            device.Activate(ref meterId, 23, IntPtr.Zero, out output);
                            outputMeters.Add((IAudioMeter)output);
                            TryBass(device);
                        }
                    }
                    catch (COMException) { }
                    catch (UnauthorizedAccessException) { }
                    finally { Release(device); }
                }
            }
            catch (COMException) { }
                    catch (UnauthorizedAccessException) { }
            finally { Release(outputs); Release(enumerator); }
        }

        private void TryBass(IDevice device)
        {
            string id;
            device.GetId(out id);
            if (bass != null)
            {
                if (id == bassDevice) keepBass = true;
                return;
            }
            Guid audioClient = typeof(BassCapture.IAudioClient).GUID;
            object client;
            try
            {
                device.Activate(ref audioClient, 23, IntPtr.Zero, out client);
                bass = new BassCapture((BassCapture.IAudioClient)client);
                bassDevice = id;
                keepBass = true;
            }
            catch (NotSupportedException) { }
            catch (COMException) { }
            catch (UnauthorizedAccessException) { }
        }

        private void CloseBass()
        {
            if (bass == null) return;
            bass.Dispose();
            bass = null;
            bassDevice = null;
        }

        private bool AddSessions(IDevice device, string selected, string customPlayer)
        {
            Guid iid = typeof(ISessionManager).GUID;
            object manager = null;
            ISessionEnumerator sessions = null;
            bool hasMusic = false, hasOther = false;
            try
            {
                device.Activate(ref iid, 23, IntPtr.Zero, out manager);
                ((ISessionManager)manager).GetSessionEnumerator(out sessions);
                int count;
                sessions.GetCount(out count);
                for (int index = 0; index < count; index++)
                {
                    object instance = null;
                    try
                    {
                        sessions.GetSession(index, out instance);
                        var control = instance as ISessionControl;
                        if (control == null) { hasOther = true; continue; }
                        int state;
                        control.GetState(out state);
                        if (state != 1) continue;
                        var meter = instance as IAudioMeter;
                        uint pid;
                        if (control.GetProcessId(out pid) < 0 || pid == 0)
                        {
                            if (meter == null) hasOther = true;
                            else { otherMeters.Add(meter); instance = null; }
                            continue;
                        }
                        string id;
                        control.GetSessionIdentifier(out id);
                        using (var process = Process.GetProcessById((int)pid))
                        {
                            string name = process.ProcessName;
                            if (MediaSession.IsCallSource(name) || MediaSession.IsCallSource(selected))
                            {
                                if (meter == null) hasOther = true;
                                else { callMeters.Add(meter); instance = null; }
                                continue;
                            }
                            string path = customPlayer.Length > 0 &&
                                string.Equals(Path.GetFileNameWithoutExtension(customPlayer), name, StringComparison.OrdinalIgnoreCase)
                                ? process.MainModule.FileName : "";
                            string appId = ReadAppId(pid);
                            bool direct = (appId.Length > 0 && string.Equals(selected, appId, StringComparison.OrdinalIgnoreCase)) ||
                                Matches(selected, name, id ?? "", customPlayer, path);
                            bool music = direct || IsMusicPlayer(name.ToLowerInvariant()) ||
                                IsMusicPlayer(appId.ToLowerInvariant()) || HasMusicProduct(process);
                            if (!music)
                            {
                                if (meter == null) hasOther = true;
                                else { otherMeters.Add(meter); instance = null; }
                                continue;
                            }
                            hasMusic = true;

                            if (meter != null)
                            {
                                (direct ? meters : musicMeters).Add(meter);
                                instance = null;
                            }
                        }
                    }
                    catch (ArgumentException) { hasOther = true; }
                    catch (InvalidOperationException) { hasOther = true; }
                    catch (System.ComponentModel.Win32Exception) { hasOther = true; }
                    catch (COMException) { hasOther = true; }
                    catch (UnauthorizedAccessException) { hasOther = true; }
                    finally { Release(instance); }
                }
            }
            finally { Release(sessions); Release(manager); }
            unmeteredOutput |= hasOther;
            return hasMusic;
        }

        private bool HasMusicProduct(Process process)
        {
            if (MediaSession.IsBrowser(process.ProcessName)) return false;
            var module = process.MainModule;
            if (module == null) return false;
            bool known;
            if (musicProducts.TryGetValue(module.FileName, out known)) return known;
            string product = module.FileVersionInfo.ProductName ?? "";
            known = !MediaSession.IsCallSource(product) && IsMusicPlayer(product.ToLowerInvariant());
            musicProducts[module.FileName] = known;
            return known;
        }

        [DllImport("kernel32.dll")] private static extern IntPtr OpenProcess(uint access, bool inherit, uint id);
        [DllImport("kernel32.dll")] private static extern bool CloseHandle(IntPtr handle);
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode)]
        private static extern int GetApplicationUserModelId(IntPtr process, ref uint length, StringBuilder appId);

        private static string ReadAppId(uint pid)
        {
            IntPtr handle = OpenProcess(0x1000, false, pid);
            if (handle == IntPtr.Zero) return "";
            try
            {
                uint length = 0;
                if (GetApplicationUserModelId(handle, ref length, null) != 122 || length > 512) return "";
                var buffer = new StringBuilder((int)length);
                return GetApplicationUserModelId(handle, ref length, buffer) == 0 ? buffer.ToString() : "";
            }
            finally { CloseHandle(handle); }
        }

        private static void Release(object value)
        {
            if (value != null) Marshal.ReleaseComObject(value);
        }

        private void ClearMeters()
        {
            foreach (IAudioMeter meter in meters) Release(meter);
            meters.Clear();
            foreach (IAudioMeter meter in musicMeters) Release(meter);
            musicMeters.Clear();
            foreach (IAudioMeter meter in outputMeters) Release(meter);
            outputMeters.Clear();
            foreach (IAudioMeter meter in otherMeters) Release(meter);
            otherMeters.Clear();
            foreach (IAudioMeter meter in callMeters) Release(meter);
            callMeters.Clear();
        }

        public void Dispose()
        {
            stopped = true;
            wake.Set();
        }
    }
}

















