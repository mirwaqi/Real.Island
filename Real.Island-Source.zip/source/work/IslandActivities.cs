using System;
using System.Collections.Concurrent;
using System.Globalization;
using System.Device.Location;
using System.IO;
using System.Media;
using System.Net;
using System.Threading;
using System.Web.Script.Serialization;

namespace IslandDesktop
{
    internal sealed class WeatherForecast
    {
        static WeatherForecast()
        {
            // The legacy compiler defaults to SSL 3.0 and TLS 1.0 without an explicit setting.
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
        }

        public string City, Date, Summary, Detail;
        public string AlertHour;
        public string Symbol, AlertSymbol;

        internal sealed class LocationLookupException : Exception
        {
            public LocationLookupException(string message, Exception inner = null) : base(message, inner) { }
        }

        private sealed class Location
        {
            public string city { get; set; }
            public string loc { get; set; }
        }
        private static Location lastNetworkLocation;
        private static DateTime lastNetworkLookup;
        private sealed class ForecastResult
        {
            public Daily daily { get; set; }
            public Current current { get; set; }
            public Hourly hourly { get; set; }
        }
        private sealed class Current
        {
            public string time { get; set; }
            public double? wind_speed_10m { get; set; }
        }
        private sealed class Hourly
        {
            public string[] time { get; set; }
            public int?[] precipitation_probability { get; set; }
            public int[] weather_code { get; set; }
        }
        private sealed class Daily
        {
            public string[] time { get; set; }
            public int[] weather_code { get; set; }
            public double[] temperature_2m_max { get; set; }
            public double[] temperature_2m_min { get; set; }
            public int?[] precipitation_probability_max { get; set; }
        }

        private static T Read<T>(string url)
        {
            var request = (HttpWebRequest)WebRequest.Create(url);
            request.Timeout = request.ReadWriteTimeout = 6500;
            request.Accept = "application/json";
            request.UserAgent = "Real.Island/2.3";
            using (var response = request.GetResponse())
            using (var reader = new StreamReader(response.GetResponseStream()))
                return new JavaScriptSerializer().Deserialize<T>(reader.ReadToEnd());
        }

        public static WeatherForecast FetchLocal(bool allowApproximate)
        {
            using (var ready = new ManualResetEventSlim())
            using (var watcher = new GeoCoordinateWatcher(GeoPositionAccuracy.Default))
            {
                EventHandler<GeoPositionStatusChangedEventArgs> status = (sender, args) => {
                    if (args.Status == GeoPositionStatus.Ready || args.Status == GeoPositionStatus.Disabled) ready.Set();
                };
                watcher.StatusChanged += status;
                GeoCoordinate coordinates;
                try
                {
                    watcher.Start(true);
                    if (watcher.Status != GeoPositionStatus.Ready) ready.Wait(TimeSpan.FromSeconds(5));
                    coordinates = watcher.Position.Location;
                }
                finally { watcher.StatusChanged -= status; }
                if (!coordinates.IsUnknown)
                    return Fetch(Math.Round(coordinates.Latitude, 1), Math.Round(coordinates.Longitude, 1), "Погода рядом");
                if (watcher.Permission == GeoPositionPermission.Denied || !allowApproximate) return null;
            }
            Location place = lastNetworkLocation;
            try
            {
                if (place == null || DateTime.UtcNow - lastNetworkLookup >= TimeSpan.FromHours(2))
                    place = Read<Location>("https://ipinfo.io/json");
            }
            catch (WebException ex)
            {
                var response = ex.Response as HttpWebResponse;
                using (response)
                {
                    string detail = response == null ? "" : " (HTTP " + (int)response.StatusCode + ")";
                    if (place == null) throw new LocationLookupException("IPinfo не смог определить город" + detail + ".", ex);
                }
            }
            if (place == null) throw new LocationLookupException("IPinfo не вернул данные о городе.");
            string[] parts = (place.loc ?? "").Split(',');
            double latitude, longitude;
            if (parts.Length != 2 ||
                !double.TryParse(parts[0], NumberStyles.Float, CultureInfo.InvariantCulture, out latitude) ||
                !double.TryParse(parts[1], NumberStyles.Float, CultureInfo.InvariantCulture, out longitude) ||
                !(Math.Abs(latitude) <= 90 && Math.Abs(longitude) <= 180))
                throw new LocationLookupException("IPinfo не вернул координаты города.");
            if (place != lastNetworkLocation)
            {
                lastNetworkLocation = place;
                lastNetworkLookup = DateTime.UtcNow;
            }
            return Fetch(Math.Round(latitude, 1), Math.Round(longitude, 1),
                string.IsNullOrWhiteSpace(place.city) ? "Погода по IP" : place.city + " · по IP");
        }

        internal static WeatherForecast Fetch(double latitude, double longitude, string label)
        {
            string url = string.Format(CultureInfo.InvariantCulture,
                "https://api.open-meteo.com/v1/forecast?latitude={0}&longitude={1}&timezone=auto&forecast_days=1" +
                "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max" +
                "&current=wind_speed_10m&hourly=weather_code,precipitation_probability",
                latitude, longitude);
            var forecast = Read<ForecastResult>(url);
            var day = forecast.daily;
            int code = day.weather_code[0];
            string conditions = code == 0 ? "Ясно" : code < 3 ? "Переменная облачность" : code == 3 ? "Облачно" :
                code < 50 ? "Туман" : code >= 95 ? "Гроза" : (code >= 71 && code <= 77 || code == 85 || code == 86) ? "Снег" : "Дождь";
            var result = new WeatherForecast {
                City = label, Date = day.time[0],
                Summary = string.Format("{0} · {1:0}°…{2:0}°", conditions, day.temperature_2m_min[0], day.temperature_2m_max[0]),
                Symbol = WeatherSymbol(code, forecast.current == null ? 0 : forecast.current.wind_speed_10m.GetValueOrDefault())
            };
            result.Detail = Precipitation(forecast, out result.AlertHour, out result.AlertSymbol);
            return result;
        }

        internal static string WeatherSymbol(int code, double wind)
        {
            if (code >= 95) return "⛈";
            if ((code >= 71 && code <= 77) || code == 85 || code == 86) return "🌨";
            if (code >= 51) return "🌧";
            if (code >= 45) return "🌫";
            if (wind >= 30) return "🌬";
            if (code == 0) return "☀";
            return code < 3 ? "⛅" : "☁";
        }

        private static string Precipitation(ForecastResult forecast, out string alertHour, out string alertSymbol)
        {
            alertHour = null;
            alertSymbol = null;
            int? maximum = forecast.daily.precipitation_probability_max[0];
            string probability = maximum.HasValue ? "Вероятность осадков до " + maximum + "%" : "";
            var hours = forecast.hourly;
            if (hours == null || forecast.current == null) return probability;
            string currentHour = forecast.current.time.Substring(0, 13);
            string nextHour = DateTime.ParseExact(forecast.current.time, "yyyy-MM-ddTHH:mm",
                CultureInfo.InvariantCulture).AddHours(1).ToString("yyyy-MM-ddTHH", CultureInfo.InvariantCulture);
            string timing = "";
            for (int i = 0; i < hours.time.Length; i++)
            {
                if (string.CompareOrdinal(hours.time[i], currentHour) < 0 || hours.weather_code[i] < 51) continue;
                int chance = hours.precipitation_probability[i].GetValueOrDefault();
                if (chance < 45 && hours.weather_code[i] < 95) continue;
                if (alertHour == null && string.CompareOrdinal(hours.time[i].Substring(0, 13), nextHour) <= 0 &&
                    (chance >= 70 || hours.weather_code[i] >= 95))
                {
                    alertHour = hours.time[i];
                    alertSymbol = WeatherSymbol(hours.weather_code[i], 0);
                }
                if (timing.Length == 0)
                    timing = hours.time[i].StartsWith(currentHour, StringComparison.Ordinal) ? "Осадки в ближайший час" :
                        "Осадки около " + hours.time[i].Substring(11, 5);
            }
            if (timing.Length == 0) return probability;
            return timing + (probability.Length == 0 ? "" : " · " + probability);
        }
    }

    internal sealed class DownloadMonitor : IDisposable
    {
        private readonly ConcurrentQueue<Tuple<DateTime, IslandNotice>> events = new ConcurrentQueue<Tuple<DateTime, IslandNotice>>();
        private FileSystemWatcher watcher;

        public void Start(string folder)
        {
            if (watcher != null || !Directory.Exists(folder)) return;
            try
            {
                watcher = new FileSystemWatcher(folder) { NotifyFilter = NotifyFilters.FileName };
                watcher.Created += (sender, e) => Changed(e.Name, null);
                watcher.Renamed += (sender, e) => Changed(e.Name, e.OldName);
                watcher.EnableRaisingEvents = true;
            }
            catch (IOException) { Dispose(); }
            catch (UnauthorizedAccessException) { Dispose(); }
        }

        private static bool Partial(string name)
        {
            string extension = Path.GetExtension(name);
            return string.Equals(extension, ".crdownload", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(extension, ".part", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(extension, ".download", StringComparison.OrdinalIgnoreCase);
        }

        private void Changed(string name, string oldName)
        {
            if (Partial(name))
            {
                if (!Partial(oldName))
                {
                    string title = name.StartsWith("Unconfirmed ", StringComparison.OrdinalIgnoreCase)
                        ? "Браузер начал скачивание" : Path.GetFileNameWithoutExtension(name);
                    events.Enqueue(Tuple.Create(DateTime.UtcNow, new IslandNotice { App = "Загрузка", Title = title }));
                }
            }
            else if (Partial(oldName))
            {
                events.Enqueue(Tuple.Create(DateTime.UtcNow, new IslandNotice { App = "Скачано", Title = name }));
            }
        }

        public IslandNotice Next()
        {
            Tuple<DateTime, IslandNotice> notice;
            IslandNotice latest = null;
            DateTime cutoff = DateTime.UtcNow.AddSeconds(-20);
            while (events.TryDequeue(out notice))
                if (notice.Item1 >= cutoff) latest = notice.Item2;
            return latest;
        }

        public void Dispose()
        {
            if (watcher != null) watcher.Dispose();
            watcher = null;
            Tuple<DateTime, IslandNotice> ignored;
            while (events.TryDequeue(out ignored)) { }
        }
    }

    internal static class NoticeChime
    {
        private static readonly SoundPlayer player = Create();

        private static SoundPlayer Create()
        {
            const int rate = 22050, samples = 6174;
            var wave = new MemoryStream();
            var writer = new BinaryWriter(wave);
            writer.Write(0x46464952); writer.Write(36 + samples * 2); writer.Write(0x45564157);
            writer.Write(0x20746D66); writer.Write(16); writer.Write((short)1); writer.Write((short)1);
            writer.Write(rate); writer.Write(rate * 2); writer.Write((short)2); writer.Write((short)16);
            writer.Write(0x61746164); writer.Write(samples * 2);
            for (int i = 0; i < samples; i++)
            {
                double time = i / (double)rate;
                double first = Tone(time, 659), second = Tone(time - .068, 988);
                writer.Write((short)(3400 * (first + second)));
            }
            wave.Position = 0;
            return new SoundPlayer(wave);
        }

        private static double Tone(double time, double pitch)
        {
            if (time <= 0 || time >= .19) return 0;
            double envelope = Math.Min(1, time / .012) * Math.Pow(1 - time / .19, 2);
            return Math.Sin(2 * Math.PI * pitch * time) * envelope;
        }

        public static void Play()
        {
            try { player.Play(); }
            catch (InvalidOperationException) { }
            catch (TimeoutException) { }
        }
    }
}
