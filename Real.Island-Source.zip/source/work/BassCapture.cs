using System;
using System.Runtime.InteropServices;

namespace IslandDesktop
{
    internal sealed class BassCapture : IDisposable
    {
        [ComImport, Guid("1CB9AD4C-DBFA-4c32-B178-C2F568A703B2"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        internal interface IAudioClient
        {
            void Initialize(int mode, uint flags, long duration, long period, IntPtr format, IntPtr session);
            void GetBufferSize(out uint size);
            void GetStreamLatency(out long latency);
            void GetCurrentPadding(out uint frames);
            void IsFormatSupported();
            void GetMixFormat(out IntPtr format);
            void GetDevicePeriod(out long regular, out long minimum);
            void Start();
            void Stop();
            void Reset();
            void SetEventHandle(IntPtr handle);
            void GetService(ref Guid iid, [MarshalAs(UnmanagedType.IUnknown)] out object service);
        }

        [ComImport, Guid("C8ADBD64-E71E-48a0-A4DE-185C395CD317"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        private interface ICapture
        {
            void GetBuffer(out IntPtr data, out uint frames, out uint flags, out ulong position, out ulong stamp);
            void ReleaseBuffer(uint frames);
            void GetNextPacketSize(out uint frames);
        }

        private readonly IAudioClient client;
        private ICapture capture;
        private int sampleBytes, frameBytes, channels;
        internal const int BandCount = 5;
        private SpectrumBand[] bands;
        private bool isFloat;

        public BassCapture(IAudioClient client)
        {
            this.client = client;
            IntPtr format = IntPtr.Zero;
            try
            {
                client.GetMixFormat(out format);
                int rate = Marshal.ReadInt32(format, 4);
                channels = Marshal.ReadInt16(format, 2);
                frameBytes = Marshal.ReadInt16(format, 12);
                sampleBytes = Marshal.ReadInt16(format, 14) / 8;
                int type = (ushort)Marshal.ReadInt16(format, 0);
                if (type == 0xfffe) type = Marshal.ReadInt32(format, 24);
                isFloat = type == 3 && sampleBytes == 4;
                if ((!isFloat && (type != 1 || (sampleBytes != 2 && sampleBytes != 4))) || rate <= 0 || channels < 1 || frameBytes < sampleBytes * channels)
                    throw new NotSupportedException();
                bands = CreateBands(rate);
                client.Initialize(0, 0x20000, 1000000, 0, format, IntPtr.Zero);
                Guid iid = typeof(ICapture).GUID;
                object service;
                client.GetService(ref iid, out service);
                capture = (ICapture)service;
                client.Start();
            }
            catch { Dispose(); throw; }
            finally { if (format != IntPtr.Zero) Marshal.FreeCoTaskMem(format); }
        }

        private static SpectrumBand[] CreateBands(int rate)
        {
            double[] centers = { 62, 215, 780, 2700, 7000 };
            var filters = new SpectrumBand[BandCount];
            for (int i = 0; i < filters.Length; i++)
                filters[i] = new SpectrumBand(Math.Min(centers[i], rate * .40), rate);
            return filters;
        }

        public void Read(double[] peaks)
        {
            Array.Clear(peaks, 0, peaks.Length);
            uint frames;
            capture.GetNextPacketSize(out frames);
            while (frames != 0)
            {
                IntPtr data;
                uint flags;
                ulong position, stamp;
                capture.GetBuffer(out data, out frames, out flags, out position, out stamp);
                if (frames == 0) break;
                try
                {
                    if ((flags & 2) != 0 || data == IntPtr.Zero)
                    {
                        foreach (var band in bands) band.Reset();
                    }
                    else
                    {
                        for (int i = 0; i < frames; i++)
                        {
                            int offset = i * frameBytes;
                            double left = ReadSample(data, offset);
                            double right = channels > 1 ? ReadSample(data, offset + sampleBytes) : 0;
                            for (int band = 0; band < bands.Length; band++)
                            {
                                double energy = bands[band].Process(left, right);
                                if (energy > peaks[band]) peaks[band] = energy;
                            }
                        }
                    }
                }
                finally { capture.ReleaseBuffer(frames); }
                capture.GetNextPacketSize(out frames);
            }
        }

        private double ReadSample(IntPtr data, int offset)
        {
            return isFloat ? new FloatSample { Bits = Marshal.ReadInt32(data, offset) }.Value :
                sampleBytes == 2 ? Marshal.ReadInt16(data, offset) / 32768d : Marshal.ReadInt32(data, offset) / 2147483648d;
        }

        private sealed class SpectrumBand
        {
            private readonly double gain, a1, a2;
            private double left1, left2, right1, right2;

            public SpectrumBand(double frequency, int rate)
            {
                double omega = 2 * Math.PI * frequency / rate;
                double alpha = Math.Sin(omega) / 1.8;
                gain = alpha / (1 + alpha);
                a1 = -2 * Math.Cos(omega) / (1 + alpha);
                a2 = (1 - alpha) / (1 + alpha);
            }

            private double Filter(double sample, ref double state1, ref double state2)
            {
                double output = gain * sample + state1;
                state1 = state2 - a1 * output;
                state2 = -gain * sample - a2 * output;
                return output;
            }

            public double Process(double left, double right)
            {
                return Math.Max(Math.Abs(Filter(left, ref left1, ref left2)),
                    Math.Abs(Filter(right, ref right1, ref right2)));
            }

            public void Reset() { left1 = left2 = right1 = right2 = 0; }
        }

#if SMOKE_TEST
        internal static double[] TestTone(double frequency)
        {
            const int rate = 48000;
            var filters = CreateBands(rate);
            var peaks = new double[BandCount];
            for (int i = 0; i < rate / 4; i++)
            {
                double sample = .6 * Math.Sin(2 * Math.PI * frequency * i / rate);
                for (int band = 0; band < peaks.Length; band++)
                {
                    double value = filters[band].Process(sample, -sample);
                    if (i >= rate / 8) peaks[band] = Math.Max(peaks[band], value);
                }
            }
            return peaks;
        }
#endif

        [StructLayout(LayoutKind.Explicit)]
        private struct FloatSample { [FieldOffset(0)] public float Value; [FieldOffset(0)] public int Bits; }

        public void Dispose()
        {
            if (capture != null)
            {
                try { client.Stop(); }
                catch (COMException) { }
                Marshal.ReleaseComObject(capture);
                capture = null;
            }
            Marshal.ReleaseComObject(client);
        }
    }
}


