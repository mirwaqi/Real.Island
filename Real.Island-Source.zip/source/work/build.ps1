param([switch]$SmokeTest)
$ErrorActionPreference='Stop'
$framework = Join-Path $env:windir 'Microsoft.NET\Framework64\v4.0.30319'
$csc = Join-Path $framework 'csc.exe'
$wpf = Join-Path $framework 'WPF'
$metadata = Join-Path $env:windir 'System32\WinMetadata'
$output = 'outputs\Real.Island.exe'
$define = @()
if ($SmokeTest) {
  $output = 'work\IslandDesktop.exe'
  $define = @('/define:SMOKE_TEST')
}
& $csc @define /nologo /target:winexe /platform:anycpu /optimize+ /warn:4 /codepage:65001 "/out:$output" /win32manifest:work\app.manifest /win32icon:work\Island.ico /resource:work\Island.ico,Island.ico /reference:"$wpf\PresentationFramework.dll" /reference:"$wpf\PresentationCore.dll" /reference:"$wpf\WindowsBase.dll" /reference:System.Xaml.dll /reference:System.Runtime.dll /reference:System.Runtime.WindowsRuntime.dll /reference:System.Runtime.InteropServices.WindowsRuntime.dll /reference:"$metadata\Windows.Media.winmd" /reference:"$metadata\Windows.Foundation.winmd" /reference:"$metadata\Windows.Storage.winmd" /reference:"$metadata\Windows.Devices.winmd" /reference:"$wpf\UIAutomationProvider.dll" /reference:System.Drawing.dll /reference:System.Windows.Forms.dll work\Core.cs work\WindowsIntegration.cs work\Overlays.cs work\Dashboard.cs work\MediaSession.cs work\TaskbarMode.cs work\IslandSettings.cs work\AppPicker.cs work\Installation.cs
exit $LASTEXITCODE















