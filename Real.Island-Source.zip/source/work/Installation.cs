using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Threading;
using System.Windows;
using Microsoft.Win32;

namespace IslandDesktop
{
    internal static class Installation
    {
        public const string Brand = "Real.Island";
        internal const string MutexName = @"Local\IslandDesktop.SingleInstance";
        internal const string QuitName = @"Local\RealIsland.Quit";
        private const string RunKey = @"Software\Microsoft\Windows\CurrentVersion\Run";
        private const string UninstallKey = @"Software\Microsoft\Windows\CurrentVersion\Uninstall\Real.Island";
        private static readonly string Folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Programs", Brand);
        private static readonly string Installed = Path.Combine(Folder, "Real.Island.exe");
        private static string Current { get { return Assembly.GetExecutingAssembly().Location; } }
        private static string Command(string path, string option) { return "\"" + path + "\" " + option; }
        private static string StartupTaskName(string sid) { return Brand + " Logon " + sid; }

        private static bool UpdateStartupTask(bool enable, string path)
        {
            try
            {
                string sid;
                using (var identity = WindowsIdentity.GetCurrent()) sid = identity.User.Value;
                dynamic scheduler = Activator.CreateInstance(Type.GetTypeFromProgID("Schedule.Service", true));
                scheduler.Connect();
                dynamic root = scheduler.GetFolder("\\");
                string name = StartupTaskName(sid);
                if (!enable)
                {
                    root.DeleteTask(name, 0);
                    return true;
                }
                dynamic task = scheduler.NewTask(0);
                task.RegistrationInfo.Description = "Запускает Real.Island при входе в Windows.";
                task.Principal.UserId = sid;
                task.Principal.LogonType = 3;
                task.Settings.ExecutionTimeLimit = "PT0S";
                task.Settings.DisallowStartIfOnBatteries = false;
                task.Settings.StopIfGoingOnBatteries = false;
                task.Settings.RestartInterval = "PT1M";
                task.Settings.RestartCount = 3;
                dynamic trigger = task.Triggers.Create(9);
                trigger.UserId = sid;
                trigger.Delay = "PT3S";
                dynamic action = task.Actions.Create(0);
                action.Path = path;
                action.Arguments = "--startup";
                action.WorkingDirectory = Path.GetDirectoryName(path);
                root.RegisterTaskDefinition(name, task, 6, sid, null, 3, null);
                return true;
            }
            catch (COMException) { return false; }
            catch (UnauthorizedAccessException) { return false; }
            catch (Microsoft.CSharp.RuntimeBinder.RuntimeBinderException) { return false; }
        }

        public static bool Exists
        {
            get { return File.Exists(Installed); }
        }

        public static bool HasInstalledUpdate()
        {
            if (!Exists || string.Equals(Current, Installed, StringComparison.OrdinalIgnoreCase)) return false;
            return Assembly.GetExecutingAssembly().GetName().Version >
                AssemblyName.GetAssemblyName(Installed).Version;
        }

        public static void UpdateInstalledCopy()
        {
            string staged = Path.Combine(Folder, Guid.NewGuid().ToString("N") + ".tmp");
            try
            {
                File.Copy(Current, staged);
                File.Replace(staged, Installed, null);
                if (StartupEnabled()) SetStartup(true);
                using (var entry = Registry.CurrentUser.OpenSubKey(UninstallKey, true))
                    if (entry != null) entry.SetValue("DisplayVersion", Assembly.GetExecutingAssembly().GetName().Version.ToString(3));
            }
            finally { File.Delete(staged); }
        }

        public static void Install()
        {
            Directory.CreateDirectory(Folder);
            if (!string.Equals(Current, Installed, StringComparison.OrdinalIgnoreCase))
                File.Copy(Current, Installed, true);
            using (var entry = Registry.CurrentUser.CreateSubKey(UninstallKey))
            {
                entry.SetValue("DisplayName", Brand);
                entry.SetValue("DisplayVersion", Assembly.GetExecutingAssembly().GetName().Version.ToString(3));
                entry.SetValue("DisplayIcon", Installed);
                entry.SetValue("InstallLocation", Folder);
                entry.SetValue("UninstallString", Command(Installed, "--uninstall"));
                entry.SetValue("NoModify", 1, RegistryValueKind.DWord);
                entry.SetValue("NoRepair", 1, RegistryValueKind.DWord);
            }
            SetStartup(true);
        }

        public static bool StartupEnabled()
        {
            string path = Exists ? Installed : Current;
            try
            {
                using (var key = Registry.CurrentUser.OpenSubKey(RunKey))
                    return key != null && string.Equals(key.GetValue(Brand) as string, Command(path, "--startup"), StringComparison.OrdinalIgnoreCase);
            }
            catch (System.Security.SecurityException) { return false; }
            catch (UnauthorizedAccessException) { return false; }
        }

        public static void SetStartup(bool enable)
        {
            string path = Exists ? Installed : Current;
            UpdateStartupTask(enable && Exists, path);
            using (var key = Registry.CurrentUser.CreateSubKey(RunKey))
            {
                if (enable)
                {
                    key.SetValue(Brand, Command(path, "--startup"));
                    key.DeleteValue("Island Desktop", false);
                }
                else key.DeleteValue(Brand, false);
            }
        }

        public static int BeginRemoval()
        {
            if (!Exists) return 0;
            if (MessageBox.Show("Удалить Real.Island из Windows?", Brand, MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
                return 0;

            try
            {
                using (var quit = EventWaitHandle.OpenExisting(QuitName))
                    quit.Set();
            }
            catch (WaitHandleCannotBeOpenedException) { }
            string helper = Path.Combine(Path.GetTempPath(), "Real.Island-Uninstall-" + Guid.NewGuid().ToString("N") + ".exe");
            try
            {
                File.Copy(Installed, helper);
                Process.Start(new ProcessStartInfo(helper, "--finish-uninstall " + App.ProcessId) { UseShellExecute = false, CreateNoWindow = true });
                return 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Удаление не запустилось. " + ex.Message, Brand);
                return 1;
            }
        }

        public static int FinishRemoval(int launcherId)
        {
            try
            {
                try
                {
                    using (var launcher = Process.GetProcessById(launcherId))
                        if (!launcher.WaitForExit(8000)) throw new IOException("Окно удаления всё ещё открыто.");
                }
                catch (ArgumentException) { }

                using (var guard = new Mutex(false, MutexName))
                {
                    bool acquired;
                    try { acquired = guard.WaitOne(8000); }
                    catch (AbandonedMutexException) { acquired = true; }
                    if (!acquired) throw new IOException("Закройте Real.Island и запустите удаление снова.");
                    try
                    {
                        File.Delete(Installed);
                        SetStartup(false);
                        Registry.CurrentUser.DeleteSubKeyTree(UninstallKey, false);
                        if (Directory.Exists(Folder) && Directory.GetFileSystemEntries(Folder).Length == 0)
                            Directory.Delete(Folder);
                    }
                    finally { guard.ReleaseMutex(); }
                }
                MessageBox.Show("Удачи! Надеемся, что ты ещё вернёшься.", Brand, MessageBoxButton.OK, MessageBoxImage.Information);
                return 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Удаление не завершено. " + ex.Message, Brand, MessageBoxButton.OK, MessageBoxImage.Error);
                return 1;
            }
        }
    }
}

