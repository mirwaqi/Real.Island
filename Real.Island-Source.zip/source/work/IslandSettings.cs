using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Threading;
using Microsoft.Win32;
using Windows.Devices.Radios;

namespace IslandDesktop
{
    internal sealed class IslandSettings : StackPanel
    {
        private readonly Preferences prefs;
        private readonly Window owner;
        private readonly Action apply, save, resize;
        private readonly Border page = new Border();
        private readonly Panel[] pages = new Panel[4];
        private readonly TextBlock status = Theme.TextAt("", 11, Theme.Muted);
        private readonly DispatcherTimer notesDelay;
        private readonly List<Button> tabs = new List<Button>();
        private readonly Button wifi, bluetooth;
        private RadioAccessStatus? radioAccess;
        private bool radioBusy;
        private int tab;

        public IslandSettings(Preferences prefs, Window owner, Action apply, Action save, Action resize, Action stop)
        {
            this.prefs = prefs;
            this.owner = owner;
            this.apply = apply;
            this.save = save;
            this.resize = resize;
            Margin = new Thickness(0, 0, 0, 3);
            notesDelay = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(350) };
            notesDelay.Tick += delegate { Flush(); };

            var navigation = new UniformGrid { Columns = 4, Margin = new Thickness(0, 2, 0, 9) };
            foreach (string name in new[] { "Связь", "Вид", "Заметки", "Приложения" })
            {
                int index = tabs.Count;
                var button = Theme.Button(name, delegate { Select(index); }, "#26232E", 26, 9);
                button.FontSize = 11;
                button.Padding = new Thickness(2, 0, 2, 0);
                button.Margin = new Thickness(2, 0, 2, 0);
                tabs.Add(button);
                navigation.Children.Add(button);
            }
            Children.Add(navigation);
            Children.Add(page);
            status.Margin = new Thickness(3, 5, 3, 0);
            status.TextWrapping = TextWrapping.Wrap;
            status.MaxHeight = 27;
            status.MinHeight = 13;
            Children.Add(status);
            var footer = Theme.Row();
            footer.HorizontalAlignment = HorizontalAlignment.Right;
            footer.Margin = new Thickness(0, 3, 0, 0);
            var off = Theme.Button("Выключить островок", stop, "#2B2632", 23, 8);
            off.FontSize = 11;
            footer.Children.Add(off);
            Children.Add(footer);

            wifi = Theme.Button("Wi-Fi", delegate { ToggleRadio(RadioKind.WiFi, "ms-settings:network-wifi"); }, "#323044", 31, 9);
            bluetooth = Theme.Button("Bluetooth", delegate { ToggleRadio(RadioKind.Bluetooth, "ms-settings:bluetooth"); }, "#323044", 31, 9);
        }

        public double MeasureHeight(double width)
        {
            Width = width;
            Measure(new Size(width, double.PositiveInfinity));
            return Math.Ceiling(DesiredSize.Height);
        }

        public void Select(int index)
        {
            Flush();
            tab = index;
            Report("");
            for (int i = 0; i < tabs.Count; i++) tabs[i].Background = Theme.Paint(i == tab ? "#634F92" : "#26232E");
            if (pages[tab] == null) switch (tab)
            {
                case 0: pages[tab] = Connections(); break;
                case 1: pages[tab] = Appearance(); break;
                case 2: pages[tab] = NotesPage(); break;
                case 3: pages[tab] = AppsPage(); break;
            }
            page.Child = pages[tab];
            if (tab == 0) RefreshRadios();
            resize();
        }

        public void Flush()
        {
            if (!notesDelay.IsEnabled) return;
            notesDelay.Stop();
            save();
        }

        private Panel Connections()
        {
            var previous = wifi.Parent as Panel;
            if (previous != null) previous.Children.Clear();
            var grid = new UniformGrid { Columns = 2 };
            AddTile(grid, wifi);
            AddTile(grid, bluetooth);
            AddLink(grid, "Сети Wi-Fi", "ms-settings:network-wifi");
            AddLink(grid, "Устройства Bluetooth", "ms-settings:bluetooth");
            AddLink(grid, "Звук", "ms-settings:sound");
            AddLink(grid, "Экран", "ms-settings:display");
            AddLink(grid, "Режим полёта", "ms-settings:network-airplanemode");
            AddLink(grid, "Все параметры", "ms-settings:");
            AddTile(grid, Theme.Button("Звук −", delegate { WindowsIntegration.MediaKey(0xAE); }, "#282632", 25, 8));
            AddTile(grid, Theme.Button("Звук +", delegate { WindowsIntegration.MediaKey(0xAF); }, "#282632", 25, 8));
            return grid;
        }

        private async void RefreshRadios()
        {
            try
            {
                var radios = await GetRadios();
                UpdateRadioLabel(wifi, "Wi-Fi", radios.Where(r => r.Kind == RadioKind.WiFi));
                UpdateRadioLabel(bluetooth, "Bluetooth", radios.Where(r => r.Kind == RadioKind.Bluetooth));
            }
            catch (Exception) { }
        }

        private static Task<IReadOnlyList<Radio>> GetRadios()
        {
            return MediaSession.Read<IReadOnlyList<Radio>>(Radio.GetRadiosAsync());
        }

        private static void UpdateRadioLabel(Button button, string label, IEnumerable<Radio> radios)
        {
            var states = radios.Select(r => r.State).ToArray();
            bool enabled = states.Contains(RadioState.On);
            button.Content = states.Length == 0 ? label : label + (enabled ? "  ·  Вкл" : "  ·  Выкл");
            button.Background = Theme.Paint(enabled ? "#54447E" : "#323044");
        }

        private async void ToggleRadio(RadioKind kind, string fallback)
        {
            if (radioBusy) return;
            radioBusy = true;
            wifi.IsEnabled = bluetooth.IsEnabled = false;
            try
            {
                var matches = (await GetRadios()).Where(r => r.Kind == kind &&
                    (r.State == RadioState.On || r.State == RadioState.Off)).ToArray();
                if (matches.Length == 0) { OpenRadioSettings(fallback); return; }
                if (!radioAccess.HasValue)
                    radioAccess = await MediaSession.Read<RadioAccessStatus>(Radio.RequestAccessAsync());
                if (radioAccess != RadioAccessStatus.Allowed) { OpenRadioSettings(fallback); return; }
                var desired = matches.Any(r => r.State == RadioState.On) ? RadioState.Off : RadioState.On;
                foreach (var radio in matches.Where(r => r.State != desired))
                {
                    if (await MediaSession.Read<RadioAccessStatus>(radio.SetStateAsync(desired)) != RadioAccessStatus.Allowed)
                    {
                        OpenRadioSettings(fallback);
                        return;
                    }
                }
                await Task.Delay(240);
                RefreshRadios();
            }
            catch (Exception) { OpenRadioSettings(fallback); }
            finally { radioBusy = false; wifi.IsEnabled = bluetooth.IsEnabled = true; }
        }

        private void OpenRadioSettings(string target)
        {
            Report("Переключатель доступен в параметрах Windows.");
            Open(target);
        }

        private Panel Appearance()
        {
            var stack = new StackPanel();
            var colors = new UniformGrid { Columns = 4, Margin = new Thickness(0, 0, 0, 4) };
            string[] names = { "Графит", "Слива", "Океан", "Мох" };
            string[] fills = { "#34333C", "#5F3C6D", "#265674", "#355D4A" };
            for (int i = 0; i < names.Length; i++)
            {
                int choice = i;
                var swatch = Theme.Button(names[i], delegate {
                    prefs.Tint = choice;
                    apply();
                    Report("Цвет · " + names[choice]);
                }, fills[i], 24, 8);
                swatch.FontSize = 11;
                swatch.Padding = new Thickness(1, 0, 1, 0);
                AddTile(colors, swatch);
            }
            stack.Children.Add(colors);
            AddSlider(stack, "Прозрачность", 0, 60, prefs.Transparency, "%", v => prefs.Transparency = v);
            AddSlider(stack, "Анимация", 160, 580, prefs.Animation, " мс", v => prefs.Animation = v);
            var options = new UniformGrid { Columns = 2, Margin = new Thickness(0, 3, 0, 4) };
            AddCheck(options, "Часы", prefs.Clock, v => { prefs.Clock = v; apply(); });
            AddCheck(options, "Музыка", prefs.Media, v => { prefs.Media = v; apply(); });
            AddCheck(options, "Серый контур", prefs.Outline, v => { prefs.Outline = v; apply(); });
            AddCheck(options, "Скрывать панель задач", prefs.HideTaskbar, v => { prefs.HideTaskbar = v; apply(); });
            AddCheck(options, "Скрывать в полноэкранном", prefs.HideFullscreen, v => { prefs.HideFullscreen = v; apply(); });
            CheckBox startup = null;
            startup = AddCheck(options, "Запускать с Windows", Preferences.StartsAtLogin(), v => {
                try
                {
                    Preferences.SetStartAtLogin(v);
                    Report(v ? "Островок будет запускаться при входе в Windows." : "Автозапуск выключен.");
                }
                catch (Exception) { Report("Windows не разрешила изменить автозапуск."); }
                startup.IsChecked = Preferences.StartsAtLogin();
            });
            stack.Children.Add(options);
            var wallpaper = new UniformGrid { Columns = 2 };
            AddTile(wallpaper, Theme.Button("Выбрать обои…", ChooseWallpaper, "#332B46", 26, 8));
            AddTile(wallpaper, Theme.Button("Аврора 4K", delegate { SetWallpaper(Preferences.Aurora); }, "#332B46", 26, 8));
            stack.Children.Add(wallpaper);
            var source = Theme.Row();
            source.Margin = new Thickness(2, 5, 0, 0);
            var chosen = Theme.TextAt("", 11, Theme.Muted);
            chosen.Width = 174;
            chosen.TextTrimming = TextTrimming.CharacterEllipsis;
            Action update = delegate {
                chosen.Text = prefs.ExtraPlayer.Length == 0 ? "Дополнительный плеер" : Path.GetFileName(prefs.ExtraPlayer);
                chosen.ToolTip = chosen.Text;
            };
            update();
            source.Children.Add(chosen);
            AddTile(source, Theme.Button("Выбрать EXE", delegate {
                var dialog = new OpenFileDialog {
                    Title = "Выберите исполняемый файл музыкального плеера",
                    Filter = "Программы (*.exe)|*.exe", CheckFileExists = true
                };
                if (dialog.ShowDialog(owner) != true) return;
                string name = Path.GetFileNameWithoutExtension(dialog.FileName);
                if (MediaSession.IsBrowser(name) || MediaSession.IsCallSource(name))
                {
                    Report("Выберите музыкальный плеер.");
                    return;
                }
                prefs.ExtraPlayer = dialog.FileName;
                update();
                apply();
            }, "#332B46", 25, 8));
            AddTile(source, Theme.Button("Сброс", delegate { prefs.ExtraPlayer = ""; update(); apply(); }, "#332B46", 25, 8));
            stack.Children.Add(source);
            return stack;
        }

        private void AddSlider(Panel panel, string label, int min, int max, int initial, string unit, Action<int> change)
        {
            var text = Theme.TextAt(label + " · " + initial + unit, 11, Theme.Muted);
            panel.Children.Add(text);
            var slider = new Slider { Minimum = min, Maximum = max, Value = initial, IsSnapToTickEnabled = true,
                TickFrequency = 1, SmallChange = 1, LargeChange = 10, Margin = new Thickness(0, 0, 0, 4) };
            System.Windows.Automation.AutomationProperties.SetName(slider, label);
            slider.ValueChanged += delegate {
                int value = (int)slider.Value;
                text.Text = label + " · " + value + unit;
                change(value);
                apply();
            };
            panel.Children.Add(slider);
        }

        private static CheckBox AddCheck(Panel panel, string name, bool initial, Action<bool> change)
        {
            var check = new CheckBox { Content = name, IsChecked = initial, FontSize = 10.5, Foreground = Theme.Text,
                VerticalContentAlignment = VerticalAlignment.Center, Margin = new Thickness(1, 2, 1, 2) };
            check.Click += delegate { change(check.IsChecked == true); };
            panel.Children.Add(check);
            return check;
        }

        private Panel NotesPage()
        {
            var stack = new StackPanel();
            var edit = new TextBox { Text = prefs.Notes, Height = 113, AcceptsReturn = true, MaxLength = 50000,
                TextWrapping = TextWrapping.Wrap, VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                Foreground = Theme.Text, Background = Theme.Paint("#25232D"), CaretBrush = Theme.Text,
                BorderBrush = Theme.Paint("#50475F"), Padding = new Thickness(7) };
            System.Windows.Automation.AutomationProperties.SetName(edit, "Текст заметок");
            edit.TextChanged += delegate {
                prefs.Notes = edit.Text;
                notesDelay.Stop();
                notesDelay.Start();
            };
            stack.Children.Add(edit);
            var hint = Theme.TextAt("Сохраняется автоматически", 11, Theme.Muted);
            hint.Margin = new Thickness(2, 4, 0, 0);
            stack.Children.Add(hint);
            return stack;
        }

        private Panel AppsPage()
        {
            var stack = new StackPanel();
            var list = new ListBox { Height = 101, Background = Theme.Paint("#25232D"), Foreground = Theme.Text,
                BorderBrush = Theme.Paint("#50475F") };
            System.Windows.Automation.AutomationProperties.SetName(list, "Ярлыки приложений");
            Action reload = delegate {
                list.Items.Clear();
                foreach (string path in prefs.Apps)
                    list.Items.Add(new ListBoxItem { Content = AppIcon.Label(path, false), Tag = path, Padding = new Thickness(6, 2, 2, 2) });
                if (list.Items.Count > 0) list.SelectedIndex = 0;
            };
            reload();
            Action launch = delegate {
                if (list.SelectedIndex >= 0) Open((string)((ListBoxItem)list.SelectedItem).Tag);
            };
            list.MouseDoubleClick += delegate { launch(); };
            stack.Children.Add(list);
            var controls = new UniformGrid { Columns = 3, Margin = new Thickness(0, 6, 0, 0) };
            AddTile(controls, Theme.Button("Открыть", launch, "#53417D", 25, 8));
            AddTile(controls, Theme.Button("Добавить…", delegate {
                if (prefs.Apps.Count >= 12) { Report("Можно добавить до 12 ярлыков."); return; }
                var picker = new AppPicker(prefs.Apps);
                var island = (Island)owner;
                island.SetPickerOpen(true);
                try
                {
                    if (picker.ShowDialog() != true) return;
                    prefs.Apps.AddRange(picker.Selected);
                    save();
                    reload();
                    list.SelectedIndex = list.Items.Count - 1;
                }
                finally { island.SetPickerOpen(false); }
            }, "#332B46", 25, 8));
            AddTile(controls, Theme.Button("Убрать", delegate {
                if (list.SelectedIndex < 0) return;
                prefs.Apps.Remove((string)((ListBoxItem)list.SelectedItem).Tag);
                save();
                reload();
            }, "#332B46", 25, 8));
            stack.Children.Add(controls);
            return stack;
        }

        private void ChooseWallpaper()
        {
            var dialog = new OpenFileDialog { Title = "Выберите обои", CheckFileExists = true,
                Filter = "Изображения|*.jpg;*.jpeg;*.png;*.bmp;*.gif;*.tif;*.tiff;*.webp;*.heic;*.avif" };
            if (dialog.ShowDialog(owner) == true) SetWallpaper(dialog.FileName);
        }

        private void SetWallpaper(string file)
        {
            try
            {
                Wallpaper.Apply(file);
                prefs.Wallpaper = file;
                save();
                Report("Обои установлены.");
            }
            catch (Exception) { Report("Windows не смогла установить эти обои."); }
        }

        private void AddLink(Panel panel, string title, string uri)
        {
            AddTile(panel, Theme.Button(title, delegate { Open(uri); }, "#282632", 27, 8));
        }

        private static void AddTile(Panel panel, Button button)
        {
            button.Margin = new Thickness(2, 2, 2, 2);
            button.Padding = new Thickness(3, 0, 3, 0);
            button.FontSize = 11;
            panel.Children.Add(button);
        }

        private void Open(string target)
        {
            try { Process.Start(new ProcessStartInfo(target) { UseShellExecute = true }); }
            catch (Exception) { Report("Не удалось открыть. Проверьте, доступен ли файл или раздел Windows."); }
        }

        public void Report(string message)
        {
            if (status.Text == message) return;
            status.Text = message;
            resize();
        }
    }
}









