using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Threading;
using Microsoft.Win32;
using Windows.Devices.Radios;

namespace IslandDesktop
{
    internal sealed class IslandSettings : StackPanel
    {
        private readonly Preferences prefs;
        private readonly Window owner;
        private readonly Action apply, save, resize;
        private readonly Border page = new Border();
        internal const int HomeTab = 4;
        private const int CustomizeTab = 5;
        private const int RemindersTab = 6;
        private readonly Panel[] pages = new Panel[7];
        private StackPanel remindersList;
        private readonly TextBlock section = Theme.TextAt("", 14, Theme.Text, true);
        private Action refreshHomeApps, refreshAppsPage;
        private readonly ScrollViewer pageScroll;
        private readonly TextBlock status = Theme.TextAt("", 11, Theme.Muted);
        private readonly DispatcherTimer notesDelay;
        private readonly List<Button> tabs = new List<Button>();
        private readonly Button wifi, bluetooth;
        private Button homeWifi, homeBluetooth;
        private CheckBox startup;
        private TextBlock weatherLabel;
        private TextBlock weatherSymbol;
        private string forecastSymbol = "";
        private string forecastText = "Определяю местоположение…";
        private RadioAccessStatus? radioAccess;
        private bool radioBusy;
        private int tab;
        private readonly List<Border> customizationCards = new List<Border>();

        public IslandSettings(Preferences prefs, Window owner, Action apply, Action save, Action resize, Action stop)
        {
            this.prefs = prefs;
            this.owner = owner;
            this.apply = apply;
            this.save = save;
            this.resize = resize;
            Margin = new Thickness(0, 0, 0, 3);
            notesDelay = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(350) };
            notesDelay.Tick += delegate { Flush(); };

            var layout = new Grid();
            layout.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(3, GridUnitType.Star) });
            layout.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1.34, GridUnitType.Star) });
            var main = Theme.Card(16, "#6420202B", "#355E5672");
            main.Margin = new Thickness(0, 0, 7, 0);
            var body = new StackPanel { Margin = new Thickness(9, 7, 9, 8) };
            section.Margin = new Thickness(3, 1, 0, 7);
            body.Children.Add(section);
            pageScroll = new ScrollViewer {
                Content = page, VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled
            };
            body.Children.Add(pageScroll);
            main.Child = body;
            layout.Children.Add(main);

            var rail = Theme.Card(16, "#6D211D2A", "#355E5672");
            var navigation = new StackPanel { Margin = new Thickness(5, 5, 5, 6) };
            rail.Child = navigation;
            Grid.SetColumn(rail, 1);
            layout.Children.Add(rail);
            string[] names = { "Связь", "Вид", "Заметки", "Приложения", "Главная", "Кастомизация", "Напоминания" };
            string[] glyphs = { "\uE701", "\uE790", "\uE70B", "\uE71D", "\uE80F", "\uE771", "\uE121" };
            foreach (int index in new[] { HomeTab, 0, 1, CustomizeTab, 2, RemindersTab, 3 })
            {
                var button = RailButton(names[index], glyphs[index], () => Select(index));
                button.Tag = index;
                tabs.Add(button);
                navigation.Children.Add(button);
            }
            var off = RailButton("Выключить островок", "\uE7E8", stop);
            off.Margin = new Thickness(0, 6, 0, 0);
            navigation.Children.Add(off);
            Children.Add(layout);
            status.Margin = new Thickness(3, 5, 3, 0);
            status.TextWrapping = TextWrapping.Wrap;
            status.MaxHeight = 27;
            status.Visibility = Visibility.Collapsed;
            Children.Add(status);

            wifi = Theme.Button("Wi-Fi", delegate { ToggleRadio(RadioKind.WiFi, "ms-settings:network-wifi"); }, "#323044", 31, 9);
            bluetooth = Theme.Button("Bluetooth", delegate { ToggleRadio(RadioKind.Bluetooth, "ms-settings:bluetooth"); }, "#323044", 31, 9);
        }

        private static Button RailButton(string text, string glyph, Action click)
        {
            var button = Theme.Button(text, click, "#312A3C", 29, 9);
            button.Margin = new Thickness(0, 0, 0, 3);
            button.Padding = new Thickness(3, 0, 3, 0);
            button.HorizontalContentAlignment = HorizontalAlignment.Stretch;
            var label = new DockPanel();
            var icon = Theme.TextAt(glyph, 12, Theme.Paint("#CCB4F6"));
            icon.FontFamily = Theme.Glyph;
            icon.Margin = new Thickness(3, 0, 6, 0);
            label.Children.Add(icon);
            var caption = Theme.TextAt(text, 10, Theme.Text, true);
            caption.TextTrimming = TextTrimming.CharacterEllipsis;
            label.Children.Add(caption);
            button.Content = label;
            Theme.Accessible(button, text);
            return button;
        }

        public double MeasureHeight(double width)
        {
            Width = width;
            double pageWidth = Math.Max(1, width * 3 / 4.34 - 27);
            page.Measure(new Size(pageWidth, double.PositiveInfinity));
            double viewportLimit = Math.Min(335, Math.Max(180, SystemParameters.WorkArea.Height - 180));
            pageScroll.Height = Math.Min(viewportLimit, Math.Ceiling(page.DesiredSize.Height));
            Measure(new Size(width, double.PositiveInfinity));
            // WPF can defer measuring children that are currently clipped during a morph.
            double bodyHeight = 42 + pageScroll.Height;
            double railHeight = 277;
            double statusHeight = status.Visibility == Visibility.Visible ? 32 : 0;
            return Math.Ceiling(Math.Max(bodyHeight, railHeight) + statusHeight + Margin.Bottom);
        }

        public void Select(int index)
        {
            Flush();
            tab = index;
            Report("");
            foreach (var button in tabs)
            {
                bool selected = (int)button.Tag == tab;
                button.Background = Theme.Paint(selected ? "#6A508F" : "#32293D");
                Theme.MarkActive(button, selected);
                if (selected) section.Text = (string)button.ToolTip;
            }
            if (pages[tab] == null) switch (tab)
            {
                case 0: pages[tab] = Connections(); break;
                case 1: pages[tab] = Appearance(); break;
                case 2: pages[tab] = NotesPage(); break;
                case 3: pages[tab] = AppsPage(out refreshAppsPage); break;
                case HomeTab: pages[tab] = HomePage(); break;
                case CustomizeTab: pages[tab] = Customize(); break;
                case RemindersTab: pages[tab] = RemindersPage(); break;
            }
            page.Child = pages[tab];
            if (tab == HomeTab)
            {
                startup.IsChecked = Installation.StartupEnabled();
                refreshHomeApps();
                RefreshRadios();
            }
            else if (tab == 0) RefreshRadios();
            else if (tab == 3) refreshAppsPage();
            pageScroll.ScrollToTop();
            resize();
        }

        private Panel Customize()
        {
            var stack = new StackPanel();
            var shape = CustomizationGroup(stack, "Форма и фон");
            shape.Children.Add(CustomizationList("Форма островка",
                new[] { "Dynamic Island", "Чёлка iPhone 13", "Скруглённая панель", "Прямоугольник" },
                prefs.IslandShape, index => prefs.IslandShape = index));
            AddSlider(shape, "Минимальная длина", 118, 340, prefs.IslandLength, " px", value => prefs.IslandLength = value);
            var clockOptions = CustomizationGroup(stack, "Часы");
            clockOptions.Children.Add(CustomizationList("Формат часов",
                new[] { "24 часа · 21:30", "12 часов · 9:30 PM", "24 часа с секундами · 21:30:45" },
                prefs.ClockFormat, index => prefs.ClockFormat = index));
            clockOptions.Children.Add(CustomizationList("Шрифт часов", Preferences.ClockFonts,
                prefs.ClockFont, index => prefs.ClockFont = index));
            AddSlider(clockOptions, "Размер часов", Preferences.MinClockSize, Preferences.MaxClockSize,
                prefs.ClockSize, " пт", value => prefs.ClockSize = value);
            AddSlider(clockOptions, "Прозрачность часов", 0, 100, prefs.ClockTransparency, "%", value => prefs.ClockTransparency = value);
            ColorOptions(clockOptions, "Цвет часов", () => prefs.ClockColor, value => prefs.ClockColor = value, "#F5F6FC");
            var colors = CustomizationGroup(stack, "Кнопки и музыка");
            ColorOptions(colors, "Цвет карточек", () => prefs.CardColor, value => { prefs.CardColor = value; RefreshCardColor(); }, "#24252D");
            ColorOptions(colors, "Цвет музыкальных полосок", () => prefs.SpectrumColor, value => prefs.SpectrumColor = value, "#C4ABFF");
            var color = Theme.Button("Цвет островка", delegate {
                using (var dialog = new System.Windows.Forms.ColorDialog { FullOpen = true,
                    Color = prefs.IslandColor.Length == 7 ? System.Drawing.ColorTranslator.FromHtml(prefs.IslandColor) : System.Drawing.Color.Black })
                {
                    if (dialog.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;
                    prefs.IslandColor = "#" + dialog.Color.R.ToString("X2") + dialog.Color.G.ToString("X2") + dialog.Color.B.ToString("X2");
                    apply();
                }
            }, "#50406A", 30, 8);
            shape.Children.Add(color);
            var resetColor = Theme.Button("Сбросить цвет островка", () => { prefs.IslandColor = ""; apply(); }, "#292632", 28, 8);
            resetColor.Margin = new Thickness(0, 5, 0, 0);
            shape.Children.Add(resetColor);
            var buttonColor = Theme.Button("Цвет кнопок", delegate {
                using (var dialog = new System.Windows.Forms.ColorDialog { FullOpen = true })
                {
                    if (prefs.ButtonColor.Length == 7)
                        dialog.Color = System.Drawing.ColorTranslator.FromHtml(prefs.ButtonColor);
                    if (dialog.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;
                    prefs.ButtonColor = "#" + dialog.Color.R.ToString("X2") + dialog.Color.G.ToString("X2") + dialog.Color.B.ToString("X2");
                    apply();
                }
            }, "#50406A", 30, 8);
            buttonColor.Margin = new Thickness(0, 5, 0, 0);
            colors.Children.Add(buttonColor);
            var resetButtons = Theme.Button("Сбросить цвет кнопок", () => { prefs.ButtonColor = ""; apply(); }, "#292632", 28, 8);
            resetButtons.Margin = new Thickness(0, 5, 0, 0);
            colors.Children.Add(resetButtons);
            var background = Theme.Button("Выбрать фото или видео", delegate {
                var dialog = new OpenFileDialog { Filter = "Фото и видео|*.png;*.jpg;*.jpeg;*.bmp;*.mp4;*.wmv",
                    CheckFileExists = true, Title = "Фон островка" };
                if (dialog.ShowDialog(owner) != true) return;
                prefs.IslandBackground = dialog.FileName;
                apply();
            }, "#50406A", 30, 8);
            background.Margin = new Thickness(0, 5, 0, 0);
            shape.Children.Add(background);
            var reset = Theme.Button("Сбросить только фон", delegate {
                prefs.IslandBackground = "";
                apply();
            }, "#292632", 28, 8);
            reset.Margin = new Thickness(0, 5, 0, 0);
            shape.Children.Add(reset);
            return stack;
        }

        private StackPanel CustomizationGroup(Panel parent, string title)
        {
            var card = Theme.Card(12, "#24252D", "#484A56");
            customizationCards.Add(card);
            RefreshCardColor();
            card.Margin = new Thickness(0, 0, 0, 8);
            var content = new StackPanel { Margin = new Thickness(8) };
            var heading = Theme.TextAt(title, 13, Theme.Text, true);
            heading.Margin = new Thickness(0, 0, 0, 7);
            content.Children.Add(heading);
            card.Child = content;
            parent.Children.Add(card);
            return content;
        }

        private void RefreshCardColor()
        {
            var color = (Color)ColorConverter.ConvertFromString(Theme.CustomColor(prefs.CardColor, "#24252D"));
            var fill = new SolidColorBrush(Color.FromArgb(220, (byte)Math.Min(125, (int)color.R),
                (byte)Math.Min(125, (int)color.G), (byte)Math.Min(125, (int)color.B)));
            fill.Freeze();
            foreach (var card in customizationCards) card.Background = fill;
        }

        private void ColorOptions(Panel parent, string title, Func<string> read, Action<string> set, string fallback)
        {
            var row = new UniformGrid { Columns = 2, Margin = new Thickness(0, 3, 0, 0) };
            var choose = Theme.Button(title, () => {
                using (var dialog = new System.Windows.Forms.ColorDialog { FullOpen = true,
                    Color = System.Drawing.ColorTranslator.FromHtml(Theme.CustomColor(read(), fallback)) })
                {
                    if (dialog.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;
                    set("#" + dialog.Color.R.ToString("X2") + dialog.Color.G.ToString("X2") + dialog.Color.B.ToString("X2"));
                    apply();
                }
            }, "#50406A", 28, 8);
            Theme.Accessible(choose, title);
            choose.Padding = new Thickness(3);
            choose.FontSize = 10;
            choose.Margin = new Thickness(0, 0, 4, 0);
            row.Children.Add(choose);
            var reset = Theme.Button("По умолчанию", () => { set(""); apply(); }, "#292632", 28, 8);
            reset.FontSize = 10;
            Theme.Accessible(reset, "Сбросить · " + title);
            row.Children.Add(reset);
            parent.Children.Add(row);
        }

        private Panel CustomizationList(string label, string[] values, int selected, Action<int> change)
        {
            var row = new StackPanel { Margin = new Thickness(0, 0, 0, 8) };
            row.Children.Add(Theme.TextAt(label, 11, Theme.Muted));
            var menu = new ContextMenu { Foreground = Theme.Text, Placement = PlacementMode.Bottom, HasDropShadow = false };
            var frame = new FrameworkElementFactory(typeof(Border));
            frame.SetValue(Border.BackgroundProperty, Theme.Paint("#F51C1924"));
            frame.SetValue(Border.BorderBrushProperty, Theme.Paint("#665374"));
            frame.SetValue(Border.BorderThicknessProperty, new Thickness(1));
            frame.SetValue(Border.CornerRadiusProperty, new CornerRadius(12));
            frame.SetValue(Border.PaddingProperty, new Thickness(5));
            frame.AppendChild(new FrameworkElementFactory(typeof(ItemsPresenter)));
            menu.Template = new ControlTemplate(typeof(ContextMenu)) { VisualTree = frame };
            var button = Theme.Button(values[selected] + "  ▾", () => { menu.IsOpen = true; }, "#25222D", 28, 8);
            System.Windows.Automation.AutomationProperties.SetName(button, label);
            menu.PlacementTarget = button;
            menu.Opened += delegate { menu.MinWidth = button.ActualWidth; };
            for (int i = 0; i < values.Length; i++)
            {
                int choice = i;
                var item = new MenuItem { Header = values[i], Foreground = Theme.Text, IsCheckable = true, IsChecked = i == selected };
                item.Template = CustomizationOptionTemplate();
                if (label == "Шрифт часов") item.FontFamily = new FontFamily(values[i]);
                item.Click += delegate {
                    foreach (MenuItem option in menu.Items) option.IsChecked = option == item;
                    button.Content = values[choice] + "  ▾";
                    change(choice);
                    apply();
                };
                menu.Items.Add(item);
            }
            row.Children.Add(button);
            return row;
        }

        private static ControlTemplate CustomizationOptionTemplate()
        {
            var template = new ControlTemplate(typeof(MenuItem));
            var row = new FrameworkElementFactory(typeof(Border), "row");
            row.SetValue(Border.BackgroundProperty, Brushes.Transparent);
            row.SetValue(Border.CornerRadiusProperty, new CornerRadius(7));
            row.SetValue(Border.PaddingProperty, new Thickness(10, 5, 10, 5));
            var content = new FrameworkElementFactory(typeof(DockPanel));
            var marker = new FrameworkElementFactory(typeof(TextBlock), "marker");
            marker.SetValue(TextBlock.TextProperty, "✓");
            marker.SetValue(TextBlock.FontFamilyProperty, Theme.Font);
            marker.SetValue(TextBlock.ForegroundProperty, Theme.Paint("#D7BEFF"));
            marker.SetValue(FrameworkElement.MarginProperty, new Thickness(9, 0, 0, 0));
            marker.SetValue(UIElement.VisibilityProperty, Visibility.Hidden);
            marker.SetValue(DockPanel.DockProperty, Dock.Right);
            content.AppendChild(marker);
            var caption = new FrameworkElementFactory(typeof(ContentPresenter));
            caption.SetValue(ContentPresenter.ContentSourceProperty, "Header");
            content.AppendChild(caption);
            row.AppendChild(content);
            template.VisualTree = row;
            var selected = new Trigger { Property = MenuItem.IsCheckedProperty, Value = true };
            selected.Setters.Add(new Setter(Border.BackgroundProperty, Theme.Paint("#45355B"), "row"));
            selected.Setters.Add(new Setter(UIElement.VisibilityProperty, Visibility.Visible, "marker"));
            template.Triggers.Add(selected);
            var highlighted = new Trigger { Property = MenuItem.IsHighlightedProperty, Value = true };
            highlighted.Setters.Add(new Setter(Border.BackgroundProperty, Theme.Paint("#564369"), "row"));
            template.Triggers.Add(highlighted);
            return template;
        }

        private Panel HomePage()
        {
            var stack = new StackPanel();
            var quick = new UniformGrid { Columns = 2, Margin = new Thickness(0, 0, 0, 7) };
            homeWifi = Theme.Button("Wi-Fi", () => ToggleRadio(RadioKind.WiFi, "ms-settings:network-wifi"), "#47405E", 35, 11);
            homeBluetooth = Theme.Button("Bluetooth", () => ToggleRadio(RadioKind.Bluetooth, "ms-settings:bluetooth"), "#3E3654", 35, 11);
            AddTile(quick, homeWifi);
            AddTile(quick, homeBluetooth);
            AddLink(quick, "Звук", "ms-settings:sound");
            AddLink(quick, "Экран", "ms-settings:display");
            stack.Children.Add(quick);
            var setUpNotices = Theme.Button("Разрешить уведомления", delegate { }, "#50406A", 30, 8);
            setUpNotices.Margin = new Thickness(2, 0, 2, 7);
            setUpNotices.Click += async delegate {
                setUpNotices.IsEnabled = false;
                var statusText = await ((Island)owner).SetUpMessengerNotices();
                save();
                Report(statusText);
                setUpNotices.IsEnabled = true;
            };
            Theme.Accessible(setUpNotices, "Запросить доступ к уведомлениям Telegram, Discord и других приложений");
            stack.Children.Insert(0, setUpNotices);
            startup = new CheckBox {
                Content = "Оставить островок навсегда",
                Foreground = Theme.Text, FontSize = 12,
                Margin = new Thickness(4, 0, 2, 8),
                ToolTip = "Запускать Real.Island автоматически при входе в Windows"
            };
            startup.Click += delegate {
                try
                {
                    if (startup.IsChecked == true && !Installation.Exists) Installation.Install();
                    else Installation.SetStartup(startup.IsChecked == true);
                    Report(startup.IsChecked == true ? "Островок будет запускаться при входе." : "Автозапуск отключён.");
                }
                catch (Exception ex) { Report("Не удалось изменить автозапуск. " + ex.Message); }
                startup.IsChecked = Installation.StartupEnabled();
                resize();
            };
            stack.Children.Insert(1, startup);
            var weather = Theme.Card(12, "#4934475D");
            weather.Margin = new Thickness(2, 0, 2, 7);
            var forecast = new StackPanel { Margin = new Thickness(8, 5, 8, 6) };
            weatherLabel = Theme.TextAt(forecastText, 12, Theme.Text, true);
            weatherLabel.TextWrapping = TextWrapping.Wrap;
            var weatherHeading = new DockPanel();
            weatherSymbol = Theme.TextAt(forecastSymbol, 24, Theme.Text);
            weatherSymbol.FontFamily = new FontFamily("Segoe UI Emoji");
            weatherSymbol.Margin = new Thickness(0, 0, 8, 0);
            weatherSymbol.Visibility = forecastSymbol.Length == 0 ? Visibility.Collapsed : Visibility.Visible;
            DockPanel.SetDock(weatherSymbol, Dock.Left);
            weatherHeading.Children.Add(weatherSymbol);
            weatherHeading.Children.Add(weatherLabel);
            forecast.Children.Add(weatherHeading);
            var weatherControls = Theme.Row();
            weatherControls.Margin = new Thickness(0, 4, 0, 0);
            var update = Theme.Button("Обновить прогноз", () => ((Island)owner).RefreshWeather(true), "#50406A", 26, 8);
            update.FontSize = 10;
            weatherControls.Children.Add(update);
            var location = Theme.Button("Геолокация Windows", () => Open("ms-settings:privacy-location"), "#292632", 26, 8);
            location.FontSize = 10;
            location.Margin = new Thickness(5, 0, 0, 0);
            weatherControls.Children.Add(location);
            forecast.Children.Add(weatherControls);
            var approximate = AddCheck(forecast, "Разрешить поиск города по IP через IPinfo", prefs.ApproximateWeather, value => {
                prefs.ApproximateWeather = value;
                save();
                ((Island)owner).RefreshWeather(true);
            });
            approximate.ToolTip = "Для приблизительного поиска города используется IPinfo";
            var provider = Theme.Button("Данные Open-Meteo", () => Open("https://open-meteo.com/"), "#00000000", 19, 5);
            provider.FontSize = 10;
            provider.Padding = new Thickness(0);
            provider.HorizontalAlignment = HorizontalAlignment.Left;
            forecast.Children.Add(provider);
            weather.Child = forecast;
            stack.Children.Add(weather);
            stack.Children.Add(AppsPage(out refreshHomeApps));
            return stack;
        }

        internal void SetForecast(string text, string symbol = "")
        {
            if (forecastText == text && forecastSymbol == symbol) return;
            forecastText = text;
            forecastSymbol = symbol;
            if (weatherLabel == null) return;
            weatherLabel.Text = text;
            weatherSymbol.Text = symbol;
            weatherSymbol.Visibility = symbol.Length == 0 ? Visibility.Collapsed : Visibility.Visible;
            resize();
        }

        public void Flush()
        {
            if (!notesDelay.IsEnabled) return;
            notesDelay.Stop();
            save();
        }

        private Panel Connections()
        {
            var previous = wifi.Parent as Panel;
            if (previous != null) previous.Children.Clear();
            var grid = new UniformGrid { Columns = 2 };
            AddTile(grid, wifi);
            AddTile(grid, bluetooth);
            AddLink(grid, "Сети Wi-Fi", "ms-settings:network-wifi");
            AddLink(grid, "Устройства Bluetooth", "ms-settings:bluetooth");
            AddLink(grid, "Звук", "ms-settings:sound");
            AddLink(grid, "Экран", "ms-settings:display");
            AddLink(grid, "Режим полёта", "ms-settings:network-airplanemode");
            AddLink(grid, "Все параметры", "ms-settings:");
            AddTile(grid, Theme.Button("Звук −", delegate { WindowsIntegration.MediaKey(0xAE); }, "#282632", 25, 8));
            AddTile(grid, Theme.Button("Звук +", delegate { WindowsIntegration.MediaKey(0xAF); }, "#282632", 25, 8));
            return grid;
        }

        private async void RefreshRadios()
        {
            try
            {
                var radios = await GetRadios();
                UpdateRadioLabel(wifi, "Wi-Fi", radios.Where(r => r.Kind == RadioKind.WiFi));
                UpdateRadioLabel(bluetooth, "Bluetooth", radios.Where(r => r.Kind == RadioKind.Bluetooth));
                if (homeWifi != null) UpdateRadioLabel(homeWifi, "Wi-Fi", radios.Where(r => r.Kind == RadioKind.WiFi));
                if (homeBluetooth != null) UpdateRadioLabel(homeBluetooth, "Bluetooth", radios.Where(r => r.Kind == RadioKind.Bluetooth));
            }
            catch (Exception) { }
        }

        private static Task<IReadOnlyList<Radio>> GetRadios()
        {
            return MediaSession.Read<IReadOnlyList<Radio>>(Radio.GetRadiosAsync());
        }

        private static void UpdateRadioLabel(Button button, string label, IEnumerable<Radio> radios)
        {
            var states = radios.Select(r => r.State).ToArray();
            bool enabled = states.Contains(RadioState.On);
            button.Content = states.Length == 0 ? label : label + (enabled ? "  ·  Вкл" : "  ·  Выкл");
            button.Background = Theme.Paint(enabled ? "#54447E" : "#323044");
            Theme.MarkActive(button, enabled);
        }

        private async void ToggleRadio(RadioKind kind, string fallback)
        {
            if (radioBusy) return;
            radioBusy = true;
            wifi.IsEnabled = bluetooth.IsEnabled = false;
            try
            {
                var matches = (await GetRadios()).Where(r => r.Kind == kind &&
                    (r.State == RadioState.On || r.State == RadioState.Off)).ToArray();
                if (matches.Length == 0) { OpenRadioSettings(fallback); return; }
                if (!radioAccess.HasValue)
                    radioAccess = await MediaSession.Read<RadioAccessStatus>(Radio.RequestAccessAsync());
                if (radioAccess != RadioAccessStatus.Allowed) { OpenRadioSettings(fallback); return; }
                var desired = matches.Any(r => r.State == RadioState.On) ? RadioState.Off : RadioState.On;
                foreach (var radio in matches.Where(r => r.State != desired))
                {
                    if (await MediaSession.Read<RadioAccessStatus>(radio.SetStateAsync(desired)) != RadioAccessStatus.Allowed)
                    {
                        OpenRadioSettings(fallback);
                        return;
                    }
                }
                await Task.Delay(240);
                RefreshRadios();
            }
            catch (Exception) { OpenRadioSettings(fallback); }
            finally { radioBusy = false; wifi.IsEnabled = bluetooth.IsEnabled = true; }
        }

        private void OpenRadioSettings(string target)
        {
            Report("Переключатель доступен в параметрах Windows.");
            Open(target);
        }

        private Panel Appearance()
        {
            var stack = new StackPanel();
            var colors = new UniformGrid { Columns = 4, Margin = new Thickness(0, 0, 0, 4) };
            string[] names = { "Графит", "Слива", "Океан", "Мох" };
            string[] fills = { "#34333C", "#5F3C6D", "#265674", "#355D4A" };
            for (int i = 0; i < names.Length; i++)
            {
                int choice = i;
                var swatch = Theme.Button(names[i], delegate {
                    prefs.Tint = choice;
                    apply();
                    Report("Цвет · " + names[choice]);
                }, fills[i], 24, 8);
                swatch.FontSize = 11;
                swatch.Padding = new Thickness(1, 0, 1, 0);
                AddTile(colors, swatch);
            }
            stack.Children.Add(colors);
            AddSlider(stack, "Прозрачность", 0, 60, prefs.Transparency, "%", v => prefs.Transparency = v);
            AddSlider(stack, "Анимация", 160, 580, prefs.Animation, " мс", v => prefs.Animation = v);
            var options = new UniformGrid { Columns = 2, Margin = new Thickness(0, 3, 0, 4) };
            AddCheck(options, "Часы", prefs.Clock, v => { prefs.Clock = v; apply(); });
            AddCheck(options, "Музыка", prefs.Media, v => { prefs.Media = v; apply(); });
            AddCheck(options, "Серый контур", prefs.Outline, v => { prefs.Outline = v; apply(); });
            AddCheck(options, "Скрывать панель задач", prefs.HideTaskbar, v => { prefs.HideTaskbar = v; apply(); });
            AddCheck(options, "Скрывать в полноэкранном", prefs.HideFullscreen, v => { prefs.HideFullscreen = v; apply(); });
            CheckBox startup = null;
            startup = AddCheck(options, "Запускать с Windows", Preferences.StartsAtLogin(), v => {
                try
                {
                    Preferences.SetStartAtLogin(v);
                    Report(v ? "Островок будет запускаться при входе в Windows." : "Автозапуск выключен.");
                }
                catch (Exception) { Report("Windows не разрешила изменить автозапуск."); }
                startup.IsChecked = Preferences.StartsAtLogin();
            });
            var island = (Island)owner;
            var clickThrough = AddCheck(options, "Клики сквозь островок", prefs.ClickThrough, v => {
                prefs.ClickThrough = v;
                apply();
            });
            clickThrough.IsEnabled = island.CanClickThrough;
            clickThrough.ToolTip = island.CanClickThrough ? "Ctrl+Alt+I открывает настройки островка." : "Ctrl+Alt+I уже используется другой программой.";
            var notifications = Theme.Button(island.NoticesActive ? "Отключить уведомления" : "Включить уведомления", delegate { }, "#332B46", 29, 8);
            notifications.Click += async delegate {
                notifications.IsEnabled = false;
                bool enabled = await island.ToggleNotices();
                notifications.Content = enabled ? "Отключить уведомления" : "Включить уведомления";
                notifications.IsEnabled = true;
                save();
                Report(enabled ? "Уведомления включены." : "Доступ выключен или недоступен в Windows.");
            };
            stack.Children.Add(options);
            var activity = new UniformGrid { Columns = 2 };
            AddCheck(activity, "Звук уведомлений", prefs.NoticeSound, value => { prefs.NoticeSound = value; save(); });
            AddCheck(activity, "Показывать загрузки", prefs.DownloadNotices, value => {
                prefs.DownloadNotices = value; save(); island.ApplyDownloadPreference();
            });
            stack.Children.Add(activity);
            stack.Children.Add(notifications);
            var windowsNotices = Theme.Button("Уведомления Windows", () => Open("ms-settings:notifications"), "#292632", 25, 8);
            windowsNotices.Margin = new Thickness(0, 4, 0, 0);
            stack.Children.Add(windowsNotices);
            var exclusions = Theme.Row();
            var selectApp = Theme.Button("Скрывать в приложении…", delegate {
                var picker = new OpenFileDialog {
                    Title = "Выбери EXE приложения", Filter = "Программы (*.exe)|*.exe", CheckFileExists = true
                };
                if (picker.ShowDialog(owner) != true) return;
                string name = Path.GetFileNameWithoutExtension(picker.FileName);
                prefs.ExcludedApps.Add(name);
                apply();
                Report("Островок скрывается в " + name);
            }, "#332B46", 26, 8);
            AddTile(exclusions, selectApp);
            AddTile(exclusions, Theme.Button("Исключения…", delegate {
                var menu = new ContextMenu { PlacementTarget = selectApp };
                foreach (string name in prefs.ExcludedApps.OrderBy(item => item))
                {
                    string app = name;
                    var entry = new MenuItem { Header = "Показывать в " + app };
                    entry.Click += delegate { prefs.ExcludedApps.Remove(app); apply(); Report("Исключение снято."); };
                    menu.Items.Add(entry);
                }
                if (menu.Items.Count == 0) menu.Items.Add(new MenuItem { Header = "Список пуст", IsEnabled = false });
                menu.IsOpen = true;
            }, "#332B46", 26, 8));
            stack.Children.Add(exclusions);
            var wallpaper = new UniformGrid { Columns = 2 };
            AddTile(wallpaper, Theme.Button("Выбрать обои…", ChooseWallpaper, "#332B46", 26, 8));
            AddTile(wallpaper, Theme.Button("Аврора 4K", delegate { SetWallpaper(Preferences.Aurora); }, "#332B46", 26, 8));
            stack.Children.Add(wallpaper);
            var source = Theme.Row();
            source.Margin = new Thickness(2, 5, 0, 0);
            var chosen = Theme.TextAt("", 11, Theme.Muted);
            chosen.Width = 174;
            chosen.TextTrimming = TextTrimming.CharacterEllipsis;
            Action update = delegate {
                chosen.Text = prefs.ExtraPlayer.Length == 0 ? "Дополнительный плеер" : Path.GetFileName(prefs.ExtraPlayer);
                chosen.ToolTip = chosen.Text;
            };
            update();
            source.Children.Add(chosen);
            AddTile(source, Theme.Button("Выбрать EXE", delegate {
                var dialog = new OpenFileDialog {
                    Title = "Выберите исполняемый файл музыкального плеера",
                    Filter = "Программы (*.exe)|*.exe", CheckFileExists = true
                };
                if (dialog.ShowDialog(owner) != true) return;
                string name = Path.GetFileNameWithoutExtension(dialog.FileName);
                if (MediaSession.IsBrowser(name) || MediaSession.IsCallSource(name))
                {
                    Report("Выберите музыкальный плеер.");
                    return;
                }
                prefs.ExtraPlayer = dialog.FileName;
                update();
                apply();
            }, "#332B46", 25, 8));
            AddTile(source, Theme.Button("Сброс", delegate { prefs.ExtraPlayer = ""; update(); apply(); }, "#332B46", 25, 8));
            stack.Children.Add(source);
            return stack;
        }

        private void AddSlider(Panel panel, string label, int min, int max, int initial, string unit, Action<int> change)
        {
            var text = Theme.TextAt(label + " · " + initial + unit, 11, Theme.Muted);
            panel.Children.Add(text);
            var slider = new Slider { Minimum = min, Maximum = max, Value = initial, IsSnapToTickEnabled = true,
                TickFrequency = 1, SmallChange = 1, LargeChange = 10, Margin = new Thickness(0, 0, 0, 4) };
            System.Windows.Automation.AutomationProperties.SetName(slider, label);
            slider.ValueChanged += delegate {
                int value = (int)slider.Value;
                text.Text = label + " · " + value + unit;
                change(value);
                apply();
            };
            panel.Children.Add(slider);
        }

        private static CheckBox AddCheck(Panel panel, string name, bool initial, Action<bool> change)
        {
            var check = new CheckBox { Content = name, IsChecked = initial, FontSize = 10.5, Foreground = Theme.Text,
                VerticalContentAlignment = VerticalAlignment.Center, Margin = new Thickness(1, 2, 1, 2) };
            check.Click += delegate { change(check.IsChecked == true); };
            panel.Children.Add(check);
            return check;
        }

        private Panel NotesPage()
        {
            var stack = new StackPanel();
            var edit = new TextBox { Text = prefs.Notes, Height = 113, AcceptsReturn = true, MaxLength = 50000,
                TextWrapping = TextWrapping.Wrap, VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                Foreground = Theme.Text, Background = Theme.Paint("#25232D"), CaretBrush = Theme.Text,
                BorderBrush = Theme.Paint("#50475F"), Padding = new Thickness(7) };
            System.Windows.Automation.AutomationProperties.SetName(edit, "Текст заметок");
            edit.TextChanged += delegate {
                prefs.Notes = edit.Text;
                notesDelay.Stop();
                notesDelay.Start();
            };
            stack.Children.Add(edit);
            var hint = Theme.TextAt("Сохраняется автоматически", 11, Theme.Muted);
            hint.Margin = new Thickness(2, 4, 0, 0);
            stack.Children.Add(hint);
            return stack;
        }

        private Panel RemindersPage()
        {
            var stack = new StackPanel();
            var form = Theme.Card(13, "#30282638", "#50403A55");
            var fields = new StackPanel { Margin = new Thickness(9) };
            form.Child = fields;
            stack.Children.Add(form);
            var soon = DateTime.Now.AddMinutes(5);
            var title = new TextBox { MaxLength = 120, Template = ReminderInputTemplate(typeof(TextBox)) };
            System.Windows.Automation.AutomationProperties.SetName(title, "Текст напоминания");
            fields.Children.Add(ReminderField("О чём напомнить", title));
            var schedule = new UniformGrid { Columns = 2, Margin = new Thickness(0, 7, 0, 9) };
            var day = new DatePicker { SelectedDate = soon.Date, Template = ReminderDateTemplate() };
            var time = new TextBox { Text = soon.ToString("HH:mm"), MaxLength = 5,
                Template = ReminderInputTemplate(typeof(TextBox)) };
            System.Windows.Automation.AutomationProperties.SetName(day, "Дата напоминания");
            System.Windows.Automation.AutomationProperties.SetName(time, "Время напоминания, ЧЧ:ММ");
            var dateField = ReminderField("Дата", day);
            dateField.Margin = new Thickness(0, 0, 7, 0);
            schedule.Children.Add(dateField);
            schedule.Children.Add(ReminderField("Время", time));
            fields.Children.Add(schedule);
            var add = Theme.Button("Добавить напоминание", delegate {
                string text = title.Text.Trim();
                DateTime clock;
                if (text.Length == 0 || day.SelectedDate == null || !DateTime.TryParseExact(time.Text.Trim(),
                    "HH:mm", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out clock))
                {
                    Report("Введи текст, дату и время в формате ЧЧ:ММ.");
                    return;
                }
                DateTime due = day.SelectedDate.Value.Date.Add(clock.TimeOfDay);
                if (TimeZoneInfo.Local.IsInvalidTime(due) || due <= DateTime.Now)
                {
                    Report("Выбери доступное время в будущем.");
                    return;
                }
                prefs.Reminders.Add(new ScheduledReminder(due.ToUniversalTime(), text));
                title.Clear();
                Report("");
                save();
                RefreshReminders();
            }, "#5A467C", 32, 9);
            Theme.MarkActive(add, true);
            fields.Children.Add(add);
            remindersList = new StackPanel { Margin = new Thickness(0, 9, 0, 0) };
            stack.Children.Add(remindersList);
            RefreshReminders();
            return stack;
        }

        private static StackPanel ReminderField(string label, Control input)
        {
            var field = new StackPanel();
            var caption = Theme.TextAt(label, 11, Theme.Muted, true);
            caption.Margin = new Thickness(2, 0, 0, 3);
            input.MinHeight = 31;
            input.FontSize = 12;
            input.Foreground = Theme.Text;
            input.Padding = new Thickness(9, 0, 6, 0);
            input.VerticalContentAlignment = VerticalAlignment.Center;
            var text = input as TextBox;
            if (text != null) text.CaretBrush = Theme.Text;
            field.Children.Add(caption);
            field.Children.Add(input);
            return field;
        }

        private static FrameworkElementFactory ReminderInputBorder()
        {
            var frame = new FrameworkElementFactory(typeof(Border), "frame");
            frame.SetValue(Border.BackgroundProperty, Theme.Paint("#22202B"));
            frame.SetValue(Border.BorderBrushProperty, Theme.Paint("#51495E"));
            frame.SetValue(Border.BorderThicknessProperty, new Thickness(1));
            frame.SetValue(Border.CornerRadiusProperty, new CornerRadius(8));
            return frame;
        }

        private static void FocusReminderInput(ControlTemplate template)
        {
            var focused = new Trigger { Property = UIElement.IsKeyboardFocusWithinProperty, Value = true };
            focused.Setters.Add(new Setter(Border.BorderBrushProperty, Theme.Paint("#B6A1E9"), "frame"));
            template.Triggers.Add(focused);
        }

        private static ControlTemplate ReminderInputTemplate(Type controlType)
        {
            var host = new FrameworkElementFactory(typeof(ScrollViewer), "PART_ContentHost");
            host.SetValue(FrameworkElement.MarginProperty, new System.Windows.TemplateBindingExtension(Control.PaddingProperty));
            host.SetValue(FrameworkElement.VerticalAlignmentProperty, VerticalAlignment.Center);
            var template = new ControlTemplate(controlType);
            if (controlType == typeof(DatePickerTextBox))
                template.VisualTree = host;
            else
            {
                var frame = ReminderInputBorder();
                frame.AppendChild(host);
                template.VisualTree = frame;
                FocusReminderInput(template);
            }
            return template;
        }

        private static ControlTemplate ReminderDateTemplate()
        {
            var popup = new FrameworkElementFactory(typeof(Popup), "PART_Popup");
            popup.SetValue(Popup.PlacementProperty, PlacementMode.Bottom);
            popup.SetValue(Popup.AllowsTransparencyProperty, true);

            var button = new FrameworkElementFactory(typeof(Button), "PART_Button");
            button.SetValue(FrameworkElement.WidthProperty, 30.0);
            button.SetValue(DockPanel.DockProperty, Dock.Right);
            button.SetValue(Control.ForegroundProperty, Theme.Paint("#CCB4F6"));
            button.SetValue(Control.FontFamilyProperty, Theme.Glyph);
            button.SetValue(ContentControl.ContentProperty, "\uE787");
            button.SetValue(System.Windows.Automation.AutomationProperties.NameProperty, "Открыть календарь");
            var buttonFace = new FrameworkElementFactory(typeof(Border));
            buttonFace.SetValue(Border.BackgroundProperty, Brushes.Transparent);
            var glyph = new FrameworkElementFactory(typeof(ContentPresenter));
            glyph.SetValue(FrameworkElement.HorizontalAlignmentProperty, HorizontalAlignment.Center);
            glyph.SetValue(FrameworkElement.VerticalAlignmentProperty, VerticalAlignment.Center);
            buttonFace.AppendChild(glyph);
            button.SetValue(Control.TemplateProperty, new ControlTemplate(typeof(Button)) { VisualTree = buttonFace });

            var editor = new FrameworkElementFactory(typeof(DatePickerTextBox), "PART_TextBox");
            editor.SetValue(Control.FontSizeProperty, 12.0);
            editor.SetValue(Control.ForegroundProperty, Theme.Text);
            editor.SetValue(TextBoxBase.CaretBrushProperty, Theme.Text);
            editor.SetValue(Control.PaddingProperty, new Thickness(9, 0, 0, 0));
            editor.SetValue(Control.TemplateProperty, ReminderInputTemplate(typeof(DatePickerTextBox)));
            var row = new FrameworkElementFactory(typeof(DockPanel));
            row.AppendChild(button);
            row.AppendChild(editor);
            var root = new FrameworkElementFactory(typeof(Grid), "PART_Root");
            root.AppendChild(row);
            root.AppendChild(popup);
            var frame = ReminderInputBorder();
            frame.AppendChild(root);
            var template = new ControlTemplate(typeof(DatePicker)) { VisualTree = frame };
            FocusReminderInput(template);
            return template;
        }

        internal void RefreshReminders()
        {
            if (remindersList == null) return;
            remindersList.Children.Clear();
            if (prefs.Reminders.Count == 0)
            {
                var empty = Theme.TextAt("Нет запланированных напоминаний", 11, Theme.Muted);
                empty.Margin = new Thickness(4, 2, 0, 0);
                remindersList.Children.Add(empty);
            }
            else
            {
                var heading = Theme.TextAt("Запланировано", 11, Theme.Muted, true);
                heading.Margin = new Thickness(4, 0, 0, 5);
                remindersList.Children.Add(heading);
            }
            foreach (var reminder in prefs.Reminders.OrderBy(item => item.DueUtc))
            {
                var card = Theme.Card(10, "#682A2535", "#50403A55");
                card.Margin = new Thickness(0, 0, 0, 5);
                var row = new DockPanel { Margin = new Thickness(9, 6, 6, 6) };
                card.Child = row;
                var remove = Theme.Button("Удалить", delegate {
                    prefs.Reminders.Remove(reminder);
                    save();
                    RefreshReminders();
                }, "#292632", 24, 7);
                DockPanel.SetDock(remove, Dock.Right);
                row.Children.Add(remove);
                remove.Margin = new Thickness(7, 0, 0, 0);
                remove.VerticalAlignment = VerticalAlignment.Center;
                var details = new StackPanel();
                var label = Theme.TextAt(reminder.Title, 12, Theme.Text, true);
                label.TextTrimming = TextTrimming.CharacterEllipsis;
                label.ToolTip = reminder.Title;
                details.Children.Add(label);
                details.Children.Add(Theme.TextAt(reminder.DueUtc.ToLocalTime().ToString("dd.MM.yyyy · HH:mm"), 10, Theme.Muted));
                row.Children.Add(details);
                remindersList.Children.Add(card);
            }
            if (tab == RemindersTab) resize();
        }

        private Panel AppsPage(out Action refresh)
        {
            var stack = new StackPanel();
            var shelf = Theme.Card(17, "#73282436", "#52685A83");
            var shortcuts = new WrapPanel { Margin = new Thickness(7, 6, 7, 6) };
            shelf.Child = shortcuts;
            stack.Children.Add(shelf);
            System.Windows.Automation.AutomationProperties.SetName(shortcuts, "Ярлыки приложений");
            Action reload = null;
            var add = Theme.Button("+", delegate {
                var picker = new AppPicker(prefs.Apps);
                var island = (Island)owner;
                island.SetPickerOpen(true);
                try
                {
                    if (picker.ShowDialog() != true) return;
                    prefs.Apps.AddRange(picker.Selected);
                    save();
                    reload();
                }
                finally { island.SetPickerOpen(false); }
            }, "#4D3D69", 42, 21);
            add.Width = 42;
            add.Margin = new Thickness(3);
            add.FontSize = 23;
            Theme.Accessible(add, "Добавить приложение");
            reload = delegate {
                shortcuts.Children.Clear();
                foreach (string path in prefs.Apps)
                {
                    string name = Path.GetFileNameWithoutExtension(path);
                    var shortcut = Theme.Button("", delegate { Open(path); }, "#60333148", 42, 15);
                    shortcut.Width = 42;
                    shortcut.Margin = new Thickness(3);
                    shortcut.Padding = new Thickness(0);
                    shortcut.Content = AppIcon.Picture(path, 32);
                    Theme.Accessible(shortcut, name);
                    var remove = new MenuItem { Header = "Убрать из островка" };
                    remove.Click += delegate { prefs.Apps.Remove(path); save(); reload(); resize(); };
                    shortcut.ContextMenu = new ContextMenu();
                    shortcut.ContextMenu.Items.Add(remove);
                    shortcuts.Children.Add(shortcut);
                }
                shortcuts.Children.Add(add);
                resize();
            };
            refresh = reload;
            return stack;
        }

        private void ChooseWallpaper()
        {
            var dialog = new OpenFileDialog { Title = "Выберите обои", CheckFileExists = true,
                Filter = "Изображения|*.jpg;*.jpeg;*.png;*.bmp;*.gif;*.tif;*.tiff;*.webp;*.heic;*.avif" };
            if (dialog.ShowDialog(owner) == true) SetWallpaper(dialog.FileName);
        }

        private void SetWallpaper(string file)
        {
            try
            {
                Wallpaper.Apply(file);
                prefs.Wallpaper = file;
                save();
                Report("Обои установлены.");
            }
            catch (Exception) { Report("Windows не смогла установить эти обои."); }
        }

        private void AddLink(Panel panel, string title, string uri)
        {
            AddTile(panel, Theme.Button(title, delegate { Open(uri); }, "#282632", 27, 8));
        }

        private static void AddTile(Panel panel, Button button)
        {
            button.Margin = new Thickness(2, 2, 2, 2);
            button.Padding = new Thickness(3, 0, 3, 0);
            button.FontSize = 11;
            panel.Children.Add(button);
        }

        private void Open(string target)
        {
            try { Process.Start(new ProcessStartInfo(target) { UseShellExecute = true }); }
            catch (Exception) { Report("Не удалось открыть. Проверьте, доступен ли файл или раздел Windows."); }
        }

        public void Report(string message)
        {
            if (status.Text == message) return;
            status.Text = message;
            status.Visibility = message.Length == 0 ? Visibility.Collapsed : Visibility.Visible;
            resize();
        }
    }
}










