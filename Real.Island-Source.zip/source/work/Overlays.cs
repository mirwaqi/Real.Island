using System;
using System.Diagnostics;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;

namespace IslandDesktop
{
    internal sealed class Island : Window
    {
        private readonly MediaSession media = new MediaSession();
        private readonly OutputMeter meter = new OutputMeter();
        private readonly DispatcherTimer statusTimer;
        private readonly IslandSurface surface = new IslandSurface();
        private readonly TextBlock clock, date, title, artist, note, playGlyph;
        private readonly Border art;
        private readonly Button header, pauseButton;
        private readonly StackPanel player, content, mediaPanel;
        private readonly Grid compact;
        private readonly StackPanel transport;
        private readonly TextBlock idleMark, compactTitle;
        private readonly Preferences prefs;
        private readonly IslandSettings settings;
        private bool showingSettings, readingOutline;
        private Track currentTrack = new Track();
        private double lastSound, headerBlend;
        private bool fallbackPlaying;
        private string displayedSource = "";
        private bool paused, pauseRequested, playbackCommandInFlight;
        private double pauseRequestUntil;


        private readonly LevelBars bars = new LevelBars();
        private readonly Stopwatch motion = new Stopwatch();
        private double width = 118, height = 42, fromWidth, fromHeight, targetWidth = 118, targetHeight = 42;
        private bool expanded, refreshing, closed, playing;
        private ImageSource previousCover;
        private TimeSpan lastFrame;

        private TimeSpan lastAudioSample;


        public Island(Preferences prefs, Action apply, Action save, Action stop)
        {


            this.prefs = prefs;
            Title = "Dynamic Island";
            WindowStyle = WindowStyle.None;
            ResizeMode = ResizeMode.NoResize;
            AllowsTransparency = true;
            Background = Brushes.Transparent;
            ShowInTaskbar = false;
            ShowActivated = false;
            Topmost = true;
            SizeToContent = SizeToContent.WidthAndHeight;
            UseLayoutRounding = false;
            SnapsToDevicePixels = false;
            var body = new Grid { Width = width, Height = height };
            body.Children.Add(surface);
            content = new StackPanel { Clip = new RectangleGeometry(new Rect(0, 0, width, height), 21, 21) };
            body.Children.Add(content);
            Content = body;

            header = Theme.Button("", HeaderClick, "#00000000", 42, 21);
            header.Padding = new Thickness(0);
            Theme.Accessible(header, "Открыть настройки или плеер Dynamic Island");
            compact = new Grid { Width = 118, Height = 30 };
            art = Theme.Card(8, "#352853");
            art.Width = 28;
            art.Height = 28;
            art.HorizontalAlignment = HorizontalAlignment.Left;
            art.VerticalAlignment = VerticalAlignment.Center;
            note = MakeIcon("\uE8D6", 13);
            note.HorizontalAlignment = HorizontalAlignment.Center;
            art.Child = note;
            art.RenderTransform = new TranslateTransform(12, 0);
            compact.Children.Add(art);
            clock = Theme.TextAt("", 13, Theme.Text, true);
            clock.HorizontalAlignment = HorizontalAlignment.Center;
            clock.Width = 54;
            clock.TextAlignment = TextAlignment.Center;
            TextOptions.SetTextFormattingMode(clock, TextFormattingMode.Ideal);
            System.Windows.Automation.AutomationProperties.SetName(clock, "Текущее время");
            compact.Children.Add(clock);
            compactTitle = Theme.TextAt("", 12, Theme.Text, true);
            compactTitle.Margin = new Thickness(46, 0, 46, 0);
            compactTitle.TextAlignment = TextAlignment.Center;
            compactTitle.TextTrimming = TextTrimming.CharacterEllipsis;
            compact.Children.Add(compactTitle);
            idleMark = MakeIcon("\uE70D", 10);
            idleMark.HorizontalAlignment = HorizontalAlignment.Center;
            compact.Children.Add(idleMark);
            bars.Width = 32;
            bars.Height = 25;
            bars.HorizontalAlignment = HorizontalAlignment.Right;
            bars.VerticalAlignment = VerticalAlignment.Center;
            bars.RenderTransform = new TranslateTransform(-12, 0);
            compact.Children.Add(bars);
            header.Content = compact;
            content.Children.Add(header);

            player = new StackPanel { Width = 276, Opacity = 0, Visibility = Visibility.Hidden };
            mediaPanel = new StackPanel { Visibility = Visibility.Collapsed };
            player.Children.Add(mediaPanel);
            title = Theme.TextAt("", 16, Theme.Text, true);
            title.TextTrimming = TextTrimming.CharacterEllipsis;
            title.TextAlignment = TextAlignment.Center;
            mediaPanel.Children.Add(title);
            artist = Theme.TextAt("", 12, Theme.Muted);
            artist.TextTrimming = TextTrimming.CharacterEllipsis;
            artist.TextAlignment = TextAlignment.Center;
            artist.Margin = new Thickness(0, 1, 0, 0);
            mediaPanel.Children.Add(artist);

            var controls = transport = Theme.Row();
            controls.HorizontalAlignment = HorizontalAlignment.Center;
            controls.Margin = new Thickness(0, 10, 0, 0);
            controls.Children.Add(MediaButton("\uE892", "Предыдущий трек", 0xB1));
            var play = MediaButton("\uE768", "Воспроизвести или поставить на паузу", 0xB3);
            playGlyph = MakeIcon("\uE768", 17);
            play.Content = playGlyph;
            playGlyph.Text = "\uE769";
            controls.Children.Add(play);
            controls.Children.Add(MediaButton("\uE893", "Следующий трек", 0xB0));
            mediaPanel.Children.Add(controls);

            var footer = Theme.Row();
            footer.HorizontalAlignment = HorizontalAlignment.Center;
            footer.Margin = new Thickness(0, 9, 0, 0);
            date = Theme.TextAt("", 11, Theme.Muted);
            date.Margin = new Thickness(0, 0, 10, 0);
            footer.Children.Add(date);
            footer.Children.Add(Theme.Button("Настройки", OpenSettings, "#29262F", 24, 8));
            pauseButton = Theme.Button("Пауза", TogglePlayback, "#29262F", 24, 8);
            pauseButton.Width = 105;
            pauseButton.Margin = new Thickness(5, 0, 0, 0);
            pauseButton.Visibility = Visibility.Collapsed;
            footer.Children.Add(pauseButton);
            player.Children.Add(footer);
            content.Children.Add(player);
            settings = new IslandSettings(prefs, this, apply, save, ResizeIsland, stop) { Visibility = Visibility.Collapsed };
            content.Children.Add(settings);

            var menu = new ContextMenu();
            var settingsItem = new MenuItem { Header = "Настройки" };
            settingsItem.Click += delegate { OpenSettings(); };
            var stopItem = new MenuItem { Header = "Остановить оформление" };
            stopItem.Click += delegate { stop(); };
            menu.Items.Add(settingsItem);
            menu.Items.Add(stopItem);
            ContextMenu = menu;

            Loaded += delegate { Reposition(); };
            SourceInitialized += delegate {
                WindowsIntegration.CenterOnResize(this);
                body.Width = compact.Width = WindowsIntegration.CenteredVisualWidth(this, width);
            };
            DpiChanged += delegate { Dispatcher.BeginInvoke(new Action(Reposition)); };
            PreviewKeyDown += delegate(object sender, KeyEventArgs e) {
                if (e.Key == Key.Escape && (expanded || showingSettings)) { TogglePanel(); e.Handled = true; }
            };
            IsVisibleChanged += delegate {
                if (IsVisible) CompositionTarget.Rendering += RenderFrame;
                else CompositionTarget.Rendering -= RenderFrame;
            };
            statusTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(450) };
            statusTimer.Tick += async delegate {
                UpdateClock();
                if (refreshing) return;
                refreshing = true;
                try
                {
                    Track track = prefs.Media ? await media.Refresh() : new Track();
                    if (!closed && !HoldTestTrack) UpdateTrack(track);
                }
                finally { refreshing = false; }
            };
            UpdateClock();
            ApplySettings();
            statusTimer.Start();
            Closed += delegate {
                settings.Flush();
                closed = true;
                statusTimer.Stop();
                CompositionTarget.Rendering -= RenderFrame;
                meter.Dispose();
                media.Dispose();
            };
        }

#if SMOKE_TEST
        internal Point ClockPosition()
        {
            return clock.PointToScreen(new Point(clock.ActualWidth / 2, clock.ActualHeight / 2));
        }
#endif

        private bool HoldTestTrack
        {
            get
            {
#if SMOKE_TEST
                return true;
#else
                return false;
#endif
            }
        }

        public void Reposition() { WindowsIntegration.Place(this); }
        public async void UpdateOutline()
        {
            if (!prefs.Outline) { surface.SetDark(false); return; }
            if (!IsVisible || readingOutline || motion.IsRunning) return;
            readingOutline = true;
            IntPtr hwnd = new System.Windows.Interop.WindowInteropHelper(this).Handle;
            try
            {
                bool dark = await System.Threading.Tasks.Task.Run(() => WindowsIntegration.DarkBehind(hwnd));
                if (!closed && prefs.Outline) surface.SetDark(dark);
            }
            finally { readingOutline = false; }
        }

        private void UpdateClock()
        {
            DateTime now = DateTime.Now;
            clock.Text = now.ToString("HH:mm");
            date.Text = now.ToString("d MMMM", CultureInfo.GetCultureInfo("ru-RU"));
        }

        public void ApplySettings()
        {
            surface.SetAppearance(prefs.Transparency, prefs.Tint);
            bars.Accent = new[] { "#C4ABFF", "#F0A8DD", "#91D9FF", "#A1EBC0" }[prefs.Tint];
            if (!prefs.Media) fallbackPlaying = false;
            SelectAudioSource();
            ApplyTrackDisplay();
            UpdateMode();
            UpdateOutline();
        }

        internal void UpdateTrack(Track track)
        {
            currentTrack = track;
            if (track.Paused) pauseRequested = false;
            if (pauseRequested && (lastFrame.TotalSeconds > pauseRequestUntil || track.Source.Length == 0))
                pauseRequested = false;
            if (track.Playing) fallbackPlaying = false;

            SelectAudioSource();
            ApplyTrackDisplay();
        }

        private void SelectAudioSource()
        {
            string source = currentTrack.Playing && currentTrack.Source.Length > 0 ? currentTrack.Source : OutputMeter.PlayerFallback;
            meter.SelectSource(prefs.Media && !HoldTestTrack ? source : "", prefs.ExtraPlayer);
        }

        private void ApplyTrackDisplay()
        {
            bool holdCard = prefs.Media && expanded && (currentTrack.Paused || (pauseRequested && currentTrack.Playing));
            bool fromSession = prefs.Media && (currentTrack.Playing || holdCard);
            bool nextPaused = holdCard;
            bool next = prefs.Media && (fromSession || fallbackPlaying);
            string nextTitle = fromSession && currentTrack.Title.Length > 0 ? currentTrack.Title : "Сейчас играет";
            string nextArtist = fromSession ? currentTrack.Artist : "";
            string nextSource = fromSession ? currentTrack.Source : "";
            ImageSource cover = fromSession ? currentTrack.Cover : null;
            if (!next && !playing) return;
            if (next && playing && compactTitle.Text == nextTitle && artist.Text == nextArtist &&
                previousCover == cover && displayedSource == nextSource && paused == nextPaused) return;

            playing = next;
            displayedSource = nextSource;
            paused = nextPaused;
            playGlyph.Text = paused ? "\uE768" : "\uE769";
            pauseButton.Content = paused ? "Продолжить" : "Пауза";
            title.Text = nextTitle;
            compactTitle.Text = nextTitle;
            artist.Text = nextArtist;
            artist.Visibility = artist.Text.Length == 0 ? Visibility.Collapsed : Visibility.Visible;
            if (previousCover != cover)
            {
                previousCover = cover;
                art.Background = cover == null ? Theme.Paint("#352853") :
                    new ImageBrush(cover) { Stretch = Stretch.UniformToFill };
                note.Visibility = cover == null ? Visibility.Visible : Visibility.Hidden;
            }
            transport.Visibility = pauseButton.Visibility = fromSession && next ? Visibility.Visible : Visibility.Collapsed;
            UpdateMode();
        }

        private void UpdateMode()
        {
            clock.Visibility = prefs.Clock ? Visibility.Visible : Visibility.Hidden;
            compactTitle.Visibility = playing ? Visibility.Visible : Visibility.Hidden;
            idleMark.Visibility = !prefs.Clock && !playing ? Visibility.Visible : Visibility.Hidden;
            art.Visibility = playing && !showingSettings ? Visibility.Visible : Visibility.Hidden;
            bars.Visibility = playing && !showingSettings ? Visibility.Visible : Visibility.Hidden;
            mediaPanel.Visibility = playing ? Visibility.Visible : Visibility.Collapsed;

            ResizeIsland();
        }

        private void HeaderClick()
        {
            if (!expanded && !playing) OpenSettings();
            else TogglePanel();
        }

        public void TogglePanel()
        {
            if (showingSettings)
            {
                settings.Flush();
                showingSettings = false;
                settings.Visibility = Visibility.Collapsed;
                expanded = playing;
                player.Visibility = playing ? Visibility.Visible : Visibility.Hidden;
                UpdateMode();
                return;
            }
            expanded = !expanded;
            ApplyTrackDisplay();
            Theme.Accessible(header, expanded ? "Свернуть Dynamic Island" : "Открыть Dynamic Island");
            if (expanded) player.Visibility = Visibility.Visible;
            UpdateMode();
        }

        public bool PickerOpen { get; private set; }
        public void SetPickerOpen(bool open)
        {
            PickerOpen = open;
            if (open) { settings.Flush(); Hide(); }
            else if (!closed) { Show(); Activate(); }
        }

        internal IslandSettings SettingsPanel { get { return settings; } }

        public void OpenSettings()
        {
            if (PickerOpen) return;
            if (!IsVisible) Show();
            if (!showingSettings)
            {
                showingSettings = true;
                expanded = true;
                player.Visibility = Visibility.Collapsed;
                settings.Visibility = Visibility.Visible;
                settings.Select(0);
                UpdateMode();
            }
            Activate();
        }

        private void ResizeIsland()
        {
            double desiredWidth = playing ? Math.Min(348, Math.Max(168, TextWidth(compactTitle) + 100)) : 118;
            double desiredHeight = 42;
            if (expanded)
            {
                double labelWidth = playing ? Math.Max(TextWidth(title), TextWidth(artist)) + 56 : 0;
                double screenWidth = System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width;
                var source = PresentationSource.FromVisual(this);
                double scale = source == null ? 1 : source.CompositionTarget.TransformToDevice.M11;
                double limit = Math.Max(235, Math.Min(560, screenWidth / scale - 24));
                desiredWidth = Math.Min(limit, Math.Max(playing ? 300 : 260, labelWidth));
                desiredHeight = playing ? (currentTrack.Playing || paused ? 163 : 116) : 87;
                player.Width = desiredWidth - 24;
                if (showingSettings)
                {
                    desiredWidth = Math.Min(limit, 356);
                    desiredHeight = header.Height + settings.MeasureHeight(desiredWidth - 23) + 12;
                }
            }
            if (Math.Abs(targetWidth - desiredWidth) < .5 && Math.Abs(targetHeight - desiredHeight) < .5) return;
            fromWidth = width;
            fromHeight = height;
            targetWidth = desiredWidth;
            targetHeight = desiredHeight;
            motion.Restart();
        }

        private static double TextWidth(TextBlock label)
        {
            var typeface = new Typeface(label.FontFamily, label.FontStyle, label.FontWeight, label.FontStretch);
            var formatted = new FormattedText(label.Text, CultureInfo.CurrentUICulture,
                FlowDirection.LeftToRight, typeface, label.FontSize, Brushes.White, VisualTreeHelper.GetDpi(label).PixelsPerDip);
            return formatted.Width;
        }

        private void RenderFrame(object sender, EventArgs args)
        {
            TimeSpan frame = ((RenderingEventArgs)args).RenderingTime;
            if (lastFrame == frame) return;
            lastFrame = frame;
            if (motion.IsRunning)
            {
                double elapsed = Math.Min(1, motion.Elapsed.TotalMilliseconds / prefs.Animation);
                double eased = elapsed * elapsed * (3 - 2 * elapsed);
                width = fromWidth + (targetWidth - fromWidth) * eased;
                height = fromHeight + (targetHeight - fromHeight) * eased;
                var body = (Grid)Content;
                // Keep the visual center on the same pixel as the native window grows.
                double pixelWidth = WindowsIntegration.CenteredVisualWidth(this, width);
                body.Width = compact.Width = pixelWidth;

                body.Height = height;
                surface.Morph = Math.Sin(Math.PI * eased);
                content.Clip = new RectangleGeometry(new Rect(0, 0, pixelWidth, height), 21, 21);
                player.Opacity = Math.Max(0, Math.Min(1, (height - 48) / 34));
                settings.Opacity = Math.Max(0, Math.Min(1, (height - 55) / 95));
                if (elapsed >= 1)
                {
                    motion.Stop();
                    if (!expanded) player.Visibility = Visibility.Hidden;
                    UpdateOutline();
                }
            }
            double blendTarget = playing && !expanded ? 1 : 0;
            if (Math.Abs(headerBlend - blendTarget) > .001)
            {
                headerBlend += (blendTarget - headerBlend) * .19;
                if (Math.Abs(headerBlend - blendTarget) < .001) headerBlend = blendTarget;
            }
            clock.Opacity = 1 - headerBlend;
            compactTitle.Opacity = headerBlend;


            if (frame - lastAudioSample < TimeSpan.FromMilliseconds(15)) return;
            lastAudioSample = frame;
            double peak = prefs.Media && !paused && !HoldTestTrack ? meter.ReadPeak() : 0;
            if (!currentTrack.Playing && !paused)
            {
                if (peak > .0002) lastSound = frame.TotalSeconds;
                bool audible = prefs.Media && (peak > .0002 || (fallbackPlaying && frame.TotalSeconds - lastSound < .85));
                if (audible != fallbackPlaying)
                {
                    fallbackPlaying = audible;
                    ApplyTrackDisplay();
                }
            }
            bars.Active = playing;
            if (playing || bars.NeedsDecay) bars.Sample(peak);
        }

        private async void TogglePlayback()
        {
            if (playbackCommandInFlight || pauseRequested || (!currentTrack.Playing && !currentTrack.Paused)) return;
            bool shouldPause = !paused;
            if (shouldPause)
            {
                pauseRequested = true;
                pauseRequestUntil = lastFrame.TotalSeconds + 1.4;
                ApplyTrackDisplay();
            }
            playbackCommandInFlight = true;
            bool accepted = await media.SetPaused(shouldPause);
            playbackCommandInFlight = false;
            if (!accepted && !closed)
            {
                pauseRequested = false;
                ApplyTrackDisplay();
            }
        }

        private Button MediaButton(string glyph, string name, byte key)
        {
            var button = Theme.Button(glyph, delegate {
                if (key == 0xB3) TogglePlayback();
                else media.Transport(key);
            }, key == 0xB3 ? "#6447A3" : "#222027", 33, 12, true);
            button.Margin = new Thickness(4, 0, 4, 0);
            button.Width = 56;
            Theme.Accessible(button, name);
            return button;
        }

        private static TextBlock MakeIcon(string glyph, double size)
        {
            var text = Theme.TextAt(glyph, size, Theme.Text);
            text.FontFamily = Theme.Glyph;
            return text;
        }
    }

    internal sealed class IslandSurface : FrameworkElement
    {
        private Brush fill = Theme.Paint("#D60A090C");
        private static readonly Pen DarkOutline = new Pen(Theme.Paint("#9A8E8C98"), 1);
        private static readonly Pen LightOutline = new Pen(Theme.Paint("#28262C"), .8);
        private bool dark = true;
        private double morph;
        private readonly Brush sheen = new LinearGradientBrush(Color.FromArgb(61, 245, 239, 255), Colors.Transparent, 72);

        public double Morph
        {
            set { morph = value; InvalidateVisual(); }
        }

        public void SetAppearance(int value, int tint)
        {
            Color color = ((SolidColorBrush)Theme.Paint(new[] { "#17161C", "#4A294E", "#16354A", "#203D33" }[tint])).Color;
            var gradient = new LinearGradientBrush(
                Color.FromArgb((byte)Math.Round(255 * (1 - value / 100d)), color.R, color.G, color.B),
                Color.FromArgb((byte)Math.Round(255 * (1 - value * .83 / 100d)), (byte)(color.R * .42), (byte)(color.G * .42), (byte)(color.B * .53)), 90);
            gradient.Freeze();
            fill = gradient;
            InvalidateVisual();
        }

        public void SetDark(bool value)
        {
            if (dark == value) return;
            dark = value;
            InvalidateVisual();
        }

        protected override void OnRender(DrawingContext dc)
        {
            if (RenderSize.Width < 2 || RenderSize.Height < 2) return;
            double radius = Math.Min(RenderSize.Height / 2 - 1, 20.25 + morph * 9);
            var bounds = new Rect(.75, .75, RenderSize.Width - 1.5, RenderSize.Height - 1.5);
            dc.DrawRoundedRectangle(fill, dark ? DarkOutline : LightOutline, bounds, radius, radius);
            dc.PushOpacity(.32 + morph * .68);
            dc.DrawRoundedRectangle(sheen, null, bounds, radius, radius);
            dc.Pop();
        }
    }

    internal sealed class LevelBars : FrameworkElement
    {
        private Brush lit = Theme.Paint("#C4ABFF");
        private static readonly Brush Idle = Theme.Paint("#706780");
        public string Accent { set { lit = Theme.Paint(value); InvalidateVisual(); } }
        private readonly double[] levels = new double[5];
        private double peak, envelope = .003;
        private bool active;
        public bool NeedsDecay { get { return peak > .005 || levels[0] > .005 || levels[4] > .005; } }

        public bool Active
        {
            set { if (active != value) { active = value; InvalidateVisual(); } }
        }

        public void Sample(double amplitude)
        {
            envelope += (amplitude - envelope) * (amplitude > envelope ? .023 : .007);
            double input = 0;
            if (amplitude > .00002)
            {
                double absolute = Math.Max(0, (20 * Math.Log10(amplitude) + 86) / 86);
                double relative = amplitude / Math.Max(.00045, envelope);
                input = Math.Min(1, .62 * absolute + .38 * Math.Min(1, Math.Sqrt(relative) * .72));
            }
            peak += (input - peak) * (input > peak ? .69 : .24);
            levels[2] = peak;
            levels[1] += (levels[2] - levels[1]) * .39;
            levels[3] += (levels[2] - levels[3]) * .29;
            levels[0] += (levels[1] - levels[0]) * .25;
            levels[4] += (levels[3] - levels[4]) * .22;
            InvalidateVisual();
        }

        protected override void OnRender(DrawingContext dc)
        {
            for (int i = 0; i < 5; i++)
            {
                double reach = 1 - Math.Abs(i - 2) * .17;
                double height = 2.5 + 22 * reach * levels[i];
                dc.DrawRoundedRectangle(active ? lit : Idle, null,
                    new Rect(2 + i * 6, (RenderSize.Height - height) / 2, 3.1, height), 1.55, 1.55);
            }
        }
    }
}























