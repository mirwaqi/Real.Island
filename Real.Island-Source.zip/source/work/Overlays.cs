using System;
using System.Diagnostics;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;

namespace IslandDesktop
{
    internal sealed class Island : Window
    {
        private readonly MediaSession media = new MediaSession();
        private readonly OutputMeter meter = new OutputMeter();
        private readonly DispatcherTimer statusTimer, activityTimer;
        private readonly NoticeMonitor notices = new NoticeMonitor();
        private readonly TextBlock callBadge, noticeText, batteryText;
        private readonly Border battery, batteryFill, noticeCard;
        private readonly Image noticeIcon;
        private Action unregisterShortcut;
        private bool activityBusy, noticeBusy, noticeChanging, batteryAvailable;
        private int callMisses;
        private DateTime noticeUntil;
        private const double HeaderHeight = 42;
        private const double RestWidth = 118;
        internal const double GlassPadding = 10;
        internal const double GlassTop = 9;
        private bool noticeOpen;
        private double noticeReveal;
        internal bool CanClickThrough { get { return unregisterShortcut != null; } }
        private readonly IslandSurface surface = new IslandSurface { IsHitTestVisible = false };
        private readonly TextBlock clock, date, title, artist, note, playGlyph;
        private readonly Border art;
        private readonly Button header, pauseButton;
        private readonly StackPanel player, content, mediaPanel;
        private readonly Grid compact, headerLayers;
        private readonly StackPanel transport;
        private readonly TextBlock idleMark, compactTitle;
        private readonly Preferences prefs;
        private readonly IslandSettings settings;
        private bool showingSettings, readingOutline;
        private Track currentTrack = new Track();
        private double lastSound, headerBlend;
        private bool fallbackPlaying;
        private string displayedSource = "";
        private bool paused, pauseRequested, playbackCommandInFlight;
        private double pauseRequestUntil;


        private readonly LevelBars bars = new LevelBars();
        private readonly double[] spectrum = new double[BassCapture.BandCount];
        private readonly Stopwatch motion = new Stopwatch();
        private double width = RestWidth, height = HeaderHeight, fromWidth, fromHeight, targetWidth = RestWidth, targetHeight = HeaderHeight;
        private bool expanded, refreshing, closed, playing;
        private ImageSource previousCover;
        private TimeSpan lastFrame;

        private TimeSpan lastAudioSample;


        public Island(Preferences prefs, Action apply, Action save, Action stop)
        {


            this.prefs = prefs;
            Title = "Dynamic Island";
            WindowStyle = WindowStyle.None;
            ResizeMode = ResizeMode.NoResize;
            AllowsTransparency = true;
            Background = Brushes.Transparent;
            ShowInTaskbar = false;
            ShowActivated = false;
            Topmost = true;
            SizeToContent = SizeToContent.WidthAndHeight;
            UseLayoutRounding = false;
            SnapsToDevicePixels = false;
            var body = new Grid { Width = width + GlassPadding * 2, Height = height + GlassTop + GlassPadding };
            body.Children.Add(surface);
            content = new StackPanel {
                Margin = new Thickness(GlassPadding, GlassTop, GlassPadding, GlassPadding),
                Clip = new RectangleGeometry(new Rect(0, 0, width, height), 21, 21)
            };
            body.Children.Add(content);
            Content = body;

            header = Theme.Button("", HeaderClick, "#00000000", HeaderHeight, 21);
            header.Padding = new Thickness(0);
            Theme.Accessible(header, "Открыть настройки или плеер Dynamic Island");
            compact = new Grid { Width = RestWidth, Height = HeaderHeight };
            art = Theme.Card(8, "#352853");
            art.Width = 28;
            art.Height = 28;
            art.HorizontalAlignment = HorizontalAlignment.Left;
            art.VerticalAlignment = VerticalAlignment.Center;
            note = MakeIcon("\uE8D6", 13);
            note.HorizontalAlignment = HorizontalAlignment.Center;
            art.Child = note;
            art.RenderTransform = new TranslateTransform(12, 0);
            compact.Children.Add(art);
            clock = Theme.TextAt("", 13, Theme.Text, true);
            clock.HorizontalAlignment = HorizontalAlignment.Center;
            clock.Width = 54;
            clock.TextAlignment = TextAlignment.Center;
            TextOptions.SetTextFormattingMode(clock, TextFormattingMode.Ideal);
            System.Windows.Automation.AutomationProperties.SetName(clock, "Текущее время");
            compact.Children.Add(clock);
            compactTitle = Theme.TextAt("", 12, Theme.Text, true);
            compactTitle.Margin = new Thickness(51, 0, 82, 0);
            compactTitle.TextAlignment = TextAlignment.Center;
            compactTitle.TextTrimming = TextTrimming.CharacterEllipsis;
            compact.Children.Add(compactTitle);
            idleMark = MakeIcon("\uE70D", 10);
            idleMark.HorizontalAlignment = HorizontalAlignment.Center;
            compact.Children.Add(idleMark);
            bars.Width = 32;
            bars.Height = HeaderHeight - 4;
            bars.HorizontalAlignment = HorizontalAlignment.Right;
            bars.VerticalAlignment = VerticalAlignment.Center;
            bars.RenderTransform = new TranslateTransform(-12, 0);
            compact.Children.Add(bars);
            battery = Theme.Card(4, "#44232330", "#90EAE8FF");
            battery.Width = 25;
            battery.Height = 12;
            battery.Margin = new Thickness(0, 0, 12, 0);
            battery.Visibility = Visibility.Hidden;
            battery.HorizontalAlignment = HorizontalAlignment.Right;
            battery.VerticalAlignment = VerticalAlignment.Center;
            var batteryBody = new Grid { ClipToBounds = true };
            batteryFill = Theme.Card(3, "#AC52658C");
            batteryFill.HorizontalAlignment = HorizontalAlignment.Left;
            batteryBody.Children.Add(batteryFill);
            batteryText = Theme.TextAt("", 8, Theme.Text, true);
            batteryText.HorizontalAlignment = HorizontalAlignment.Center;
            batteryBody.Children.Add(batteryText);
            battery.Child = batteryBody;
            compact.Children.Add(battery);

            callBadge = Theme.TextAt("●  В звонке", 12, Theme.Paint("#9AF0BC"), true);
            callBadge.Margin = new Thickness(12, 0, 0, 0);
            callBadge.HorizontalAlignment = HorizontalAlignment.Left;
            callBadge.Visibility = Visibility.Hidden;
            compact.Children.Add(callBadge);
            headerLayers = new Grid { Width = RestWidth, Height = HeaderHeight };
            headerLayers.Children.Add(compact);
            header.Content = headerLayers;
            content.Children.Add(header);

            player = new StackPanel { Width = 276, Opacity = 0, Visibility = Visibility.Hidden };
            mediaPanel = new StackPanel { Visibility = Visibility.Collapsed };
            player.Children.Add(mediaPanel);
            title = Theme.TextAt("", 16, Theme.Text, true);
            title.TextTrimming = TextTrimming.CharacterEllipsis;
            title.TextAlignment = TextAlignment.Center;
            mediaPanel.Children.Add(title);
            artist = Theme.TextAt("", 12, Theme.Muted);
            artist.TextTrimming = TextTrimming.CharacterEllipsis;
            artist.TextAlignment = TextAlignment.Center;
            artist.Margin = new Thickness(0, 1, 0, 0);
            mediaPanel.Children.Add(artist);

            var controls = transport = Theme.Row();
            controls.HorizontalAlignment = HorizontalAlignment.Center;
            controls.Margin = new Thickness(0, 10, 0, 0);
            controls.Children.Add(MediaButton("\uE892", "Предыдущий трек", 0xB1));
            var play = MediaButton("\uE768", "Воспроизвести или поставить на паузу", 0xB3);
            playGlyph = MakeIcon("\uE768", 17);
            play.Content = playGlyph;
            playGlyph.Text = "\uE769";
            controls.Children.Add(play);
            controls.Children.Add(MediaButton("\uE893", "Следующий трек", 0xB0));
            mediaPanel.Children.Add(controls);

            var footer = Theme.Row();
            footer.HorizontalAlignment = HorizontalAlignment.Center;
            footer.Margin = new Thickness(0, 9, 0, 0);
            date = Theme.TextAt("", 11, Theme.Muted);
            date.Margin = new Thickness(0, 0, 10, 0);
            footer.Children.Add(date);
            footer.Children.Add(Theme.Button("Настройки", OpenSettings, "#29262F", 24, 8));
            pauseButton = Theme.Button("Пауза", TogglePlayback, "#29262F", 24, 8);
            pauseButton.Width = 105;
            pauseButton.Margin = new Thickness(5, 0, 0, 0);
            pauseButton.Visibility = Visibility.Collapsed;
            footer.Children.Add(pauseButton);
            player.Children.Add(footer);
            content.Children.Add(player);
            settings = new IslandSettings(prefs, this, apply, save, ResizeIsland, stop) { Visibility = Visibility.Collapsed };
            content.Children.Add(settings);
            noticeCard = Theme.Card(10, "#241A1A2C");
            noticeCard.Margin = new Thickness(5, 1, 7, 1);
            noticeCard.Opacity = 0;
            noticeCard.ClipToBounds = true;
            noticeCard.Visibility = Visibility.Collapsed;
            var noticeRow = new DockPanel { Margin = new Thickness(3, 0, 7, 0) };
            noticeIcon = new Image { Width = 38, Height = 38, Stretch = Stretch.Uniform,
                VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 9, 0) };
            noticeIcon.Clip = new RectangleGeometry(new Rect(0, 0, 38, 38), 8, 8);
            DockPanel.SetDock(noticeIcon, Dock.Left);
            noticeRow.Children.Add(noticeIcon);
            noticeText = Theme.TextAt("", 12, Theme.Text, true);
            noticeText.TextTrimming = TextTrimming.CharacterEllipsis;
            noticeText.TextWrapping = TextWrapping.NoWrap;
            noticeRow.Children.Add(noticeText);
            noticeCard.Child = noticeRow;
            headerLayers.Children.Add(noticeCard);

            var menu = new ContextMenu();
            var settingsItem = new MenuItem { Header = "Настройки" };
            settingsItem.Click += delegate { OpenSettings(); };
            var stopItem = new MenuItem { Header = "Остановить оформление" };
            stopItem.Click += delegate { stop(); };
            menu.Items.Add(settingsItem);
            menu.Items.Add(stopItem);
            ContextMenu = menu;

            Loaded += delegate {
                Reposition();
                if (unregisterShortcut == null) unregisterShortcut = WindowsIntegration.InstallIslandShortcut(this, OpenSettings);
                ApplyInputMode();
                if (prefs.Notices && !HoldTestTrack)
                {
                    try { notices.Resume(); }
                    catch (Exception) { notices.Disable(); }
                }
            };
            SourceInitialized += delegate {
                WindowsIntegration.CenterOnResize(this, () => fullscreenWindow);
                body.Width = WindowsIntegration.CenteredVisualWidth(this, width + GlassPadding * 2);
                headerLayers.Width = compact.Width = body.Width - GlassPadding * 2;
            };
            DpiChanged += delegate { Dispatcher.BeginInvoke(new Action(Reposition)); };
            PreviewKeyDown += delegate(object sender, KeyEventArgs e) {
                if (e.Key == Key.Escape && (expanded || showingSettings)) { TogglePanel(); e.Handled = true; }
            };
            IsVisibleChanged += delegate {
                if (IsVisible) CompositionTarget.Rendering += RenderFrame;
                else CompositionTarget.Rendering -= RenderFrame;
            };
            statusTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(450) };
            statusTimer.Tick += async delegate {
                UpdateClock();
                if (refreshing) return;
                refreshing = true;
                try
                {
                    Track track = prefs.Media ? await media.Refresh() : new Track();
                    if (!closed && !HoldTestTrack) UpdateTrack(track);
                }
                finally { refreshing = false; }
            };
            UpdateClock();
            ApplySettings();
            statusTimer.Start();
            activityTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(850) };
            activityTimer.Tick += RefreshActivity;
            activityTimer.Start();
            UpdateBattery();
            Closed += delegate {
                settings.Flush();
                closed = true;
                statusTimer.Stop();
                activityTimer.Stop();
                if (unregisterShortcut != null) unregisterShortcut();
                CompositionTarget.Rendering -= RenderFrame;
                meter.Dispose();
                media.Dispose();
            };
        }

#if SMOKE_TEST
        internal double VisibleHeight { get { return ActualHeight - GlassTop - GlassPadding; } }
        internal double VisibleWidth { get { return ActualWidth - GlassPadding * 2; } }
        internal bool NoticeRevealed { get { return noticeCard.IsVisible && noticeReveal > .98; } }

        internal bool ShowTestBattery()
        {
            batteryAvailable = true;
            batteryText.Text = "73%";
            UpdateBatteryVisibility();
            return battery.IsVisible;
        }

        internal bool BatteryVisible { get { return battery.IsVisible; } }

        internal Point ClockPosition()
        {
            return clock.PointToScreen(new Point(clock.ActualWidth / 2, clock.ActualHeight / 2));
        }
#endif

        private bool HoldTestTrack
        {
            get
            {
#if SMOKE_TEST
                return true;
#else
                return false;
#endif
            }
        }

        private IntPtr fullscreenWindow;
        public void FollowFullscreen(IntPtr fullscreen)
        {
            fullscreenWindow = fullscreen;
            Reposition();
            WindowsIntegration.KeepAbove(this, fullscreen);
        }

        public void Reposition() { WindowsIntegration.Place(this, fullscreenWindow); }
        public async void UpdateGlass()
        {
            if (!IsVisible || readingOutline || motion.IsRunning || surface.GlassTransitioning) return;
            readingOutline = true;
            IntPtr hwnd = new System.Windows.Interop.WindowInteropHelper(this).Handle;
            var dpi = VisualTreeHelper.GetDpi(this);
            int horizontal = (int)Math.Round(GlassPadding * dpi.DpiScaleX);
            int top = (int)Math.Round(GlassTop * (1 - noticeReveal) * dpi.DpiScaleY);
            int bottom = (int)Math.Round(GlassPadding * dpi.DpiScaleY);
            try
            {
                bool dark = true;
                var image = await System.Threading.Tasks.Task.Run(() => WindowsIntegration.GlassBackdrop(hwnd, horizontal, top, bottom, out dark));
                if (!closed && !motion.IsRunning) surface.SetBackdrop(image, prefs.Outline && dark);
            }
            catch (System.ComponentModel.Win32Exception) { }
            finally { readingOutline = false; }
        }

        private void ApplyInputMode()
        {
            WindowsIntegration.SetClickThrough(this, prefs.ClickThrough && CanClickThrough && !showingSettings);
        }

        internal async System.Threading.Tasks.Task<bool> ToggleNotices()
        {
            if (noticeChanging) return prefs.Notices;
            noticeChanging = true;
            try
            {
                if (notices.Enabled && !HoldTestTrack)
                {
                    notices.Disable();
                    prefs.Notices = false;
                    ShowNotice(null);
                }
                else
                {
                    try { prefs.Notices = await notices.Enable(); }
                    catch (Exception) { prefs.Notices = false; }
                }
                return prefs.Notices;
            }
            finally { noticeChanging = false; }
        }

        private void UpdateBattery()
        {
            var power = System.Windows.Forms.SystemInformation.PowerStatus;
            var state = power.BatteryChargeStatus;
            batteryAvailable = state != System.Windows.Forms.BatteryChargeStatus.Unknown &&
                (state & System.Windows.Forms.BatteryChargeStatus.NoSystemBattery) == 0;
            UpdateBatteryVisibility();
            if (!batteryAvailable) return;
            int percent = Math.Max(0, Math.Min(100, (int)Math.Round(power.BatteryLifePercent * 100)));
            batteryText.Text = percent.ToString(CultureInfo.InvariantCulture) + "%";
            batteryFill.Width = 23 * percent / 100d;
            Theme.Accessible(battery, "Заряд " + percent + " процентов");
        }

        private void UpdateBatteryVisibility()
        {
            bool show = expanded && batteryAvailable;
            battery.Visibility = show ? Visibility.Visible : Visibility.Hidden;
            ((TranslateTransform)bars.RenderTransform).X = show ? -43 : -12;
        }

        private async void RefreshActivity(object sender, EventArgs args)
        {
            if (HoldTestTrack) return;
            RefreshNotices();
            if (activityBusy) return;
            activityBusy = true;
            try
            {
                UpdateBattery();
                if (noticeOpen && DateTime.UtcNow >= noticeUntil) ShowNotice(null);
                bool active = await System.Threading.Tasks.Task.Run(() => OutputMeter.HasActiveCall());
                if (closed) return;
                callMisses = active ? 0 : Math.Min(callMisses + 1, 3);
                bool showCall = active || (callBadge.Visibility == Visibility.Visible && callMisses < 3);
                if ((callBadge.Visibility == Visibility.Visible) != showCall)
                {
                    callBadge.Visibility = showCall ? Visibility.Visible : Visibility.Hidden;
                    UpdateMode();
                }
            }
            catch (Exception) { }
            finally { activityBusy = false; }
        }

        private async void RefreshNotices()
        {
            if (closed || noticeBusy || !notices.Enabled || noticeChanging || !IsVisible) return;
            noticeBusy = true;
            try
            {
                var notice = await notices.Refresh();
                if (!closed && notices.Enabled && notice != null && IsVisible) ShowNotice(notice);
            }
            catch (Exception) { }
            finally { noticeBusy = false; }
        }

        internal bool NoticesActive { get { return notices.Enabled; } }

        internal void ShowNotice(IslandNotice notice)
        {
            noticeOpen = notice != null;
            if (noticeOpen)
            {
                noticeCard.Visibility = Visibility.Visible;
                noticeIcon.Source = notice.Icon;
                noticeIcon.Visibility = noticeIcon.Source == null ? Visibility.Collapsed : Visibility.Visible;
                noticeText.Text = notice.App + " · " + notice.Title;
                noticeCard.ToolTip = noticeText.Text +
                    (string.IsNullOrWhiteSpace(notice.Body) ? "" : Environment.NewLine + notice.Body);
                noticeUntil = DateTime.UtcNow.AddSeconds(6);
            }
            ResizeIsland();
        }

        private void UpdateClock()
        {
            DateTime now = DateTime.Now;
            string time = now.ToString("HH:mm");
            if (clock.Text != time) clock.Text = time;
            date.Text = now.ToString("d MMMM", CultureInfo.GetCultureInfo("ru-RU"));
        }

        public void ApplySettings()
        {
            ApplyInputMode();
            surface.SetAppearance(prefs.Transparency, prefs.Tint);
            bars.Accent = new[] { "#C4ABFF", "#F0A8DD", "#91D9FF", "#A1EBC0" }[prefs.Tint];
            if (!prefs.Media) fallbackPlaying = false;
            SelectAudioSource();
            ApplyTrackDisplay();
            UpdateMode();
            UpdateGlass();
        }

        internal void UpdateTrack(Track track)
        {
            currentTrack = track;
            if (track.Paused) pauseRequested = false;
            if (pauseRequested && (lastFrame.TotalSeconds > pauseRequestUntil || track.Source.Length == 0))
                pauseRequested = false;
            if (track.Playing) fallbackPlaying = false;

            SelectAudioSource();
            ApplyTrackDisplay();
        }

        private void SelectAudioSource()
        {
            string source = currentTrack.Playing && currentTrack.Source.Length > 0 ? currentTrack.Source : OutputMeter.PlayerFallback;
            meter.SelectSource(prefs.Media && !HoldTestTrack ? source : "", prefs.ExtraPlayer);
        }

        private void ApplyTrackDisplay()
        {
            bool holdCard = prefs.Media && expanded && (currentTrack.Paused || (pauseRequested && currentTrack.Playing));
            bool fromSession = prefs.Media && (currentTrack.Playing || holdCard);
            bool nextPaused = holdCard;
            bool next = prefs.Media && (fromSession || fallbackPlaying);
            string nextTitle = fromSession && currentTrack.Title.Length > 0 ? currentTrack.Title : "Сейчас играет";
            string nextArtist = fromSession ? currentTrack.Artist : "";
            string nextSource = fromSession ? currentTrack.Source : "";
            ImageSource cover = fromSession ? currentTrack.Cover : null;
            if (!next && !playing) return;
            if (next && playing && compactTitle.Text == nextTitle && artist.Text == nextArtist &&
                previousCover == cover && displayedSource == nextSource && paused == nextPaused) return;

            playing = next;
            displayedSource = nextSource;
            paused = nextPaused;
            playGlyph.Text = paused ? "\uE768" : "\uE769";
            pauseButton.Content = paused ? "Продолжить" : "Пауза";
            title.Text = nextTitle;
            compactTitle.Text = nextTitle;
            artist.Text = nextArtist;
            artist.Visibility = artist.Text.Length == 0 ? Visibility.Collapsed : Visibility.Visible;
            if (previousCover != cover)
            {
                previousCover = cover;
                art.Background = cover == null ? Theme.Paint("#352853") :
                    new ImageBrush(cover) { Stretch = Stretch.UniformToFill };
                note.Visibility = cover == null ? Visibility.Visible : Visibility.Hidden;
            }
            transport.Visibility = pauseButton.Visibility = fromSession && next ? Visibility.Visible : Visibility.Collapsed;
            UpdateMode();
        }

        private void UpdateMode()
        {
            clock.Visibility = prefs.Clock ? Visibility.Visible : Visibility.Hidden;
            compactTitle.Visibility = playing ? Visibility.Visible : Visibility.Hidden;
            idleMark.Visibility = !prefs.Clock && !playing ? Visibility.Visible : Visibility.Hidden;
            art.Visibility = playing && callBadge.Visibility != Visibility.Visible && !showingSettings ? Visibility.Visible : Visibility.Hidden;
            bars.Visibility = playing && !showingSettings ? Visibility.Visible : Visibility.Hidden;
            mediaPanel.Visibility = playing ? Visibility.Visible : Visibility.Collapsed;
            UpdateBatteryVisibility();

            ResizeIsland();
        }

        private void HeaderClick()
        {
            if (!expanded && !playing) OpenSettings();
            else TogglePanel();
        }

        public void TogglePanel()
        {
            if (showingSettings)
            {
                settings.Flush();
                showingSettings = false;
                ApplyInputMode();
                settings.Visibility = Visibility.Collapsed;
                expanded = playing;
                player.Visibility = playing ? Visibility.Visible : Visibility.Collapsed;
                UpdateMode();
                return;
            }
            expanded = !expanded;
            ApplyTrackDisplay();
            Theme.Accessible(header, expanded ? "Свернуть Dynamic Island" : "Открыть Dynamic Island");
            if (expanded) player.Visibility = Visibility.Visible;
            UpdateMode();
        }

        public bool PickerOpen { get; private set; }
        public void SetPickerOpen(bool open)
        {
            PickerOpen = open;
            if (open) { settings.Flush(); Hide(); }
            else if (!closed) { Show(); Activate(); }
        }

        internal IslandSettings SettingsPanel { get { return settings; } }

        public void OpenSettings()
        {
            if (PickerOpen) return;
            if (!IsVisible) Show();
            if (!showingSettings)
            {
                showingSettings = true;
                ApplyInputMode();
                expanded = true;
                player.Visibility = Visibility.Collapsed;
                settings.Visibility = Visibility.Visible;
                settings.Select(IslandSettings.HomeTab);
                UpdateMode();
            }
            Activate();
        }

        private void ResizeIsland()
        {
            double desiredWidth = playing ? Math.Min(348, Math.Max(192, TextWidth(compactTitle) + 132)) : RestWidth;
            double desiredHeight = HeaderHeight;
            if (expanded)
            {
                double labelWidth = playing ? Math.Max(TextWidth(title), TextWidth(artist)) + 56 : 0;
                double screenWidth = System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width;
                var source = PresentationSource.FromVisual(this);
                double scale = source == null ? 1 : source.CompositionTarget.TransformToDevice.M11;
                double limit = Math.Max(235, Math.Min(560, screenWidth / scale - 24));
                desiredWidth = Math.Min(limit, Math.Max(playing ? 300 : 260, labelWidth));
                desiredHeight = playing ? (currentTrack.Playing || paused ? 169 : 122) : 93;
                player.Width = desiredWidth - 24;
                if (showingSettings)
                {
                    desiredWidth = Math.Min(limit, 546);
                    desiredHeight = header.Height + settings.MeasureHeight(desiredWidth - 23) + 11;
                }
            }
            if (callBadge.Visibility == Visibility.Visible) desiredWidth = Math.Max(desiredWidth, 192);
            if (noticeOpen && !expanded) desiredWidth = 214;
            if (Math.Abs(targetWidth - desiredWidth) < .5 && Math.Abs(targetHeight - desiredHeight) < .5) return;
            fromWidth = width;
            fromHeight = height;
            targetWidth = desiredWidth;
            targetHeight = desiredHeight;
            motion.Restart();
        }

        private static double TextWidth(TextBlock label)
        {
            var typeface = new Typeface(label.FontFamily, label.FontStyle, label.FontWeight, label.FontStretch);
            var formatted = new FormattedText(label.Text, CultureInfo.CurrentUICulture,
                FlowDirection.LeftToRight, typeface, label.FontSize, Brushes.White, VisualTreeHelper.GetDpi(label).PixelsPerDip);
            return formatted.Width;
        }

        private void RenderFrame(object sender, EventArgs args)
        {
            TimeSpan frame = ((RenderingEventArgs)args).RenderingTime;
            if (lastFrame == frame) return;
            double dt = Math.Min(.05, (frame - lastFrame).TotalSeconds);
            lastFrame = frame;
            surface.AdvanceGlass();
            var source = PresentationSource.FromVisual(this);
            if (source == null || source.CompositionTarget == null) return;
            var pointer = System.Windows.Forms.Cursor.Position;
            var localPointer = PointFromScreen(new Point(pointer.X, pointer.Y));
            noticeReveal += ((noticeOpen ? 1 : 0) - noticeReveal) * (1 - Math.Exp(-dt * 20));
            if (noticeReveal < .004) noticeReveal = 0;
            if (noticeReveal > .996) noticeReveal = 1;
            if (noticeCard.Visibility == Visibility.Visible)
            {
                noticeCard.Opacity = noticeReveal;
                compact.Opacity = 1 - noticeReveal;
                if (!noticeOpen && noticeReveal == 0)
                {
                    noticeIcon.Source = null;
                    noticeText.Text = "";
                    noticeCard.ToolTip = null;
                    noticeCard.Visibility = Visibility.Collapsed;
                }
            }
            surface.MoveGlass(localPointer, dt, noticeReveal);
            if (motion.IsRunning)
            {
                double elapsed = Math.Min(1, motion.Elapsed.TotalMilliseconds / prefs.Animation);
                double eased = elapsed * elapsed * (3 - 2 * elapsed);
                width = fromWidth + (targetWidth - fromWidth) * eased;
                height = fromHeight + (targetHeight - fromHeight) * eased;
                var body = (Grid)Content;
                // Keep the visual center on the same pixel as the native window grows.
                body.Width = WindowsIntegration.CenteredVisualWidth(this, width + GlassPadding * 2);
                double pixelWidth = headerLayers.Width = compact.Width = body.Width - GlassPadding * 2;

                body.Height = height + GlassTop + GlassPadding;
                surface.Morph = Math.Sin(Math.PI * eased);
                content.Clip = new RectangleGeometry(new Rect(0, 0, pixelWidth, height), 23, 23);
                player.Opacity = Math.Max(0, Math.Min(1, (height - 48) / 34));
                settings.Opacity = Math.Max(0, Math.Min(1, (height - 55) / 95));
                if (elapsed >= 1)
                {
                    motion.Stop();
                    if (!expanded) player.Visibility = Visibility.Collapsed;
                    UpdateGlass();
                }
            }
            double blendTarget = playing && !expanded && callBadge.Visibility != Visibility.Visible ? 1 : 0;
            if (Math.Abs(headerBlend - blendTarget) > .001)
            {
                headerBlend += (blendTarget - headerBlend) * .19;
                if (Math.Abs(headerBlend - blendTarget) < .001) headerBlend = blendTarget;
            }
            clock.Opacity = 1 - headerBlend;
            compactTitle.Opacity = headerBlend;


            if (frame - lastAudioSample < TimeSpan.FromMilliseconds(15)) return;
            lastAudioSample = frame;
            double peak = prefs.Media && !paused && !HoldTestTrack ? meter.ReadPeak() : 0;
            if (!currentTrack.Playing && !paused)
            {
                if (peak > .0002) lastSound = frame.TotalSeconds;
                bool audible = prefs.Media && (peak > .0002 || (fallbackPlaying && frame.TotalSeconds - lastSound < .85));
                if (audible != fallbackPlaying)
                {
                    fallbackPlaying = audible;
                    ApplyTrackDisplay();
                }
            }
            bars.Active = playing;
            if (prefs.Media && !paused && !HoldTestTrack) meter.ReadSpectrum(spectrum);
            else Array.Clear(spectrum, 0, spectrum.Length);
            if (playing || bars.NeedsDecay) bars.SampleSpectrum(peak, spectrum);
        }

        private async void TogglePlayback()
        {
            if (playbackCommandInFlight || pauseRequested || (!currentTrack.Playing && !currentTrack.Paused)) return;
            bool shouldPause = !paused;
            if (shouldPause)
            {
                pauseRequested = true;
                pauseRequestUntil = lastFrame.TotalSeconds + 1.4;
                ApplyTrackDisplay();
            }
            playbackCommandInFlight = true;
            bool accepted = await media.SetPaused(shouldPause);
            playbackCommandInFlight = false;
            if (!accepted && !closed)
            {
                pauseRequested = false;
                ApplyTrackDisplay();
            }
        }

        private Button MediaButton(string glyph, string name, byte key)
        {
            var button = Theme.Button(glyph, delegate {
                if (key == 0xB3) TogglePlayback();
                else media.Transport(key);
            }, key == 0xB3 ? "#6447A3" : "#222027", 33, 12, true);
            button.Margin = new Thickness(4, 0, 4, 0);
            button.Width = 56;
            Theme.Accessible(button, name);
            return button;
        }

        private static TextBlock MakeIcon(string glyph, double size)
        {
            var text = Theme.TextAt(glyph, size, Theme.Text);
            text.FontFamily = Theme.Glyph;
            return text;
        }
    }

    internal sealed class IslandSurface : FrameworkElement
    {
        private Brush fill = Theme.Paint("#D60A090C");
        private ImageBrush backdrop, previousBackdrop;
        private readonly Stopwatch glassTransition = new Stopwatch();
        private double backdropOpacity, glassBlend = 1, outlineBlend = 1, previousOutline = 1;
        private static readonly Pen DarkOutline = new Pen(Theme.Paint("#928E8C98"), .8);
        private static readonly Pen LightOutline = new Pen(Theme.Paint("#33282A35"), .8);
        private bool dark = true;

        private static Brush CreateReflection()
        {
            var brush = new LinearGradientBrush();
            brush.StartPoint = new Point(.04, 0);
            brush.EndPoint = new Point(.66, 1);
            brush.GradientStops.Add(new GradientStop(Color.FromArgb(60, 244, 249, 255), 0));
            brush.GradientStops.Add(new GradientStop(Color.FromArgb(20, 226, 236, 255), .14));
            brush.GradientStops.Add(new GradientStop(Colors.Transparent, .42));
            brush.GradientStops.Add(new GradientStop(Color.FromArgb(20, 230, 227, 255), 1));
            brush.Freeze();
            return brush;
        }
        private double morph;
        private Point glassPointer;
        private double pull, notch;
        private static readonly Brush Reflection = CreateReflection();
        public bool GlassTransitioning { get { return glassTransition.IsRunning; } }

        public double Morph
        {
            set { morph = value; InvalidateVisual(); }
        }

        public void MoveGlass(Point pointer, double seconds, double notice)
        {
            var bounds = GlassBounds();
            double x = Math.Max(bounds.Left, Math.Min(bounds.Right, pointer.X));
            double y = Math.Max(bounds.Top, Math.Min(bounds.Bottom, pointer.Y));
            double distance = (pointer - new Point(x, y)).Length;
            double proximity = Math.Max(0, 1 - distance / 54);
            double target = 7 * proximity * proximity;
            double follow = 1 - Math.Exp(-seconds * 18);
            if (pull == 0) glassPointer = pointer;
            else glassPointer += (pointer - glassPointer) * follow;
            double previousPull = pull;
            double previousNotch = notch;
            pull += (target - pull) * follow;
            if (pull < .025) pull = 0;
            notch = notice;
            if (pull != 0 || previousPull != pull || previousNotch != notch) InvalidateVisual();
        }

        private Rect GlassBounds()
        {
            double left = Island.GlassPadding + .75;
            double top = Island.GlassTop * (1 - notch) + .75;
            return new Rect(left, top, Math.Max(1, RenderSize.Width - 2 * left),
                Math.Max(1, RenderSize.Height - Island.GlassPadding - top - .75));
        }

        public void SetAppearance(int value, int tint)
        {
            Color color = ((SolidColorBrush)Theme.Paint(new[] { "#17161C", "#4A294E", "#16354A", "#203D33" }[tint])).Color;
            var gradient = new LinearGradientBrush(
                Color.FromArgb((byte)Math.Round(255 * (1 - value / 100d)), color.R, color.G, color.B),
                Color.FromArgb((byte)Math.Round(255 * (1 - value * .83 / 100d)), (byte)(color.R * .42), (byte)(color.G * .42), (byte)(color.B * .53)), 90);
            gradient.Freeze();
            fill = gradient;
            backdropOpacity = .20 + value * .005;
            InvalidateVisual();
        }

        public void SetBackdrop(ImageSource image, bool outline)
        {
            if (image == null) return;
            previousBackdrop = backdrop;
            previousOutline = outlineBlend;
            dark = outline;
            backdrop = new ImageBrush(image) { Stretch = Stretch.UniformToFill, AlignmentY = AlignmentY.Top };
            backdrop.Freeze();
            glassBlend = 0;
            glassTransition.Restart();
        }

        public void AdvanceGlass()
        {
            if (!glassTransition.IsRunning) return;
            double progress = Math.Min(1, glassTransition.Elapsed.TotalMilliseconds / 240);
            glassBlend = progress * progress * (3 - 2 * progress);
            outlineBlend = previousOutline + ((dark ? 1 : 0) - previousOutline) * glassBlend;
            if (progress >= 1)
            {
                glassTransition.Stop();
                previousBackdrop = null;
            }
            InvalidateVisual();
        }

        private static double GlassFit(Rect bounds, ImageBrush brush)
        {
            if (brush == null) return 0;
            double ratio = bounds.Width * brush.ImageSource.Height / (bounds.Height * brush.ImageSource.Width);
            double fit = Math.Min(ratio, 1 / ratio);
            return fit * fit;
        }

        protected override void OnRender(DrawingContext dc)
        {
            if (RenderSize.Width <= Island.GlassPadding * 2 + 6 || RenderSize.Height < 25) return;
            var bounds = GlassBounds();
            double radius = Math.Min(bounds.Height / 2 - 1, 23 + morph * 5);
            var shape = GlassShape(bounds, radius);
            dc.DrawGeometry(fill, null, shape);
            if (backdrop != null)
            {
                double oldWeight = GlassFit(bounds, previousBackdrop) * (1 - glassBlend);
                double newWeight = GlassFit(bounds, backdrop) * glassBlend;
                dc.PushOpacity(backdropOpacity * (oldWeight + newWeight));
                dc.DrawGeometry(previousBackdrop ?? backdrop, null, shape);
                if (previousBackdrop != null && newWeight > 0)
                {
                    dc.PushOpacity(newWeight / (oldWeight + newWeight));
                    dc.DrawGeometry(backdrop, null, shape);
                    dc.Pop();
                }
                dc.Pop();
            }
            dc.PushOpacity(.68 + morph * .32);
            dc.DrawGeometry(Reflection, null, shape);
            dc.Pop();
            dc.DrawGeometry(null, LightOutline, shape);
            if (outlineBlend > 0)
            {
                dc.PushOpacity(outlineBlend);
                dc.DrawGeometry(null, DarkOutline, shape);
                dc.Pop();
            }
        }

        private Geometry GlassShape(Rect bounds, double radius)
        {
            if (pull == 0 && notch == 0) return new RectangleGeometry(bounds, radius, radius);

            double topRadius = radius * (1 - .88 * notch);
            var centers = new[] {
                new Point(bounds.Right - topRadius, bounds.Top + topRadius),
                new Point(bounds.Right - radius, bounds.Bottom - radius),
                new Point(bounds.Left + radius, bounds.Bottom - radius),
                new Point(bounds.Left + topRadius, bounds.Top + topRadius)
            };
            var shape = new StreamGeometry();
            using (var path = shape.Open())
            {
                Point previous = new Point(bounds.Left + topRadius, bounds.Top);
                path.BeginFigure(PullEdge(previous, 0, -1), true, true);
                for (int corner = 0; corner < centers.Length; corner++)
                {
                    double r = corner == 0 || corner == 3 ? topRadius : radius;
                    double angle = (corner - 1) * Math.PI / 2;
                    double nx = Math.Cos(angle), ny = Math.Sin(angle);
                    Point start = centers[corner] + new Vector(nx * r, ny * r);
                    Vector side = start - previous;
                    int steps = Math.Max(1, (int)Math.Ceiling(side.Length / 8));
                    for (int i = 1; i <= steps; i++)
                        path.LineTo(PullEdge(previous + side * (i / (double)steps), nx, ny), true, true);
                    for (int i = 1; i <= 10; i++)
                    {
                        double turn = angle + i * Math.PI / 20;
                        nx = Math.Cos(turn);
                        ny = Math.Sin(turn);
                        previous = centers[corner] + new Vector(nx * r, ny * r);
                        path.LineTo(PullEdge(previous, nx, ny), true, true);
                    }
                }
            }
            shape.Freeze();
            return shape;
        }

        private Point PullEdge(Point point, double nx, double ny)
        {
            Vector toward = glassPointer - point;
            double falloff = Math.Max(0, 1 - toward.Length / 80);
            double amount = pull * falloff * Math.Min(1, Math.Max(0, (toward.X * nx + toward.Y * ny + 12) / 22));
            double minimumY = .75 + Island.GlassTop * (1 - notch) * .12;
            return new Point(point.X + nx * amount, Math.Max(minimumY, point.Y + ny * amount));
        }

#if SMOKE_TEST
        internal static bool VerifyCursorPull()
        {
            var glass = new IslandSurface();
            glass.Arrange(new Rect(0, 0, 138, 61));
            var bounds = glass.GlassBounds();
            var near = new Point(bounds.Right + 9, bounds.Top + bounds.Height / 2);
            for (int i = 0; i < 24; i++) glass.MoveGlass(near, .016, 0);
            var pulled = glass.GlassShape(bounds, 20).Bounds;
            var far = new Point(bounds.Right + 150, near.Y);
            for (int i = 0; i < 30; i++) glass.MoveGlass(far, .016, 0);
            return pulled.Right > bounds.Right + 2 && pulled.Right < 138 &&
                glass.GlassShape(bounds, 20).Bounds == bounds;
        }
#endif
    }

    internal sealed class LevelBars : FrameworkElement
    {
        private Brush lit = Theme.Paint("#C4ABFF");
        private static readonly Brush Idle = Theme.Paint("#706780");
        public string Accent { set { lit = Theme.Paint(value); InvalidateVisual(); } }
        private readonly double[] levels = new double[5];
        private readonly double[] bandEnvelope = { .015, .015, .012, .009, .007 };
        private readonly double[] heldBands = new double[BassCapture.BandCount];
        private double bassPulse, previousBass;
        private static readonly double[] BandTravel = { 1, .91, .81, .69, .77 };
        private int missingSpectrum;
        private double peak, envelope = .003, bassEnvelope = .003;
        private bool active;
        public bool NeedsDecay
        {
            get
            {
                foreach (double level in levels) if (level > .005) return true;
                return false;
            }
        }

        public bool Active
        {
            set { if (active != value) { active = value; InvalidateVisual(); } }
        }

        public void SampleSpectrum(double amplitude, double[] bands)
        {
            bool fresh = false;
            foreach (double band in bands) if (band > .00002) { fresh = true; break; }
            missingSpectrum = fresh ? 0 : Math.Min(missingSpectrum + 1, 8);
            if (missingSpectrum >= 8)
            {
                Array.Clear(heldBands, 0, heldBands.Length);
                bassPulse = previousBass = 0;
                Sample(amplitude);
                return;
            }
            if (fresh) Array.Copy(bands, heldBands, bands.Length);

            double total = 0;
            foreach (double band in heldBands) total += band;
            double average = total / heldBands.Length;
            double strongest = 0;
            foreach (double band in heldBands) strongest = Math.Max(strongest, band);
            if (fresh)
            {
                double bass = Math.Max(heldBands[0], heldBands[1]);
                double rise = Math.Max(0, bass - previousBass);
                double kick = rise / (rise + Math.Max(.0002, strongest * .38));
                bassPulse = Math.Max(bassPulse * .72, kick);
                previousBass = bass;
            }
            else bassPulse *= .72;
            for (int i = 0; i < levels.Length; i++)
            {
                double power = heldBands[i];
                double baseline = bandEnvelope[i];
                double ratio = power / Math.Max(.00008, baseline);
                double presence = power / (power + Math.Max(.00008, average));
                bool low = i < 2;
                double gate = low ? .22 + .43 * Math.Max(0, 1 - power / Math.Max(.00008, average * 2)) : .65;
                double accent = Math.Max(0, ratio - (low ? .78 : 1));
                double energyGate = Math.Sqrt(Math.Min(1, power / Math.Max(.0002, amplitude * gate)));
                double body = (low ? .40 : .25) * MeterResponse(power, baseline) + .31 * presence;
                double transient = (low ? .96 : .62) * accent / ((low ? .34 : 1.35) + accent);
                double target = (body + (1 - body) * transient) * energyGate;
                double relativeStrength = power / Math.Max(.00008, strongest);
                target *= .25 + .75 * Math.Min(1, relativeStrength);
                if (low)
                    target += (1 - target) * bassPulse * .59 * Math.Min(1, relativeStrength);
                double attack = low ? .96 : .82 - i * .025;
                double release = low ? .38 : .23 + i * .045;
                levels[i] += (target - levels[i]) * (target > levels[i] ? attack : release);
                if (fresh) bandEnvelope[i] += (power - baseline) * (power > baseline ? .063 : low ? .055 : .023);
                heldBands[i] *= .77;
            }
            peak = levels[2];
            InvalidateVisual();
        }

        internal void Sample(double amplitude, double bass = 0)
        {
            double body = MeterResponse(amplitude, envelope);
            double bassBody = MeterResponse(bass, bassEnvelope);
            double bassRatio = bass / Math.Max(.00008, bassEnvelope);
            double accent = Math.Max(0, bassRatio - 1);
            double beat = accent / (.42 + accent);
            // Combine sustained bass and accents without flattening the strongest hits.
            double music = (bass > 0 ? .72 : .56) * body;
            double lowEnd = .23 * bassBody + .70 * beat;
            double input = music + (1 - music) * lowEnd;
            envelope += (amplitude - envelope) * .014;
            bassEnvelope += (bass - bassEnvelope) * (bass > bassEnvelope ? .009 : bass > .00002 ? .027 : .004);
            peak += (input - peak) * (input > peak ? .97 : .32);
            levels[2] = peak;
            levels[1] += (peak * .86 - levels[1]) * .75;
            levels[3] += (peak * .76 - levels[3]) * .64;
            levels[0] += (peak * .67 - levels[0]) * .5;
            levels[4] += (peak * .56 - levels[4]) * .43;
            InvalidateVisual();
        }

        private static double MeterResponse(double value, double reference)
        {
            double signal = Math.Max(0, value - .00002);
            double ratio = signal / Math.Max(.00008, reference);
            return ratio / (.36 + ratio);
        }

#if SMOKE_TEST
        internal double CenterLevel { get { return levels[2]; } }
        internal double CenterHeight { get { return BarHeight(2); } }
        internal double BandLevel(int band) { return levels[band]; }
#endif

        private double BarHeight(int index)
        {
            return 2.5 + Math.Max(0, RenderSize.Height - 2.5) * BandTravel[index] * levels[index];
        }

        protected override void OnRender(DrawingContext dc)
        {
            for (int i = 0; i < 5; i++)
            {
                double height = BarHeight(i);
                dc.DrawRoundedRectangle(active ? lit : Idle, null,
                    new Rect(2 + i * 6, (RenderSize.Height - height) / 2, 3.1, height), 1.55, 1.55);
            }
        }
    }
}































