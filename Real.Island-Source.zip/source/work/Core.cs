using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Microsoft.Win32;

[assembly: AssemblyTitle("Real.Island")]
[assembly: AssemblyProduct("Real.Island")]
[assembly: AssemblyVersion("2.3.39.0")]

namespace IslandDesktop
{
    internal sealed class App : Application
    {
        public static readonly int ProcessId = System.Diagnostics.Process.GetCurrentProcess().Id;
        internal static bool DelayWeather { get; private set; }

        [STAThread]
        public static int Main(string[] args)
        {
            DelayWeather = Array.IndexOf(args, "--defer-weather") >= 0;
#if SMOKE_TEST
            if (Array.IndexOf(args, "--check") >= 0)
            {
                try { return Verify(); }
                catch (Exception ex) {
                    File.WriteAllText(Path.Combine("work", "verify", "result.txt"), ex.ToString());
                    return 1;
                }
            }
#endif
            if (Array.IndexOf(args, "--uninstall") >= 0) return Installation.BeginRemoval();
            if (Array.IndexOf(args, "--repair-startup") >= 0)
            {
                if (!Installation.Exists) return 1;
                Installation.SetStartup(true);
                return 0;
            }
            int launcher;
            if (args.Length == 2 && args[0] == "--finish-uninstall" && int.TryParse(args[1], out launcher) && launcher > 0)
                return Installation.FinishRemoval(launcher);
            bool created;
            using (var guard = new Mutex(true, Installation.MutexName, out created))
            {
                bool atLogin = Array.IndexOf(args, "--startup") >= 0;
                using (var quit = new EventWaitHandle(false, EventResetMode.AutoReset, Installation.QuitName))
                using (var wake = new EventWaitHandle(false, EventResetMode.AutoReset, @"Local\IslandDesktop.ShowSettings"))
                {
                    try
                    {
                        if (!atLogin && Installation.HasInstalledUpdate())
                        {
                            if (!created)
                            {
                                quit.Set();
                                try { created = guard.WaitOne(5000); }
                                catch (AbandonedMutexException) { created = true; }
                                if (!created) throw new IOException("Закройте запущенную копию Real.Island и откройте скачанный файл ещё раз.");
                            }
                            Installation.UpdateInstalledCopy();
                            atLogin = true;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Не удалось обновить Real.Island. " + ex.Message, Installation.Brand);
                        return 1;
                    }
                    if (!created)
                    {
                        if (!atLogin) wake.Set();
                        return 0;
                    }
                    TaskbarMode.RestoreInterrupted();
                    var application = new App { ShutdownMode = ShutdownMode.OnMainWindowClose };
                    var panel = new Dashboard();
                    application.MainWindow = panel;
                    var activation = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(300) };
                    activation.Tick += delegate { if (quit.WaitOne(0)) panel.Exit(); else if (wake.WaitOne(0)) panel.ShowSettings(); };
                    activation.Start();
                    panel.Closed += delegate { activation.Stop(); };
                    application.SessionEnding += delegate { panel.OnSessionEnding(); };
                    if (atLogin)
                    {
                        application.Dispatcher.BeginInvoke(DispatcherPriority.ApplicationIdle, new Action(panel.StartAtLogin));
                        return application.Run();
                    }
                    return application.Run(panel);
                }
            }
        }



#if SMOKE_TEST
        private static int Verify()
        {
            var app = new App { ShutdownMode = ShutdownMode.OnExplicitShutdown };
            var panel = new Dashboard();
            panel.Show();
            bool permissionsOnLaunch = FindButton(panel, "Разрешить уведомления") != null;
            var powerButton = FindButton(panel, "Запустить");
            InvokeButton(powerButton);
            Flush();
            bool started = Application.Current.Windows.OfType<Island>().Any() &&
                (string)powerButton.Content == "Остановить";
            panel.ShowSettings();
            panel.Close();
            Flush();
            bool stayedOpen = !panel.IsVisible && Application.Current.Windows.OfType<Island>().Any();
            InvokeButton(powerButton);
            Flush();
            bool stopped = !Application.Current.Windows.OfType<Island>().Any() &&
                (string)powerButton.Content == "Запустить";
            panel.ShowSettings();
            var islandPrefs = new Preferences();
            islandPrefs.Apps.Add(Environment.GetFolderPath(Environment.SpecialFolder.Windows) + @"\explorer.exe");
            var island = new Island(islandPrefs, delegate { }, delegate { }, delegate { });
            island.PlayEntrance();
            // At logon the UI can be busy before the renderer draws its first frame.
            island.Show();
            Thread.Sleep(950);
            Flush();
            bool entrance = ((ScaleTransform)((Grid)island.Content).RenderTransform).ScaleX < .25;
            WaitForMotion();
            var openingScale = ((ScaleTransform)((Grid)island.Content).RenderTransform).ScaleX;
            entrance &= openingScale >= .055 && openingScale < 1;
            WaitForMotion();
            WaitForMotion();
            entrance &= ((Grid)island.Content).RenderTransform.Value.IsIdentity;
            double compactWidth = island.VisibleWidth;
            var english = new IntPtr(0x04090409);
            var russian = new IntPtr(0x04190419);
            var ukrainian = new IntPtr(0x04220422);
            long layoutTick = System.Diagnostics.Stopwatch.Frequency / 20;
            island.CheckKeyboardLayout(english, 0);
            island.CheckKeyboardLayout(english, 4 * layoutTick + 4);
            for (int rest = 0; rest < 4; rest++) WaitForMotion();
            island.CheckKeyboardLayout(russian, 5 * layoutTick);
            WaitForMotion();
            bool keepClockWhileWaiting = island.VisibleKeyboardLabel.Length == 0 && !island.CompactHeaderHidden;
            island.CheckKeyboardLayout(russian, 10 * layoutTick);
            WaitForMotion();
            bool keyboardBadge = keepClockWhileWaiting && island.VisibleKeyboardLabel == "РУС" &&
                island.CompactHeaderHidden && island.VisibleWidth == compactWidth;
            island.CheckKeyboardLayout(ukrainian, 11 * layoutTick);
            island.CheckKeyboardLayout(ukrainian, 13 * layoutTick);
            island.CheckKeyboardLayout(english, 14 * layoutTick);
            WaitForMotion();
            keyboardBadge &= island.VisibleKeyboardLabel == "РУС" && island.CompactHeaderHidden;
            island.CheckKeyboardLayout(english, 19 * layoutTick);
            WaitForMotion();
            keyboardBadge &= island.VisibleKeyboardLabel == "ENG" && island.VerifyKeyboardBadgeExit();
            WaitForMotion();
            WaitForMotion();
            WaitForMotion();
            WaitForMotion();
            keyboardBadge &= island.VisibleKeyboardLabel.Length == 0 && island.VisibleWidth == compactWidth;
            bool batteryOnDemand = !island.ShowTestBattery();
            island.TogglePanel();
            WaitForMotion();
            batteryOnDemand &= island.BatteryVisible;
            double idleWidth = island.VisibleWidth;
            bool idle = compactWidth > 95 && compactWidth < 152 && island.VisibleHeight < 100 && idleWidth > 240;
            string output = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "verify");
            Directory.CreateDirectory(output);
            Capture(island, Path.Combine(output, "idle.png"));
            island.TogglePanel();
            WaitForMotion();
            batteryOnDemand &= !island.BatteryVisible;
            island.TogglePanel();
            WaitForMotion();
            var cover = Wallpaper.Art(128, 128);
            island.UpdateTrack(new Track { Title = "Night Drive", Artist = "Тестовый трек", Cover = cover, Playing = true });
            WaitForMotion();
            double shortWidth = island.ActualWidth;
            island.UpdateTrack(new Track { Title = "Night Drive — Extended Midnight Radio Edition (Live in Berlin)", Artist = "Тестовый трек", Cover = cover, Playing = true });
            WaitForMotion();
            bool wider = island.ActualWidth > shortWidth + 65 && island.ActualHeight >= 160;
            Capture(island, Path.Combine(output, "island.png"));
            double playingWidth = island.ActualWidth;
            island.UpdateTrack(new Track { Title = "Night Drive — Extended Midnight Radio Edition (Live in Berlin)",
                Artist = "Тестовый трек", Cover = cover, Paused = true });
            WaitForMotion();
            bool pauseKeepsCard = Math.Abs(island.ActualWidth - playingWidth) < 3 && island.ActualHeight >= 160 && FindButton(island, "Продолжить") != null;
            Capture(island, Path.Combine(output, "paused.png"));
            island.UpdateTrack(new Track());
            WaitForMotion();
            bool reset = Math.Abs(island.VisibleWidth - idleWidth) < 3 && island.VisibleHeight < 100;
            island.TogglePanel();
            WaitForMotion();
            double foldedHeight = island.VisibleHeight;
            var paddedPixels = new byte[64 * 64 * 4];
            for (int y = 24; y < 40; y++)
                for (int x = 24; x < 40; x++)
                {
                    int pixel = (y * 64 + x) * 4;
                    paddedPixels[pixel] = 230;
                    paddedPixels[pixel + 2] = 180;
                    paddedPixels[pixel + 3] = 255;
                }
            var paddedIcon = BitmapSource.Create(64, 64, 96, 96, PixelFormats.Bgra32, null, paddedPixels, 256);
            var croppedIcon = NoticeMonitor.TrimIconPadding(paddedIcon);
            var telegramIcon = NoticeMonitor.MessengerLogo("Telegram");
            bool telegramLogo = telegramIcon != null && telegramIcon.PixelWidth == 32 && telegramIcon.PixelHeight == 32 &&
                ReferenceEquals(telegramIcon, NoticeMonitor.MessengerLogo("Telegram Desktop")) &&
                NoticeMonitor.MessengerLogo("Discord") == null;
            island.ShowNotice(new IslandNotice { App = "Telegram", Title = "Сообщение", Body = "Тест отображения",
                Icon = croppedIcon, FromWindows = true });
            WaitForMotion();
            bool notification = Math.Abs(island.VisibleHeight - foldedHeight - 21) < 2 &&
                island.VisibleWidth >= 320 && island.NoticeRevealed && island.VisibleNoticeBody == "Тест отображения" &&
                croppedIcon.PixelWidth == 18 && croppedIcon.PixelHeight == 18 &&
                FindButton(island, "Ответить") != null;
            Capture(island, Path.Combine(output, "notification.png"));
            InvokeButton(FindButton(island, "Ответить"));
            WaitForMotion();
            var reply = FindButton(island, "Отправить");
            notification &= reply != null && reply.IsVisible &&
                island.VisibleHeight > foldedHeight + 50 && island.VisibleWidth >= 380;
            var replySurface = (Border)reply.Template.FindName("surface", reply);
            Color defaultButton = ((SolidColorBrush)replySurface.Background).Color;
            islandPrefs.ButtonColor = "#347DA4";
            island.ApplySettings();
            Flush();
            Color idleBlue = ((SolidColorBrush)replySurface.Background).Color;
            bool coloredButtons = idleBlue != defaultButton && idleBlue.B > idleBlue.R;
            Theme.MarkActive(reply, true);
            Flush();
            coloredButtons &= ((SolidColorBrush)replySurface.Background).Color.B > idleBlue.B;
            islandPrefs.ButtonColor = "#8000FF";
            island.ApplySettings();
            Flush();
            Color activeViolet = ((SolidColorBrush)replySurface.Background).Color;
            Theme.MarkActive(reply, false);
            Flush();
            Color idleViolet = ((SolidColorBrush)replySurface.Background).Color;
            coloredButtons &= activeViolet.B < 130 && idleViolet.B < activeViolet.B && idleViolet.B > idleViolet.R;
            islandPrefs.ButtonColor = "#FFFFFF";
            island.ApplySettings();
            Flush();
            Color idleWhite = ((SolidColorBrush)replySurface.Background).Color;
            Theme.MarkActive(reply, true);
            Flush();
            Color activeWhite = ((SolidColorBrush)replySurface.Background).Color;
            coloredButtons &= activeWhite.R < 130 && idleWhite.R < activeWhite.R;
            islandPrefs.ButtonColor = "";
            island.ApplySettings();
            Flush();
            coloredButtons &= ((SolidColorBrush)replySurface.Background).Color == defaultButton;
            var cancelReply = FindButton(island, "Отменить");
            notification &= cancelReply != null && cancelReply.IsVisible;
            InvokeButton(cancelReply);
            WaitForMotion();
            notification &= !reply.IsVisible && !cancelReply.IsVisible && island.NoticeRevealed &&
                island.VisibleNoticeBody == "Тест отображения" && FindButton(island, "Ответить").IsVisible;
            island.ShowNotice(null);
            WaitForMotion();
            notification &= !island.NoticeRevealed && Math.Abs(island.VisibleWidth - compactWidth) < 3;
            island.ShowNotice(new IslandNotice { App = "Скачано", Title = "test.zip" });
            WaitForMotion();
            bool downloadNotice = island.IsVisible && island.NoticeRevealed &&
                !FindButton(island, "Ответить").IsVisible;
            island.ShowNotice(null);
            WaitForMotion();
            downloadNotice &= island.IsVisible && !island.NoticeRevealed &&
                Math.Abs(island.VisibleWidth - compactWidth) < 3;
            bool calls = NoticeMonitor.IsIncomingCall("Telegram Desktop", new[] { "Входящий звонок", "Тест" }) &&
                NoticeMonitor.IsIncomingCall("Discord", new[] { "Test is calling you" }) &&
                NoticeMonitor.IsIncomingCall("Discord", new[] { "Test начинает звонок." }) &&
                NoticeMonitor.IsIncomingCall("WhatsApp", new[] { "Входящий аудиозвонок" }) &&
                !NoticeMonitor.IsIncomingCall("Discord", new[] { "Test начинает звонок.", "Вы пропустили звонок." }) &&
                !NoticeMonitor.IsIncomingCall("Discord", new[] { "Missed call" }) &&
                !NoticeMonitor.IsIncomingCall("Browser", new[] { "Incoming call" });
            var whatsappRinging = new[] { "Voice call", "Accept" };
            var whatsappConnected = new[] { "Voice call", "End call" };
            calls &= WindowsIntegration.IsWhatsAppIncomingCall(names => names.Any(whatsappRinging.Contains)) &&
                !WindowsIntegration.IsWhatsAppIncomingCall(names => names.Any(whatsappConnected.Contains));
            foreach (var sample in new[] {
                new[] { "Discord", "Test начинает звонок." },
                new[] { "Telegram", "Test звонит вам…" },
                new[] { "WhatsApp", "Входящий голосовой звонок" }
            })
            {
                island.ShowNotice(new IslandNotice { App = sample[0], Title = "Test", Body = sample[1], FromWindows = true,
                    IncomingCall = NoticeMonitor.IsIncomingCall(sample[0], new[] { sample[1] }) });
                WaitForMotion();
                calls &= island.NoticeRevealed && island.IncomingCallAnimated && !FindButton(island, "Ответить").IsVisible;
            }
            island.ShowNotice(null);
            WaitForMotion();
            island.UpdateCallStatus(true);
            calls &= island.CallBadgeVisible && island.CallBadgeText.Contains("В звонке · 00:00");
            calls &= Island.FormatCallDuration(TimeSpan.FromSeconds(61)) == "01:01" &&
                Island.FormatCallDuration(TimeSpan.FromSeconds(3601)) == "1:00:01";
            Thread.Sleep(1100);
            Flush();
            calls &= island.CallBadgeText != "☎  В звонке · 00:00" && island.CallBadgeText.StartsWith("☎  В звонке · ");
            island.UpdateCallStatus(false);
            island.UpdateCallStatus(false);
            calls &= island.CallBadgeVisible;
            island.UpdateCallStatus(false);
            calls &= !island.CallBadgeVisible;
            island.UpdateCallStatus(false, "Telegram");
            calls &= island.CallBadgeVisible;
            island.UpdateCallStatus(false, "Discord");
            calls &= island.CallBadgeVisible;
            island.UpdateCallStatus(false);
            calls &= !island.CallBadgeVisible;
            island.UpdateCallStatus(false, "WhatsApp");
            WaitForMotion();
            calls &= island.IncomingCallAnimated && island.NoticeRevealed && !FindButton(island, "Ответить").IsVisible;
            island.UpdateCallStatus(false);
            WaitForMotion();
            calls &= !island.IncomingCallAnimated && !island.NoticeRevealed;
            island.UpdateTrack(new Track { Title = "Night Drive — Extended Midnight Radio Edition", Playing = true });
            WaitForMotion();
            double musicWidth = island.VisibleWidth;
            bool trackSave = WindowsIntegration.SupportsSavingTrack(new Track { Source = "Spotify.exe", Title = "Test", Artist = "Artist" }) &&
                !WindowsIntegration.SupportsSavingTrack(new Track { Source = "Chrome", Title = "Test", Artist = "Artist" }) &&
                !WindowsIntegration.CanSaveSpotifySong("Remove from Liked Songs");
            var saveButton = FindButton(island, "Добавить трек в медиатеку Spotify");
            trackSave &= saveButton != null && saveButton.Visibility == Visibility.Collapsed;
            island.UpdateTrack(new Track { Source = "Spotify.exe", Title = "Test", Artist = "Artist", Playing = true });
            trackSave &= saveButton != null && saveButton.Visibility == Visibility.Visible;
            island.UpdateTrack(new Track { Title = "Night Drive — Extended Midnight Radio Edition", Playing = true });
            island.UpdateCallStatus(true);
            calls &= island.CallBadgeVisible && island.MusicBarsVisible && island.CallBadgeText.Contains("В звонке · 00:00");
            island.UpdateCallStatus(false);
            island.UpdateCallStatus(false);
            island.UpdateCallStatus(false);
            island.ShowNotice(new IslandNotice { App = "Telegram", Title = "Сообщение во время музыки" });
            WaitForMotion();
            notification &= island.NoticeRevealed && island.VisibleWidth <= 216 &&
                Math.Abs(island.VisibleHeight - foldedHeight) < 2;
            island.ShowNotice(null);
            WaitForMotion();
            notification &= Math.Abs(island.VisibleWidth - musicWidth) < 3;
            island.UpdateTrack(new Track());
            WaitForMotion();
            var clockStart = island.ClockPosition();
            double clockDrift = 0;
            int clockSamples = 0;
            Action measureClock = delegate {
                var position = island.ClockPosition();
                clockDrift = Math.Max(clockDrift, (position - clockStart).Length);
                clockSamples++;
            };
            EventHandler afterLayout = delegate { island.Dispatcher.BeginInvoke(DispatcherPriority.Render, measureClock); };
            measureClock();
            island.LayoutUpdated += afterLayout;
            int taps = 0;
            var rapid = new DispatcherTimer(DispatcherPriority.Input) { Interval = TimeSpan.FromMilliseconds(45) };
            rapid.Tick += delegate {
                if (++taps >= 8) rapid.Stop();
                if (taps % 2 == 0) island.OpenSettings();
                else island.TogglePanel();
            };
            island.OpenSettings();
            Flush();
            permissionsOnLaunch &= FindButton(island, "Разрешить уведомления") != null;
            rapid.Start();
            for (int attempt = 0; taps < 8 && attempt < 8; attempt++) WaitForMotion();
            WaitForMotion();
            rapid.Stop();
            island.LayoutUpdated -= afterLayout;
            bool steadyClock = taps == 8 && clockSamples >= 8 && clockDrift <= 1;
            island.OpenSettings();
            WaitForMotion();
            var homeShortcut = FindButton(island, "explorer");
            bool inline = island.SettingsPanel.IsVisible && island.VisibleHeight > 200 &&
                island.VisibleWidth > 470 && island.VisibleWidth < 560 && FindButton(island, "+") != null &&
                homeShortcut != null && homeShortcut.IsVisible;
            Capture(island, Path.Combine(output, "settings-home.png"));
            island.SettingsPanel.Select(1);
            WaitForMotion();
            Capture(island, Path.Combine(output, "appearance.png"));
            inline &= island.ActualHeight >= 305;
            island.SettingsPanel.Select(2);
            WaitForMotion();
            Capture(island, Path.Combine(output, "notes.png"));
            island.SettingsPanel.Select(3);
            WaitForMotion();
            bool pickerOpened = false;
            var pickerTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(350) };
            pickerTimer.Tick += delegate {
                pickerTimer.Stop();
                var picker = Application.Current.Windows.OfType<AppPicker>().FirstOrDefault();
                pickerOpened = picker != null && island.PickerOpen && !island.IsVisible;
                if (picker != null)
                {
                    Capture((FrameworkElement)picker.Content, Path.Combine(output, "picker.png"));
                    picker.ConfirmFirst();
                }
            };
            pickerTimer.Start();
            InvokeButton(FindButton(island, "+"));
            WaitForMotion();
            pickerOpened &= island.IsVisible && !island.PickerOpen && islandPrefs.Apps.Count == 2;
            island.SettingsPanel.Select(IslandSettings.HomeTab);
            WaitForMotion();
            inline &= FindButton(island, "+") != null;
            island.SettingsPanel.Select(0);
            WaitForMotion();
            Capture(island, Path.Combine(output, "connections.png"));
            inline &= island.SettingsPanel.IsVisible && island.VisibleHeight >= 210;
            var off = FindButton(island, "Выключить островок");
            if (off == null) inline = false;
            else
            {
                var bottom = off.TranslatePoint(new Point(0, off.ActualHeight), island);
                inline &= bottom.Y + 6 < island.ActualHeight;
            }
            var levels = new LevelBars();
            for (int i = 0; i < 10; i++) levels.Sample(.00025);
            bool moved = levels.NeedsDecay;
            for (int i = 0; i < 80; i++) levels.Sample(0);
            var loud = new LevelBars();
            loud.Arrange(new Rect(0, 0, 32, 38));
            for (int i = 0; i < 300; i++) loud.Sample(.5);
            bool levelFallback = loud.CenterHeight > 13 && loud.CenterHeight < 24;
            for (int i = 0; i < 550; i++) loud.Sample(.98, .06);
            double betweenBeats = loud.CenterLevel;
            for (int i = 0; i < 3; i++) loud.Sample(.98, .09);
            double quietBeat = loud.CenterLevel;
            for (int i = 0; i < 15; i++) loud.Sample(.98, .06);
            for (int i = 0; i < 3; i++) loud.Sample(.98, .30);
            double firstBeat = loud.CenterLevel;
            for (int i = 0; i < 15; i++) loud.Sample(.98, .06);
            for (int i = 0; i < 3; i++) loud.Sample(.98, .65);
            bool bassHeadroom = levelFallback && quietBeat > betweenBeats + .13 &&
                firstBeat > betweenBeats + .26 && loud.CenterLevel > firstBeat + .003 &&
                loud.CenterHeight > 28 && loud.CenterHeight < 38;
            bool independentBands = true;
            double[] testFrequencies = { 62, 215, 780, 2700, 7000 };
            for (int band = 0; band < testFrequencies.Length; band++)
            {
                var spectralBars = new LevelBars();
                double[] tone = BassCapture.TestTone(testFrequencies[band]);
                for (int sample = 0; sample < 12; sample++) spectralBars.SampleSpectrum(.6, tone);
                for (int other = 0; other < testFrequencies.Length; other++)
                    if (other != band)
                        independentBands &= spectralBars.BandLevel(band) > spectralBars.BandLevel(other) + .12;
            }
            var sustained = new LevelBars();
            double[] loudSpectrum = { .94, .70, .88, .66, .82 };
            for (int i = 0; i < 120; i++) sustained.SampleSpectrum(.99, loudSpectrum);
            double steadyBass = sustained.BandLevel(0);
            loudSpectrum[0] = .14;
            for (int i = 0; i < 12; i++) sustained.SampleSpectrum(.99, loudSpectrum);
            double dip = sustained.BandLevel(0);
            loudSpectrum[0] = .94;
            for (int i = 0; i < 3; i++) sustained.SampleSpectrum(.99, loudSpectrum);
            double hit = sustained.BandLevel(0);
            bool loudMotion = dip < steadyBass - .24 && hit > dip + .55 && hit > .78 && hit < .98 &&
                hit > sustained.BandLevel(4) + .35;
            bool sources = OutputMeter.Matches("MSEdge", "msedge", "") &&
                OutputMeter.Matches("Chrome", "chrome", "") &&
                OutputMeter.Matches("Spotify.exe", "spotify", "") &&
                !OutputMeter.Matches("Chrome", "Discord", "") &&
                !OutputMeter.Matches("Spotify.exe", "Teams", "") &&
                MediaSession.IsCallSource("Google Meet") &&
                OutputMeter.Matches(OutputMeter.PlayerFallback, "vlc", "") &&
                OutputMeter.Matches(OutputMeter.PlayerFallback, "PortablePlayer", "", @"C:\Music\PortablePlayer.exe", @"C:\Music\PortablePlayer.exe") &&
                OutputMeter.Matches(OutputMeter.PlayerFallback, "youtube song", "") &&
                OutputMeter.Matches(OutputMeter.PlayerFallback, "YouTube_Music", "") &&
                !OutputMeter.Matches(OutputMeter.PlayerFallback, "chrome", "") &&
                !OutputMeter.Matches(OutputMeter.PlayerFallback, "discord", "");
            bool pass = batteryOnDemand && notification && steadyClock && pauseKeepsCard && pickerOpened && sources && inline && idle && wider && reset && moved && !levels.NeedsDecay && started && stayedOpen && stopped && panel.IsVisible && island.IsVisible;
            bool glassPull = IslandSurface.VerifyCursorPull();
            bool musicDuringCall = OutputMeter.MusicSpectrumWeight(.08f, 0) == 1 &&
                OutputMeter.MusicSpectrumWeight(.08f, .12f) > .35 &&
                OutputMeter.MusicSpectrumWeight(0, .12f) == 0;
            pass &= bassHeadroom && independentBands && loudMotion && glassPull && musicDuringCall;
            var wallpaper = Wallpaper.Art(3840, 2160);
            pass &= wallpaper.PixelWidth == 3840 && wallpaper.PixelHeight == 2160;
            string testPath = Path.Combine(output, "test-prefs.txt");
            var prefs = new Preferences { Wallpaper = @"C:\Обои\пример.png", Transparency = 43, Animation = 455, Media = false, Tint = 2, Notes = "Заметка", ExtraPlayer = @"C:\Музыка\Плеер.exe" };
            prefs.Apps.Add(@"C:\Программы\пример.lnk");
            for (int i = 0; i < 15; i++) prefs.Apps.Add(@"C:\Программы\ярлык-" + i + ".lnk");
            prefs.ClickThrough = true;
            prefs.Notices = true;
            prefs.ApproximateWeather = true;
            prefs.IslandLength = 270;
            prefs.IslandShape = 3;
            prefs.IslandColor = "#CC7799";
            prefs.ButtonColor = "#347DA4";
            prefs.ClockFormat = 2;
            prefs.ClockFont = 3;
            prefs.ClockSize = 20;
            prefs.CardColor = "#253B54";
            prefs.IslandBackground = @"C:\Обои\фон.mp4";
            prefs.NoticeSound = false;
            prefs.DownloadNotices = false;
            prefs.ExcludedApps.Add("RobloxPlayerBeta");
            prefs.Save(testPath);
            Preferences restored = Preferences.Load(testPath);
            bool groupedReply = WindowsIntegration.IsMoreNotificationsLabel("+11 уведомл.") &&
                WindowsIntegration.IsMoreNotificationsLabel("3 more notifications") &&
                !WindowsIntegration.IsMoreNotificationsLabel("Clear all notifications") &&
                WindowsIntegration.MatchesNotificationLabel("Метка", " Метка") &&
                !WindowsIntegration.MatchesNotificationLabel("Метка", "Метка 2") &&
                WindowsIntegration.MatchesCombinedNotificationText("Тестовый отправитель\r\nПервое сообщение",
                    new[] { "Тестовый отправитель", "Первое сообщение" }) &&
                !WindowsIntegration.MatchesCombinedNotificationText("Тестовый отправитель\r\nВторое сообщение",
                    new[] { "Тестовый отправитель", "Первое сообщение" });
            var replyField = new Rect(120, 598, 307, 40);
            bool inlineReply = WindowsIntegration.IsInlineReplyButton(replyField, new Rect(437, 598, 61, 40)) &&
                !WindowsIntegration.IsInlineReplyButton(replyField, new Rect(437, 343, 61, 40)) &&
                !WindowsIntegration.IsInlineReplyButton(replyField, new Rect(540, 598, 61, 40)) &&
                !WindowsIntegration.IsInlineReplyButton(replyField, Rect.Empty);
            var messengers = new[] { "Telegram", "Discord", "WhatsApp", "Viber", "Signal", "Microsoft Teams",
                "Zoom Workplace", "Skype", "Slack", "Webex" };
            bool messengerRouting = messengers.All(name =>
                new IslandNotice { App = name, FromWindows = true }.CanReply &&
                NoticeMonitor.IsIncomingCall(name, new[] { "Incoming call" }) &&
                !new IslandNotice { App = name, FromWindows = true, IncomingCall = true }.CanReply) &&
                !new IslandNotice { App = "Windows PowerShell", FromWindows = true }.CanReply;
            pass &= groupedReply && inlineReply && permissionsOnLaunch && messengerRouting && telegramLogo && entrance && keyboardBadge && coloredButtons && calls && trackSave && downloadNotice &&
                restored.ApproximateWeather && !restored.NoticeSound && !restored.DownloadNotices;
            pass &= restored.IslandLength == 270 && restored.IslandShape == 3 &&
                restored.IslandColor == prefs.IslandColor && restored.IslandBackground == prefs.IslandBackground &&
                restored.ButtonColor == prefs.ButtonColor && restored.ClockFormat == 2 && restored.ClockFont == 3 &&
                restored.ClockSize == 20 && restored.CardColor == "#253B54";
            pass &= restored.Wallpaper == prefs.Wallpaper && restored.Transparency == 43 && restored.Animation == 455 && !restored.Media && restored.Tint == 2 && restored.Notes == prefs.Notes && restored.ExtraPlayer == prefs.ExtraPlayer && restored.Apps.SequenceEqual(prefs.Apps) && restored.ClickThrough && restored.Notices && restored.ExcludedApps.SetEquals(prefs.ExcludedApps);
            Capture((FrameworkElement)panel.Content, Path.Combine(output, "dashboard.png"));
            island.Close();
            panel.Close();
            app.Shutdown();
            File.WriteAllText(Path.Combine(output, "result.txt"), pass ? "OK. Clock drift: " + clockDrift + " px. Battery visibility: OK." : "FAIL. Battery: " + batteryOnDemand + " Started: " + started + " Stopped: " + stopped + " Idle: " + idle + " Compact: " + compactWidth + " Idle width: " + idleWidth + " Wider: " + wider + " Reset: " + reset + " Stayed open: " + stayedOpen + " Inline: " + inline + " Pause: " + pauseKeepsCard + " Picker: " + pickerOpened + " Clock drift: " + clockDrift + " px; settings height: " + island.ActualHeight + "; sources: " + sources + "; clock samples: " + clockSamples + "; bars: " + moved + "/" + levels.NeedsDecay);
            File.AppendAllText(Path.Combine(output, "result.txt"), Environment.NewLine + string.Format(
                CultureInfo.InvariantCulture, "Bass headroom: {0}. Constant loudness, center height: {1:P0}, {2:P0}, {3:P0}, {4:P0}.",
                bassHeadroom ? "OK" : "FAIL", betweenBeats, quietBeat, firstBeat, loud.CenterLevel));
            File.AppendAllText(Path.Combine(output, "result.txt"), Environment.NewLine + "Cursor pull: " + glassPull + "; notification reveal: " + notification);
            File.AppendAllText(Path.Combine(output, "result.txt"), Environment.NewLine + "Independent frequency bands: " + independentBands);
            File.AppendAllText(Path.Combine(output, "result.txt"), Environment.NewLine + "Entrance: " + entrance);
            File.AppendAllText(Path.Combine(output, "result.txt"), Environment.NewLine + "Keyboard layout animation: " + keyboardBadge);
            File.AppendAllText(Path.Combine(output, "result.txt"), Environment.NewLine + "Button color and reset: " + coloredButtons);
            File.AppendAllText(Path.Combine(output, "result.txt"), Environment.NewLine + "Spotify save eligibility: " + trackSave);
            File.AppendAllText(Path.Combine(output, "result.txt"), Environment.NewLine + "Incoming call notification: " + calls);
            File.AppendAllText(Path.Combine(output, "result.txt"), Environment.NewLine + "Returns to compact mode after download notice: " + downloadNotice);
            File.AppendAllText(Path.Combine(output, "result.txt"), Environment.NewLine + "First-run permissions button: " + permissionsOnLaunch +
                "; grouped quick reply labels: " + groupedReply + "; inline reply action: " + inlineReply);
            File.AppendAllText(Path.Combine(output, "result.txt"), Environment.NewLine + "Messenger notification routing: " + messengerRouting);
            File.AppendAllText(Path.Combine(output, "result.txt"), Environment.NewLine + "Telegram notification icon: " + telegramLogo);
            File.AppendAllText(Path.Combine(output, "result.txt"), Environment.NewLine + "Music spectrum during calls: " + musicDuringCall);
            File.AppendAllText(Path.Combine(output, "result.txt"), Environment.NewLine + "Rapid clicks: " + taps + "; stable: " + steadyClock);
            File.AppendAllText(Path.Combine(output, "result.txt"), Environment.NewLine +
                string.Format(CultureInfo.InvariantCulture, "Loud spectrum motion: {0}. Steady/dip/hit: {1:P0}/{2:P0}/{3:P0}", loudMotion, steadyBass, dip, hit));
            return pass ? 0 : 1;
        }

        private static void WaitForMotion()
        {
            var frame = new DispatcherFrame();
            var timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(385) };
            timer.Tick += delegate { timer.Stop(); frame.Continue = false; };
            timer.Start();
            Dispatcher.PushFrame(frame);
        }

        private static Button FindButton(DependencyObject root, string name)
        {
            var button = root as Button;
            if (button != null && ((button.Content as string) == name ||
                System.Windows.Automation.AutomationProperties.GetName(button) == name)) return button;
            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(root); i++)
            {
                Button found = FindButton(VisualTreeHelper.GetChild(root, i), name);
                if (found != null) return found;
            }
            return null;
        }

        private static void InvokeButton(Button button)
        {
            if (button == null) throw new InvalidOperationException("Launch button is missing.");
            var peer = new System.Windows.Automation.Peers.ButtonAutomationPeer(button);
            var invoke = (System.Windows.Automation.Provider.IInvokeProvider)peer.GetPattern(System.Windows.Automation.Peers.PatternInterface.Invoke);
            invoke.Invoke();
        }

        private static void Flush()
        {
            Dispatcher.CurrentDispatcher.Invoke(new Action(delegate { }), DispatcherPriority.ApplicationIdle);
        }

        private static void Capture(FrameworkElement window, string path)
        {
            var bitmap = new RenderTargetBitmap((int)Math.Ceiling(window.ActualWidth), (int)Math.Ceiling(window.ActualHeight), 96, 96, PixelFormats.Pbgra32);
            bitmap.Render(window);
            Wallpaper.SavePng(bitmap, path);
        }
#endif
    }

    internal sealed class Preferences
    {
        public const string Aurora = "@aurora";
        public static readonly string Folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Island Desktop");
        public static readonly string FileName = Path.Combine(Folder, "preferences.txt");
        public string Wallpaper = "";
        public int Transparency = 16, Animation = 320, Tint;
        public string Notes = "", ExtraPlayer = "";
        public bool ClickThrough, Notices = true;
        public bool ApproximateWeather;
        public int IslandShape, IslandLength = 118;
        public string IslandColor = "", IslandBackground = "", ButtonColor = "";
        public bool NoticeSound = true, DownloadNotices = true;
        public readonly HashSet<string> ExcludedApps = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        public readonly List<string> Apps = new List<string>();
        public bool Clock = true, Media = true, Outline = true, HideTaskbar = true, HideFullscreen = false;
        public int ClockFormat;
        internal static readonly string[] ClockFonts = { "Segoe UI", "Bahnschrift", "Consolas", "Georgia", "Arial", "Trebuchet MS" };
        public int ClockFont;
        internal const int MinClockSize = 10, MaxClockSize = 22;
        public int ClockSize = 13;
        public int ClockTransparency;
        public string ClockColor = "", SpectrumColor = "";
        public string CardColor = "";

        public static bool StartsAtLogin() { return Installation.StartupEnabled(); }
        public static void SetStartAtLogin(bool enable) { Installation.SetStartup(enable); }

        public static Preferences Load(string path)
        {
            var prefs = new Preferences();
            if (!File.Exists(path)) return prefs;
            try
            {
                string[] lines = File.ReadAllLines(path);
                if (lines.Length < 2 || (lines[0] != "Island Desktop 1" && lines[0] != "Island Desktop 2" && lines[0] != "Island Desktop 3" && lines[0] != "Island Desktop 4" && lines[0] != "Island Desktop 5")) return prefs;
                prefs.Wallpaper = Decode(lines[1]);
                if (lines[0] != "Island Desktop 1" && lines.Length >= 9)
                {
                    prefs.Transparency = ReadNumber(lines[2], 0, 60, prefs.Transparency);
                    prefs.Animation = ReadNumber(lines[3], 160, 580, prefs.Animation);
                    prefs.Clock = lines[4] != "0";
                    prefs.Media = lines[5] != "0";
                    prefs.Outline = lines[6] != "0";
                    prefs.HideTaskbar = lines[7] != "0";
                    prefs.HideFullscreen = (lines[0] == "Island Desktop 4" || lines[0] == "Island Desktop 5") && lines[8] != "0";
                    if (lines.Length >= 11 && (lines[0] == "Island Desktop 3" || lines[0] == "Island Desktop 4" || lines[0] == "Island Desktop 5"))
                    {
                        prefs.Tint = ReadNumber(lines[9], 0, 3, 0);
                        prefs.Notes = Decode(lines[10]);
                        if (lines[0] == "Island Desktop 5" && lines.Length >= 12)
                            prefs.ExtraPlayer = Decode(lines[11]);
                        int start = lines[0] == "Island Desktop 5" ? 12 : 11;
                        prefs.Apps.AddRange(lines.Skip(start).Select(Decode));
                        string extra = File.Exists(path + ".activity") ? File.ReadAllText(path + ".activity") : null;
                        if (extra != null)
                        {
                            string[] fields = extra.Split('|');
                            prefs.ClickThrough = fields.Length > 1 && fields[1] == "1";
                            prefs.Notices = fields.Length > 2 && fields[2] == "1";
                            foreach (string field in fields.Skip(3))
                            {
                                if (field == "approximate-weather:1") prefs.ApproximateWeather = true;
                                else if (field == "mute:1") prefs.NoticeSound = false;
                                else if (field == "downloads:0") prefs.DownloadNotices = false;
                                else if (field.StartsWith("shape:")) prefs.IslandShape = ReadNumber(field.Substring(6), 0, 3, 0);
                                else if (field.StartsWith("length:")) prefs.IslandLength = ReadNumber(field.Substring(7), 118, 340, 118);
                                else if (field.StartsWith("color:")) prefs.IslandColor = Decode(field.Substring(6));
                                else if (field.StartsWith("button-color:")) prefs.ButtonColor = Decode(field.Substring(13));
                                else if (field.StartsWith("clock-format:")) prefs.ClockFormat = ReadNumber(field.Substring(13), 0, 2, 0);
                                else if (field.StartsWith("clock-font:")) prefs.ClockFont = ReadNumber(field.Substring(11), 0, ClockFonts.Length - 1, 0);
                                else if (field.StartsWith("clock-size:")) prefs.ClockSize = ReadNumber(field.Substring(11), MinClockSize, MaxClockSize, 13);
                                else if (field.StartsWith("clock-alpha:")) prefs.ClockTransparency = ReadNumber(field.Substring(12), 0, 100, 0);
                                else if (field.StartsWith("clock-color:")) prefs.ClockColor = Decode(field.Substring(12));
                                else if (field.StartsWith("spectrum-color:")) prefs.SpectrumColor = Decode(field.Substring(15));
                                else if (field.StartsWith("card-color:")) prefs.CardColor = Decode(field.Substring(11));
                                else if (field.StartsWith("background:")) prefs.IslandBackground = Decode(field.Substring(11));
                                else if (field.Length > 0 && !field.Contains(":")) prefs.ExcludedApps.Add(Decode(field));
                            }
                        }
                    }
                }
                return prefs;
            }
            catch (IOException) { return new Preferences(); }
            catch (UnauthorizedAccessException) { return new Preferences(); }
            catch (FormatException) { return new Preferences(); }
        }

        public void Save(string path)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            string staged = path + ".tmp";
            var lines = new[] { "Island Desktop 5", Encode(Wallpaper),
                Transparency.ToString(CultureInfo.InvariantCulture), Animation.ToString(CultureInfo.InvariantCulture),
                Flag(Clock), Flag(Media), Flag(Outline), Flag(HideTaskbar), Flag(HideFullscreen),
                Tint.ToString(CultureInfo.InvariantCulture), Encode(Notes), Encode(ExtraPlayer) };
            string extra = string.Join("|", new[] { "extra", Flag(ClickThrough), Flag(Notices) }.Concat(ExcludedApps.Select(Encode)));
            extra += "|approximate-weather:" + Flag(ApproximateWeather) + "|mute:" + Flag(!NoticeSound) + "|downloads:" + Flag(DownloadNotices);
            extra += "|shape:" + IslandShape + "|length:" + IslandLength +
                "|color:" + Encode(IslandColor) + "|background:" + Encode(IslandBackground) +
                "|button-color:" + Encode(ButtonColor) + "|clock-format:" + ClockFormat + "|clock-font:" + ClockFont +
                "|clock-size:" + ClockSize + "|clock-alpha:" + ClockTransparency + "|clock-color:" + Encode(ClockColor) +
                "|spectrum-color:" + Encode(SpectrumColor) + "|card-color:" + Encode(CardColor);
            File.WriteAllLines(staged, lines.Concat(Apps.Select(Encode)));
            if (File.Exists(path)) File.Replace(staged, path, null);
            else File.Move(staged, path);
            File.WriteAllText(path + ".activity", extra);
        }

        private static string Flag(bool value) { return value ? "1" : "0"; }

        private static int ReadNumber(string value, int min, int max, int fallback)
        {
            int parsed;
            return int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out parsed)
                ? Math.Min(max, Math.Max(min, parsed)) : fallback;
        }

        private static string Encode(string value) { return Convert.ToBase64String(Encoding.UTF8.GetBytes(value)); }
        private static string Decode(string value) { return Encoding.UTF8.GetString(Convert.FromBase64String(value)); }
    }

    internal static class Theme
    {
        internal static readonly DependencyProperty ButtonColorProperty = DependencyProperty.RegisterAttached(
            "ButtonColor", typeof(string), typeof(Theme), new FrameworkPropertyMetadata("", FrameworkPropertyMetadataOptions.Inherits));
        internal static readonly DependencyProperty ActiveButtonProperty = DependencyProperty.RegisterAttached(
            "ActiveButton", typeof(bool), typeof(Theme), new FrameworkPropertyMetadata(false));
        internal static void MarkActive(Button button, bool active) { button.SetValue(ActiveButtonProperty, active); }
        private static readonly ButtonBackground ButtonBackgroundConverter = new ButtonBackground();
        public static readonly Brush Text = Paint("#F5F6FC"), Muted = Paint("#ADB3C5");
        public static readonly FontFamily Font = new FontFamily("Segoe UI");
        public static readonly FontFamily Glyph = new FontFamily("Segoe MDL2 Assets");

        public static Brush Paint(string hex)
        {
            return new SolidColorBrush((Color)ColorConverter.ConvertFromString(hex));
        }

        internal static string CustomColor(string value, string fallback)
        {
            uint rgb;
            return value.Length == 7 && value[0] == '#' &&
                uint.TryParse(value.Substring(1), NumberStyles.HexNumber, CultureInfo.InvariantCulture, out rgb)
                ? value : fallback;
        }

        public static TextBlock TextAt(string text, double size, Brush color, bool bold = false)
        {
            return new TextBlock { Text = text, FontFamily = Font, Foreground = color, FontSize = size,
                FontWeight = bold ? FontWeights.SemiBold : FontWeights.Normal, VerticalAlignment = VerticalAlignment.Center };
        }

        public static Border Card(double radius, string fill, string edge = null)
        {
            return new Border { CornerRadius = new CornerRadius(radius), Background = Paint(fill),
                BorderBrush = edge == null ? null : Paint(edge), BorderThickness = new Thickness(edge == null ? 0 : 1) };
        }

        public static Button Button(string text, Action click, string fill, double height = 36, double radius = 12, bool glyph = false)
        {
            var button = new Button {
                Content = text, Foreground = Text, Background = Paint(fill),
                FontFamily = glyph ? Glyph : Font, FontSize = glyph ? 17 : 13, FontWeight = glyph ? FontWeights.Normal : FontWeights.SemiBold,
                Height = height, Padding = new Thickness(12, 0, 12, 0), Cursor = Cursors.Hand, BorderThickness = new Thickness(0),
                HorizontalContentAlignment = HorizontalAlignment.Center, VerticalContentAlignment = VerticalAlignment.Center
            };
            var template = new ControlTemplate(typeof(Button));
            var border = new FrameworkElementFactory(typeof(Border), "surface");
            border.SetValue(Border.CornerRadiusProperty, new CornerRadius(radius));
            if (fill == "#00000000")
                border.SetValue(Border.BackgroundProperty, new TemplateBindingExtension(Control.BackgroundProperty));
            else
            {
                var background = new System.Windows.Data.MultiBinding { Converter = ButtonBackgroundConverter };
                var parent = new System.Windows.Data.RelativeSource(System.Windows.Data.RelativeSourceMode.TemplatedParent);
                background.Bindings.Add(new System.Windows.Data.Binding("Background") { RelativeSource = parent });
                background.Bindings.Add(new System.Windows.Data.Binding { Path = new PropertyPath("(0)", ButtonColorProperty), RelativeSource = parent });
                background.Bindings.Add(new System.Windows.Data.Binding { Path = new PropertyPath("(0)", ActiveButtonProperty), RelativeSource = parent });
                background.Bindings.Add(new System.Windows.Data.Binding("IsPressed") { RelativeSource = parent });
                border.SetBinding(Border.BackgroundProperty, background);
                var foreground = new System.Windows.Data.MultiBinding { Converter = ButtonBackgroundConverter, ConverterParameter = "foreground" };
                foreach (var binding in background.Bindings.Cast<System.Windows.Data.Binding>())
                    foreground.Bindings.Add(new System.Windows.Data.Binding { Path = binding.Path, RelativeSource = parent });
                border.SetBinding(System.Windows.Documents.TextElement.ForegroundProperty, foreground);
            }
            var content = new FrameworkElementFactory(typeof(ContentPresenter));
            content.SetValue(FrameworkElement.MarginProperty, new TemplateBindingExtension(Control.PaddingProperty));
            content.SetValue(FrameworkElement.HorizontalAlignmentProperty, HorizontalAlignment.Center);
            content.SetValue(FrameworkElement.VerticalAlignmentProperty, VerticalAlignment.Center);
            border.AppendChild(content);
            template.VisualTree = border;
            if (fill != "#00000000")
            {
                AddTrigger(template, UIElement.IsMouseOverProperty, .83);
                AddTrigger(template, ButtonBase.IsPressedProperty, .62);
            }
            AddTrigger(template, UIElement.IsEnabledProperty, .38, false);
            button.Template = template;
            button.Click += delegate { click(); };
            return button;
        }

        private static void AddTrigger(ControlTemplate template, DependencyProperty property, double opacity, bool when = true)
        {
            var trigger = new Trigger { Property = property, Value = when };
            trigger.Setters.Add(new Setter(UIElement.OpacityProperty, opacity, "surface"));
            template.Triggers.Add(trigger);
        }

        public static void Accessible(FrameworkElement control, string name)
        {
            control.ToolTip = name;
            System.Windows.Automation.AutomationProperties.SetName(control, name);
        }

        public static StackPanel Row() { return new StackPanel { Orientation = Orientation.Horizontal }; }

        private sealed class ButtonBackground : System.Windows.Data.IMultiValueConverter
        {
            public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
            {
                var original = values[0] as SolidColorBrush;
                var hex = values[1] as string;
                uint rgb;
                bool foreground = parameter != null;
                if (original == null || original.Color.A == 0 ||
                    string.IsNullOrEmpty(hex) || hex.Length != 7 ||
                    hex[0] != '#' || !uint.TryParse(hex.Substring(1), NumberStyles.HexNumber, CultureInfo.InvariantCulture, out rgb))
                    return foreground ? Text : values[0];
                var tint = Color.FromRgb((byte)(rgb >> 16), (byte)(rgb >> 8), (byte)rgb);
                bool active = Equals(values[2], true) || Equals(values[3], true);
                double maximum = Math.Max(tint.R, Math.Max(tint.G, tint.B));
                double scale = maximum == 0 ? 0 : (active ? 85d : 37d) / maximum;
                tint = Color.FromRgb((byte)Math.Round(23 + tint.R * scale),
                    (byte)Math.Round(21 + tint.G * scale), (byte)Math.Round(28 + tint.B * scale));
                return foreground ? Text : new SolidColorBrush(tint);
            }

            public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
            {
                throw new NotSupportedException();
            }
        }
    }

    internal static class Wallpaper
    {
        public static BitmapSource LoadPreview(string path)
        {
            var image = new BitmapImage();
            image.BeginInit();
            image.CacheOption = BitmapCacheOption.OnLoad;
            image.DecodePixelWidth = 720;
            using (Stream source = File.OpenRead(path))
            {
                image.StreamSource = source;
                image.EndInit();
            }
            image.Freeze();
            return image;
        }

        public static void SavePng(BitmapSource image, string path)
        {
            var encoder = new PngBitmapEncoder();
            encoder.Frames.Add(BitmapFrame.Create(image));
            using (Stream file = File.Create(path)) encoder.Save(file);
        }

        public static BitmapSource Art(int width, int height)
        {
            var visual = new DrawingVisual();
            using (DrawingContext d = visual.RenderOpen())
            {
                d.PushTransform(new ScaleTransform(width / 960d, height / 540d));
                d.DrawRectangle(Gradient("#080B17", "#181127", "#21164A", 26), null, new Rect(0, 0, 960, 540));
                var light = new RadialGradientBrush((Color)ColorConverter.ConvertFromString("#7758CA"), Colors.Transparent);
                light.GradientOrigin = light.Center = new Point(.52, .58);
                d.DrawRectangle(light, null, new Rect(155, -22, 990, 590));
                Shape(d, "M -90,531 C 113,327 216,214 405,212 C 608,210 630,477 1020,259 L 1030,610 L -90,610 Z",
                    Gradient("#5C3FC4", "#6944AD", "#261B58", 26));
                Shape(d, "M -50,550 C 164,491 303,289 503,312 C 661,330 748,400 1000,220 L 1000,580 L -50,580 Z",
                    Gradient("#2C255E", "#5277D0", "#9A6BE5", 334));
                Shape(d, "M -15,555 C 192,505 330,367 491,371 C 654,375 802,487 1000,356 L 1000,580 L -15,580 Z",
                    Gradient("#10132A", "#222C63", "#47418F", 312));
                d.Pop();
            }
            var result = new RenderTargetBitmap(width, height, 96, 96, PixelFormats.Pbgra32);
            result.Render(visual);
            result.Freeze();
            return result;
        }

        private static void Shape(DrawingContext drawing, string geometry, Brush brush)
        {
            drawing.DrawGeometry(brush, null, Geometry.Parse(geometry));
        }

        private static LinearGradientBrush Gradient(string a, string b, string c, double angle)
        {
            var stops = new GradientStopCollection {
                new GradientStop((Color)ColorConverter.ConvertFromString(a), 0),
                new GradientStop((Color)ColorConverter.ConvertFromString(b), .52),
                new GradientStop((Color)ColorConverter.ConvertFromString(c), 1)
            };
            return new LinearGradientBrush(stops, angle);
        }

        public static void Apply(string selection)
        {
            Directory.CreateDirectory(Preferences.Folder);
            if (selection == Preferences.Aurora)
            {
                string generated = Path.Combine(Preferences.Folder, "Aurora 4K.png");
                if (!File.Exists(generated)) SavePng(Art(3840, 2160), generated);
                WindowsIntegration.SetWallpaper(generated);
                return;
            }

            string extension = Path.GetExtension(selection).ToLowerInvariant();
            // Keep common wallpaper formats at their original resolution.
            if (extension == ".jpg" || extension == ".jpeg" || extension == ".png" || extension == ".bmp")
            {
                WindowsIntegration.SetWallpaper(selection);
                return;
            }
            using (Stream source = File.OpenRead(selection))
            {
                BitmapDecoder decoder = BitmapDecoder.Create(source, BitmapCreateOptions.PreservePixelFormat, BitmapCacheOption.OnLoad);
                string converted = Path.Combine(Preferences.Folder, "Selected-" + Guid.NewGuid().ToString("N") + ".png");
                SavePng(decoder.Frames[0], converted);
                WindowsIntegration.SetWallpaper(converted);
            }
        }
    }
}











































